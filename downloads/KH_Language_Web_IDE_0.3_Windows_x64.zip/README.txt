KH言語 IDE 0.3
Windows 10／11（x64）

■ HTMLを作る

1. ZIPを展開し、KH_IDE.exe を開きます。
2. 最初に表示されるウェブサンプルを編集します。複数ファイルの例を
   試す場合は、examples/Website/index.kh を「開く」で選びます。
3. 「HTML出力」または F8 を押し、保存先と名前を決めます。
   例として mypage.html を指定すると、同じ場所に mypage-site ができ、
   中に index.html、styles.css、app.js、追加ページが生成されます。
4. 「ブラウザーで開く」で確認します。公開するときは、生成したフォルダー
   の中身をまとめて静的ホスティングの公開先に置きます。

生成先に同名のフォルダーがあるときは、新しい名前を指定してください。
サンプルの公開用ファイルは examples/GeneratedWebsite に同梱しています。

■ .kh で書く

    theme("#1e684d")
    page("私のホームページ", "トップページの説明")
    text("こんにちは！")
    link("アトリエについて", "about.html")
    button("押してみる", "クリックできました！")

    page("about.html", "アトリエについて", "活動紹介")
    text("ここに紹介文を書きます。")
    link("トップページへ", "index.html")

サイトのソースは UTF-8 の .kh です。ページ内容、共通デザイン、
ボタンの動作を同じファイルにまとめることも、複数に分けることもできます。

    use "style.kh"

use は引用符付きで1行に書き、編集中のメイン .kh と同じフォルダーにある
ファイルを指定します。先にメインを保存してください。読み込むファイル名は
半角の英数字、ハイフン、アンダースコアと拡張子 .kh を使います。
読み込んだ内容は use の位置で実行されます。

■ ウェブ用の命令

    language("ja")                      ページの言語
    theme("#1e684d")                     共通のアクセント色
    page("ページ名", "説明")              index.html を作る
    page("about.html", "ページ名", "説明") 追加ページを作る
    section("セクション名")               まとまりを作る
    section_end()                       まとまりを閉じる
    heading("見出し")                    見出し
    text("本文")                         段落
    link("案内", "about.html")            リンク
    image("photo.jpg", "写真の説明")       画像
    button("ラベル", "メッセージ")         クリックでメッセージを表示
    css("body { margin: 0; }")           共通CSSを追記
    script("console.log(\"Hello\");")     共通JavaScriptを追記

css や script の文字列内では \n で改行、\" で引用符を書けます。
image でローカル画像を指定した場合、画像を生成先に置いてください。
共通設定はサイト全体に適用されます。ページ名は重複させず、index.html を
1つ用意してください。ページ内の section は section_end() で閉じます。

ウェブ用の命令はF8で処理され、HTMLなどの公開用ファイルになります。
既存の if / else / repeat / function も、ページを組み立てる処理に使えます。
ボタンのメッセージ表示は生成後にブラウザーで動きます。独自のブラウザー
処理は script() から共通の app.js に追加できます。
この版の出力先は静的サイトです。

■ コンソール用 .exe を作る

以前の .kh スクリプトは引き続きF5で実行し、F7で単体のWindows用
.exeにできます。examples/Console/Hello.kh が例です。命令は英語で、
変数名・関数名・引数名には日本語も使えます。

■ ソースからの再ビルド

x86-64 Linux で GCC、GNU binutils（i386pep 対応の ld）、Python 3、make
を用意し、source フォルダーで make を実行します。
生成先は build/KH_IDE.exe です。
