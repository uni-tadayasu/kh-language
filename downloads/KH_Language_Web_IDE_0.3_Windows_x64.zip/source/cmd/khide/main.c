#include <stddef.h>
#include <stdint.h>
#include "../../internal/buildexe.h"
#include "../../internal/lang.h"
#include "../../internal/webexport.h"

typedef unsigned short WCHAR;
typedef void *Handle;
typedef uint32_t DWord;
typedef uintptr_t WParam;
typedef intptr_t LParam;
typedef intptr_t LResult;

typedef struct {
    int32_t left, top, right, bottom;
} Rect;

typedef struct {
    Handle window;
    unsigned message;
    WParam wparam;
    LParam lparam;
    DWord time;
    int32_t x, y;
    DWord private_value;
} Message;

typedef struct {
    unsigned size;
    unsigned style;
    LResult (*procedure)(Handle, unsigned, WParam, LParam);
    int class_extra;
    int window_extra;
    Handle instance;
    Handle icon;
    Handle cursor;
    Handle background;
    const WCHAR *menu_name;
    const WCHAR *class_name;
    Handle small_icon;
} WindowClass;

typedef struct {
    DWord size;
    Handle owner;
    Handle instance;
    const WCHAR *filter;
    WCHAR *custom_filter;
    DWord max_custom_filter;
    DWord filter_index;
    WCHAR *file;
    DWord max_file;
    WCHAR *file_title;
    DWord max_file_title;
    const WCHAR *initial_dir;
    const WCHAR *title;
    DWord flags;
    unsigned short file_offset;
    unsigned short extension_offset;
    const WCHAR *default_extension;
    LParam custom_data;
    void *hook;
    const WCHAR *template_name;
    void *reserved;
    DWord reserved_flags;
    DWord extended_flags;
} OpenFileName;

_Static_assert(sizeof(Rect) == 16, "RECT layout");
_Static_assert(sizeof(WindowClass) == 80, "WNDCLASSEXW layout");
_Static_assert(sizeof(Message) == 48, "MSG layout");
_Static_assert(sizeof(OpenFileName) == 152, "OPENFILENAMEW layout");

extern void ExitProcess(unsigned code);
extern Handle GetModuleHandleW(const WCHAR *name);
extern Handle GetProcessHeap(void);
extern void *HeapAlloc(Handle heap, DWord flags, size_t size);
extern int HeapFree(Handle heap, DWord flags, void *memory);
extern int MultiByteToWideChar(unsigned codepage, DWord flags, const char *text,
                               int count, WCHAR *wide, int capacity);
extern int WideCharToMultiByte(unsigned codepage, DWord flags, const WCHAR *wide,
                               int count, char *text, int capacity,
                               const char *default_char, int *used_default);
extern Handle CreateFileW(const WCHAR *name, DWord access, DWord share,
                          void *security, DWord creation, DWord flags, Handle template_file);
extern int GetFileSizeEx(Handle file, int64_t *size);
extern int ReadFile(Handle file, void *data, DWord size, DWord *read, void *overlapped);
extern int WriteFile(Handle file, const void *data, DWord size, DWord *written, void *overlapped);
extern int CloseHandle(Handle handle);
extern int MoveFileExW(const WCHAR *old_name, const WCHAR *new_name, DWord flags);
extern int DeleteFileW(const WCHAR *name);
extern unsigned GetTempFileNameW(const WCHAR *path, const WCHAR *prefix, unsigned unique, WCHAR *output);

extern unsigned short RegisterClassExW(const WindowClass *window_class);
extern Handle CreateWindowExW(DWord ex_style, const WCHAR *class_name, const WCHAR *name,
                              DWord style, int x, int y, int width, int height,
                              Handle parent, Handle menu, Handle instance, void *param);
extern int ShowWindow(Handle window, int command);
extern int UpdateWindow(Handle window);
extern int GetMessageW(Message *message, Handle window, unsigned first, unsigned last);
extern int TranslateMessage(const Message *message);
extern LResult DispatchMessageW(const Message *message);
extern void PostQuitMessage(int code);
extern LResult DefWindowProcW(Handle window, unsigned message, WParam wparam, LParam lparam);
extern int SetWindowTextW(Handle window, const WCHAR *text);
extern int GetWindowTextW(Handle window, WCHAR *text, int max_count);
extern int GetWindowTextLengthW(Handle window);
extern LResult SendMessageW(Handle window, unsigned message, WParam wparam, LParam lparam);
extern Handle SetFocus(Handle window);
extern int MoveWindow(Handle window, int x, int y, int width, int height, int repaint);
extern int GetClientRect(Handle window, Rect *rect);
extern Handle LoadCursorW(Handle instance, const WCHAR *name);
extern Handle LoadIconW(Handle instance, const WCHAR *name);
extern int MessageBoxW(Handle window, const WCHAR *text, const WCHAR *title, unsigned type);
extern int DestroyWindow(Handle window);
extern short GetKeyState(int key);
extern int EnableWindow(Handle window, int enable);
extern Handle ShellExecuteW(Handle window, const WCHAR *verb, const WCHAR *file,
                            const WCHAR *parameters, const WCHAR *directory, int command);

extern Handle CreateFontW(int height, int width, int escape, int orientation,
                          int weight, DWord italic, DWord underline, DWord strikeout,
                          DWord charset, DWord precision, DWord clip_precision,
                          DWord quality, DWord family, const WCHAR *face);
extern Handle GetStockObject(int object);
extern int DeleteObject(Handle object);
extern DWord SetBkColor(Handle dc, DWord color);
extern DWord SetTextColor(Handle dc, DWord color);
extern Handle CreateSolidBrush(DWord color);

extern int GetOpenFileNameW(OpenFileName *name);
extern int GetSaveFileNameW(OpenFileName *name);
extern DWord CommDlgExtendedError(void);

#define WM_CREATE 0x0001
#define WM_DESTROY 0x0002
#define WM_SIZE 0x0005
#define WM_CLOSE 0x0010
#define WM_GETMINMAXINFO 0x0024
#define WM_SETFONT 0x0030
#define WM_KEYDOWN 0x0100
#define WM_COMMAND 0x0111
#define WM_CTLCOLOREDIT 0x0133
#define WM_CTLCOLORSTATIC 0x0138

#define WS_OVERLAPPEDWINDOW 0x00cf0000u
#define WS_CLIPCHILDREN 0x02000000u
#define WS_VISIBLE 0x10000000u
#define WS_CHILD 0x40000000u
#define WS_VSCROLL 0x00200000u
#define WS_HSCROLL 0x00100000u
#define WS_TABSTOP 0x00010000u
#define WS_EX_CLIENTEDGE 0x00000200u
#define ES_MULTILINE 0x0004u
#define ES_AUTOVSCROLL 0x0040u
#define ES_AUTOHSCROLL 0x0080u
#define ES_NOHIDESEL 0x0100u
#define ES_READONLY 0x0800u
#define ES_WANTRETURN 0x1000u
#define BS_DEFPUSHBUTTON 1
#define SS_CENTERIMAGE 0x0200
#define SS_PATHELLIPSIS 0x8000

#define EM_SETSEL 0x00b1
#define EM_SCROLLCARET 0x00b7
#define EM_LINEINDEX 0x00bb
#define EM_LINELENGTH 0x00c1
#define EM_SETLIMITTEXT 0x00c5
#define EN_CHANGE 0x0300u

#define ID_NEW 100
#define ID_OPEN 101
#define ID_SAVE 102
#define ID_SAVE_AS 103
#define ID_RUN 104
#define ID_BUILD 105
#define ID_WEB_SAMPLE 106
#define ID_WEB_EXPORT 107
#define ID_WEB_OPEN 108
#define ID_EDITOR 109
#define ACTION_COUNT 9

#define OFN_OVERWRITEPROMPT 0x00000002u
#define OFN_HIDEREADONLY 0x00000004u
#define OFN_NOCHANGEDIR 0x00000008u
#define OFN_PATHMUSTEXIST 0x00000800u
#define OFN_FILEMUSTEXIST 0x00001000u
#define OFN_EXPLORER 0x00080000u

#define GENERIC_READ 0x80000000u
#define GENERIC_WRITE 0x40000000u
#define FILE_SHARE_READ 1u
#define OPEN_EXISTING 3u
#define TRUNCATE_EXISTING 5u
#define FILE_ATTRIBUTE_NORMAL 0x80u
#define MOVEFILE_REPLACE_EXISTING 1u
#define MOVEFILE_WRITE_THROUGH 8u

#define MB_ICONERROR 0x10u
#define MB_ICONQUESTION 0x20u
#define MB_YESNOCANCEL 3u
#define MB_DEFBUTTON3 0x200u
#define IDYES 6
#define IDNO 7

#define DEFAULT_WINDOW_POSITION ((int)0x80000000u)
#define SYSTEM_APPLICATION_ICON ((const WCHAR *)(uintptr_t)32512)
#define SYSTEM_ARROW_CURSOR ((const WCHAR *)(uintptr_t)32512)
#define INVALID_HANDLE ((Handle)(intptr_t)-1)
#define EDIT_LIMIT (KH_SOURCE_UNIT_LIMIT * 2)
#define SOURCE_FILE_LIMIT (KH_SOURCE_BYTE_LIMIT + 3)
#define OUTPUT_CAPACITY 2000000
#define PATH_CAPACITY 32768
#define COLOR(red, green, blue) ((DWord)((red) | ((green) << 8) | ((blue) << 16)))

typedef struct {
    Handle instance;
    Handle window;
    Handle title;
    Handle path;
    Handle editor_label;
    Handle output_label;
    Handle editor;
    Handle output;
    Handle status;
    Handle buttons[ACTION_COUNT];
    Handle interface_font;
    Handle title_font;
    Handle code_font;
    Handle page_brush;
    Handle output_brush;
    WCHAR file_path[PATH_CAPACITY];
    WCHAR last_index_path[PATH_CAPACITY];
    int dirty;
    int loading;
} Ide;

typedef struct {
    char *bytes;
    size_t length;
    size_t capacity;
    unsigned lines;
} Output;

static Ide ide;
static const WCHAR app_title[] = u"KH言語 IDE 0.3";
static const WCHAR class_name[] = u"KHLanguageIDE";
static const WCHAR kh_filter[] = u"KH スクリプト (*.kh)\0*.kh\0すべてのファイル (*.*)\0*.*\0";
static const WCHAR exe_filter[] = u"Windows アプリ (*.exe)\0*.exe\0";
static const WCHAR html_filter[] = u"ホームページ (*.html)\0*.html\0";
static const WCHAR web_sample[] =
    u"# F8 で HTML・CSS・JavaScript を書き出します。\r\n"
    u"サイト名 = \"葛西ウェブ工房\"\r\n"
    u"説明 = \"KH言語で作った、はじめてのホームページです。\"\r\n"
    u"theme(\"#176344\")\r\n"
    u"page(サイト名, 説明)\r\n"
    u"heading(\"ホームページへようこそ\")\r\n"
    u"text(説明)\r\n"
    u"link(\"工房について\", \"about.html\")\r\n"
    u"section(\"できること\")\r\n"
    u"text(\"文章、リンク、ボタンを組み合わせてページを作れます。\")\r\n"
    u"button(\"メッセージを表示\", \"ページを見てくれてありがとう！\")\r\n"
    u"section_end()\r\n"
    u"\r\n"
    u"page(\"about.html\", \"工房について\", \"葛西ウェブ工房の紹介です。\")\r\n"
    u"heading(\"工房について\")\r\n"
    u"text(\"このページも同じ .kh ファイルから作られています。\")\r\n"
    u"link(\"トップへ戻る\", \"index.html\")\r\n";

static void *allocate(size_t size) {
    return HeapAlloc(GetProcessHeap(), 0, size);
}

static void release(void *memory) {
    if (memory) HeapFree(GetProcessHeap(), 0, memory);
}

static size_t wide_length(const WCHAR *text) {
    size_t length = 0;
    while (text[length]) length++;
    return length;
}

static size_t narrow_length(const char *text) {
    size_t length = 0;
    while (text[length]) length++;
    return length;
}

static size_t append_wide(WCHAR *target, size_t capacity, size_t used, const WCHAR *text) {
    while (used + 1 < capacity && *text) target[used++] = *text++;
    target[used] = 0;
    return used;
}

static size_t append_number(WCHAR *target, size_t capacity, size_t used, unsigned value) {
    WCHAR reversed[16];
    size_t count = 0;
    do {
        reversed[count++] = (WCHAR)('0' + value % 10);
        value /= 10;
    } while (value);
    while (count && used + 1 < capacity) target[used++] = reversed[--count];
    target[used] = 0;
    return used;
}

static const WCHAR *basename(const WCHAR *path) {
    const WCHAR *name = path;
    for (const WCHAR *character = path; *character; character++) {
        if (*character == '\\' || *character == '/') name = character + 1;
    }
    return name;
}

static void show_error(const WCHAR *message) {
    MessageBoxW(ide.window, message, app_title, MB_ICONERROR);
}

static void status(const WCHAR *message) {
    SetWindowTextW(ide.status, message);
}

static WCHAR *utf8_as_edit_text(const char *source, int byte_length) {
    if (!byte_length) {
        WCHAR *empty = allocate(sizeof(WCHAR));
        if (empty) empty[0] = 0;
        return empty;
    }
    int count = MultiByteToWideChar(65001, 8, source, byte_length, 0, 0);
    if (count <= 0) return 0;

    WCHAR *wide = allocate((size_t)count * sizeof(WCHAR));
    WCHAR *edit = allocate(((size_t)count * 2 + 1) * sizeof(WCHAR));
    if (!wide || !edit || MultiByteToWideChar(65001, 8, source, byte_length, wide, count) != count) {
        release(wide);
        release(edit);
        return 0;
    }

    size_t used = 0;
    for (int index = 0; index < count; index++) {
        WCHAR character = wide[index];
        if (character == '\r' || character == '\n') {
            if (character == '\r' && index + 1 < count && wide[index + 1] == '\n') index++;
            edit[used++] = '\r';
            edit[used++] = '\n';
        } else {
            edit[used++] = character ? character : 0x2400;
        }
    }
    edit[used] = 0;
    release(wide);
    return edit;
}

static char *editor_source(void) {
    int length = GetWindowTextLengthW(ide.editor);
    WCHAR *wide = allocate(((size_t)length + 1) * sizeof(WCHAR));
    if (!wide) return 0;
    wide[0] = 0;
    GetWindowTextW(ide.editor, wide, length + 1);
    size_t cursor = 0;
    for (int index = 0; wide[index]; index++) {
        if (wide[index] == '\r' && wide[index + 1] == '\n') continue;
        wide[cursor++] = wide[index] == '\r' ? '\n' : wide[index];
    }
    wide[cursor] = 0;
    int size = WideCharToMultiByte(65001, 128, wide, -1, 0, 0, 0, 0);
    char *source = size > 0 ? allocate((size_t)size) : 0;
    if (source && !WideCharToMultiByte(65001, 128, wide, -1, source, size, 0, 0)) {
        release(source);
        source = 0;
    }
    release(wide);
    return source;
}

static void update_filename(void) {
    WCHAR title[256];
    size_t used = append_wide(title, 256, 0, app_title);
    used = append_wide(title, 256, used, u"  /  ");
    used = append_wide(title, 256, used, *ide.file_path ? basename(ide.file_path) : u"untitled.kh");
    if (ide.dirty) append_wide(title, 256, used, u"  *");
    SetWindowTextW(ide.window, title);
    SetWindowTextW(ide.path, *ide.file_path ? ide.file_path : u"untitled.kh");
}

static void load_document(const WCHAR *source, const WCHAR *path, int dirty) {
    ide.loading = 1;
    SetWindowTextW(ide.editor, source);
    ide.loading = 0;
    append_wide(ide.file_path, PATH_CAPACITY, 0, path);
    ide.dirty = dirty;
    update_filename();
    SetWindowTextW(ide.output, u"Webサイトは F8 で HTML 出力。スクリプトは F5 で実行できます。");
    status(u"編集できます");
    SetFocus(ide.editor);
}

typedef enum { PATH_SCRIPT, PATH_EXECUTABLE, PATH_WEBSITE } PathKind;

static int select_path(WCHAR *path, int save, PathKind kind) {
    OpenFileName dialog = {0};
    dialog.size = sizeof dialog;
    dialog.owner = ide.window;
    dialog.filter = kind == PATH_WEBSITE ? html_filter : kind == PATH_EXECUTABLE ? exe_filter : kh_filter;
    dialog.filter_index = 1;
    dialog.file = path;
    dialog.max_file = PATH_CAPACITY;
    dialog.default_extension = kind == PATH_WEBSITE ? u"html" : kind == PATH_EXECUTABLE ? u"exe" : u"kh";
    if (kind == PATH_WEBSITE) dialog.title = u"HTML 出力先とサイトフォルダー名を指定";
    else if (kind == PATH_EXECUTABLE) dialog.title = u"実行ファイルの保存先";
    else dialog.title = save ? u"KH スクリプトを保存" : u"KH スクリプトを開く";
    dialog.flags = OFN_EXPLORER | OFN_NOCHANGEDIR | OFN_HIDEREADONLY | OFN_PATHMUSTEXIST;
    if (!save) dialog.flags |= OFN_FILEMUSTEXIST;
    else if (kind != PATH_WEBSITE) dialog.flags |= OFN_OVERWRITEPROMPT;
    int selected = save ? GetSaveFileNameW(&dialog) : GetOpenFileNameW(&dialog);
    if (!selected && CommDlgExtendedError()) show_error(u"ファイル選択画面を開けませんでした。");
    return selected;
}

static int has_extension(const WCHAR *path, const WCHAR *extension) {
    const WCHAR *name = basename(path);
    size_t name_length = wide_length(name);
    size_t ext_length = wide_length(extension);
    if (name_length <= ext_length) return 0;
    name += name_length - ext_length;
    for (size_t index = 0; index < ext_length; index++) {
        WCHAR character = name[index];
        if (character >= 'A' && character <= 'Z') character += 'a' - 'A';
        if (character != extension[index]) return 0;
    }
    return 1;
}

static int write_source(const WCHAR *path, const char *source) {
    WCHAR directory[260];
    WCHAR temp_path[260];
    size_t length = (size_t)(basename(path) - path);
    if (length == 0 || length >= 246) return 0;
    for (size_t index = 0; index < length; index++) directory[index] = path[index];
    directory[length] = 0;
    if (!GetTempFileNameW(directory, u"KH", 0, temp_path)) return 0;

    int saved = 0;
    Handle file = CreateFileW(temp_path, GENERIC_WRITE, 0, 0, TRUNCATE_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
    if (file != INVALID_HANDLE) {
        DWord written = 0;
        DWord size = (DWord)narrow_length(source);
        int result = WriteFile(file, source, size, &written, 0) && written == size;
        int closed = CloseHandle(file);
        saved = result && closed && MoveFileExW(temp_path, path, MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH);
    }
    if (!saved) DeleteFileW(temp_path);
    return saved;
}

static int save_document(int as_new) {
    WCHAR *path = allocate(PATH_CAPACITY * sizeof(WCHAR));
    if (!path) {
        show_error(u"保存に必要なメモリを確保できませんでした。");
        return 0;
    }
    if (as_new || !has_extension(ide.file_path, u".kh")) {
        size_t used = append_wide(path, PATH_CAPACITY, 0, *ide.file_path ? basename(ide.file_path) : u"untitled.kh");
        if (!has_extension(path, u".kh")) append_wide(path, PATH_CAPACITY, used, u".kh");
        if (!select_path(path, 1, PATH_SCRIPT)) {
            release(path);
            return 0;
        }
    } else {
        append_wide(path, PATH_CAPACITY, 0, ide.file_path);
    }
    if (!has_extension(path, u".kh")) {
        show_error(u"ファイル名の末尾を .kh にして保存してください。");
        release(path);
        return 0;
    }
    char *source = editor_source();
    int saved = source && write_source(path, source);
    if (saved) {
        append_wide(ide.file_path, PATH_CAPACITY, 0, path);
        ide.dirty = 0;
        update_filename();
        status(u"KH スクリプトを保存しました");
    } else {
        show_error(u"保存できませんでした。保存先のパスと書き込み権限を確認してください。");
    }
    release(source);
    release(path);
    return saved;
}

static int confirm_replacement(void) {
    if (!ide.dirty) return 1;
    int choice = MessageBoxW(ide.window, u"編集中のスクリプトを保存しますか？",
                             app_title, MB_ICONQUESTION | MB_YESNOCANCEL | MB_DEFBUTTON3);
    if (choice == IDYES) return save_document(0);
    return choice == IDNO;
}

static WCHAR *read_source(const WCHAR *path) {
    Handle file = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
    if (file == INVALID_HANDLE) return 0;
    WCHAR *source = 0;
    int64_t size;
    if (GetFileSizeEx(file, &size) && size >= 0 && size <= SOURCE_FILE_LIMIT) {
        char *bytes = allocate((size_t)size + 1);
        if (bytes) {
            DWord count = 0;
            if (ReadFile(file, bytes, (DWord)size, &count, 0) && count == (DWord)size) {
                unsigned offset = 0;
                if (count >= 3 && (unsigned char)bytes[0] == 0xef &&
                    (unsigned char)bytes[1] == 0xbb && (unsigned char)bytes[2] == 0xbf) offset = 3;
                unsigned check = offset;
                while (check < count && bytes[check]) check++;
                if (check == count) {
                    source = utf8_as_edit_text(bytes + offset, (int)(count - offset));
                    if (source && wide_length(source) > EDIT_LIMIT) {
                        release(source);
                        source = 0;
                    }
                }
            }
            release(bytes);
        }
    }
    CloseHandle(file);
    return source;
}

static void open_document(void) {
    if (!confirm_replacement()) return;
    WCHAR *path = allocate(PATH_CAPACITY * sizeof(WCHAR));
    if (!path) {
        show_error(u"ファイルを開くためのメモリを確保できませんでした。");
        return;
    }
    path[0] = 0;
    if (select_path(path, 0, PATH_SCRIPT)) {
        WCHAR *source = read_source(path);
        if (source) {
            load_document(source, path, 0);
            release(source);
        } else {
            show_error(u"ファイルを読み込めませんでした。UTF-8 で保存したテキストファイルを選んでください。");
        }
    }
    release(path);
}

static void append_output(Output *output, const char *text, size_t length) {
    if (length > output->capacity - output->length) length = output->capacity - output->length;
    for (size_t index = 0; index < length; index++) output->bytes[output->length++] = text[index];
}

static void receive_output(const char *text, size_t length, void *context) {
    Output *output = context;
    if (output->lines++) append_output(output, "\n", 1);
    append_output(output, text, length);
}

static void show_diagnostic(const KHDiagnostic *diagnostic, const WCHAR *previous) {
    WCHAR message[512];
    size_t used = 0;
    used = append_number(message, 512, used, (unsigned)diagnostic->line);
    used = append_wide(message, 512, used, u" 行 ");
    used = append_number(message, 512, used, (unsigned)diagnostic->column);
    used = append_wide(message, 512, used, u" 列  ");
    status(message);
    int remaining = (int)(512 - used);
    if (!MultiByteToWideChar(65001, 0, diagnostic->message, -1, message + used, remaining)) {
        append_wide(message, 512, used, u"コードにエラーがあります。");
    }
    if (*previous) {
        size_t capacity = wide_length(previous) + wide_length(message) + 5;
        WCHAR *combined = allocate(capacity * sizeof(WCHAR));
        if (combined) {
            used = append_wide(combined, capacity, 0, previous);
            used = append_wide(combined, capacity, used, u"\r\n\r\n");
            append_wide(combined, capacity, used, message);
            SetWindowTextW(ide.output, combined);
            release(combined);
        } else {
            SetWindowTextW(ide.output, message);
        }
    } else {
        SetWindowTextW(ide.output, message);
    }
    LResult first = SendMessageW(ide.editor, EM_LINEINDEX, (WParam)(diagnostic->line - 1), 0);
    if (first >= 0) {
        LResult length = SendMessageW(ide.editor, EM_LINELENGTH, (WParam)first, 0);
        LResult column = diagnostic->column - 1;
        if (column > length) column = length;
        SetFocus(ide.editor);
        SendMessageW(ide.editor, EM_SETSEL, (WParam)(first + column),
                     first + column + (column < length ? 1 : 0));
        SendMessageW(ide.editor, EM_SCROLLCARET, 0, 0);
    }
}

static void run_document(void) {
    char *source = editor_source();
    Output output = {0};
    output.capacity = OUTPUT_CAPACITY;
    output.bytes = allocate(output.capacity);
    if (!source || !output.bytes) {
        release(source);
        release(output.bytes);
        show_error(u"実行に必要なメモリを確保できませんでした。");
        return;
    }

    KHDiagnostic diagnostic;
    int ok = kh_run(source, receive_output, &output, &diagnostic);
    WCHAR *visible = utf8_as_edit_text(output.bytes, (int)output.length);
    release(output.bytes);
    release(source);
    if (!visible) {
        show_error(u"実行結果を表示できませんでした。");
        return;
    }
    if (ok) {
        SetWindowTextW(ide.output, output.lines ? visible : u"出力はありません。");
        status(u"実行完了");
    } else {
        show_diagnostic(&diagnostic, visible);
    }
    release(visible);
}

static void propose_name(WCHAR *path, const WCHAR *fallback, const WCHAR *extension) {
    const WCHAR *name = *ide.file_path ? basename(ide.file_path) : fallback;
    size_t used = append_wide(path, PATH_CAPACITY, 0, name);
    if (has_extension(path, u".kh")) used -= 3;
    append_wide(path, PATH_CAPACITY, used, extension);
}

static void build_document(void) {
    char *source = editor_source();
    if (!source) {
        show_error(u"ビルドに必要なメモリを確保できませんでした。");
        return;
    }

    KHDiagnostic diagnostic;
    if (!kh_check(source, &diagnostic)) {
        show_diagnostic(&diagnostic, u"");
        release(source);
        return;
    }

    WCHAR *path = allocate(PATH_CAPACITY * sizeof(WCHAR));
    if (!path) {
        release(source);
        show_error(u"保存先を選ぶためのメモリを確保できませんでした。");
        return;
    }
    propose_name(path, u"program", u".exe");
    if (select_path(path, 1, PATH_EXECUTABLE)) {
        if (!has_extension(path, u".exe")) {
            show_error(u"ファイル名の末尾を .exe にしてください。");
        } else {
            char error[512] = {0};
            if (kh_build_exe(source, path, error, sizeof error)) {
                size_t capacity = wide_length(path) + 100;
                WCHAR *message = allocate(capacity * sizeof(WCHAR));
                if (message) {
                    size_t used = append_wide(message, capacity, 0, u"実行ファイルを作成しました。\r\n");
                    append_wide(message, capacity, used, path);
                    SetWindowTextW(ide.output, message);
                    release(message);
                }
                status(u"ビルド完了");
            } else {
                WCHAR *message = utf8_as_edit_text(error, (int)narrow_length(error));
                show_error(message && *message ? message : u"実行ファイルを作成できませんでした。");
                release(message);
                status(u"ビルドに失敗しました");
            }
        }
    }
    release(path);
    release(source);
}

static void report_web_output(const WCHAR *path) {
    size_t stem_length = wide_length(path) - 5;
    append_wide(ide.last_index_path, PATH_CAPACITY, 0, path);
    append_wide(ide.last_index_path, PATH_CAPACITY, stem_length, u"-site\\index.html");
    EnableWindow(ide.buttons[ID_WEB_OPEN - ID_NEW], 1);
    size_t capacity = wide_length(ide.last_index_path) + 120;
    WCHAR *message = allocate(capacity * sizeof(WCHAR));
    if (message) {
        size_t used = append_wide(message, capacity, 0, u"HTML・CSS・JavaScript を出力しました。\r\n\r\n");
        used = append_wide(message, capacity, used, ide.last_index_path);
        append_wide(message, capacity, used, u"\r\n\r\n「ブラウザーで開く」で確認できます。");
        SetWindowTextW(ide.output, message);
        release(message);
    }
    status(u"HTML 出力完了");
}

static void export_web_document(void) {
    char *source = editor_source();
    WCHAR *path = allocate(PATH_CAPACITY * sizeof(WCHAR));
    if (!source || !path) {
        show_error(u"HTML 出力に必要なメモリを確保できませんでした。");
    } else {
        propose_name(path, u"homepage", u".html");
        if (select_path(path, 1, PATH_WEBSITE)) {
            if (!has_extension(path, u".html")) {
                show_error(u"出力名の末尾を .html にしてください。");
            } else {
                KHDiagnostic diagnostic = {0};
                char error[512] = {0};
                if (kh_export_site(source, ide.file_path, path, &diagnostic, error, sizeof error)) {
                    report_web_output(path);
                } else if (diagnostic.line > 0) {
                    show_diagnostic(&diagnostic, u"");
                } else {
                    WCHAR *message = utf8_as_edit_text(error, (int)narrow_length(error));
                    show_error(message && *message ? message : u"HTML を出力できませんでした。");
                    release(message);
                    status(u"HTML 出力に失敗しました");
                }
            }
        }
    }
    release(path);
    release(source);
}

static void open_web_output(void) {
    if (!*ide.last_index_path) return;
    Handle result = ShellExecuteW(ide.window, u"open", ide.last_index_path, 0, 0, 1);
    if ((intptr_t)result <= 32) show_error(u"ブラウザーで開けませんでした。出力先の index.html を確認してください。");
}

static void action(unsigned id) {
    switch (id) {
        case ID_NEW:
            if (confirm_replacement()) load_document(u"", u"", 0);
            break;
        case ID_OPEN: open_document(); break;
        case ID_SAVE: save_document(0); break;
        case ID_SAVE_AS: save_document(1); break;
        case ID_RUN: run_document(); break;
        case ID_BUILD: build_document(); break;
        case ID_WEB_SAMPLE:
            if (confirm_replacement()) load_document(web_sample, u"", 0);
            break;
        case ID_WEB_EXPORT: export_web_document(); break;
        case ID_WEB_OPEN: open_web_output(); break;
    }
}

static Handle control(DWord ex_style, const WCHAR *class, const WCHAR *text, DWord style, int id) {
    Handle result = CreateWindowExW(ex_style, class, text, WS_CHILD | WS_VISIBLE | style,
                                    0, 0, 0, 0, ide.window, (Handle)(intptr_t)id, ide.instance, 0);
    if (result) SendMessageW(result, WM_SETFONT, (WParam)ide.interface_font, 0);
    return result;
}

static void place(Handle control_window, int x, int y, int width, int height) {
    MoveWindow(control_window, x, y, width > 0 ? width : 1, height > 0 ? height : 1, 1);
}

static void layout(void) {
    Rect area;
    if (!GetClientRect(ide.window, &area)) return;
    int width = area.right;
    int height = area.bottom;
    int width_inside = width - 36;
    int split = width >= 775;
    static const int button_widths[] = {60, 60, 60, 130, 78, 110, 101, 106, 145};

    place(ide.title, 18, 11, 200, 34);
    place(ide.path, 233, 14, width - 251, 25);
    int x = 18;
    int y = 53;
    for (int index = 0; index < ACTION_COUNT; index++) {
        if (x + button_widths[index] > width - 18) {
            x = 18;
            y += 40;
        }
        place(ide.buttons[index], x, y, button_widths[index], 34);
        x += button_widths[index] + 6;
    }
    int labels_top = y + 47;
    int panes_top = labels_top + 26;
    if (split) {
        int editor_width = width_inside * 3 / 5;
        int output_left = 30 + editor_width;
        int output_width = width - output_left - 18;
        place(ide.editor_label, 18, labels_top, editor_width, 24);
        place(ide.output_label, output_left, labels_top, output_width, 24);
        place(ide.editor, 18, panes_top, editor_width, height - panes_top - 39);
        place(ide.output, output_left, panes_top, output_width, height - panes_top - 39);
    } else {
        int output_height = (height - panes_top - 58) / 3;
        if (output_height < 88) output_height = 88;
        int output_top = height - 39 - output_height;
        place(ide.editor_label, 18, labels_top, width_inside, 24);
        place(ide.editor, 18, panes_top, width_inside, output_top - panes_top - 36);
        place(ide.output_label, 18, output_top - 30, width_inside, 24);
        place(ide.output, 18, output_top, width_inside, output_height);
    }
    place(ide.status, 18, height - 30, width_inside, 22);
}

static int create_controls(void) {
    ide.interface_font = CreateFontW(-16, 0, 0, 0, 400, 0, 0, 0, 1, 0, 0, 5, 0, u"Yu Gothic UI");
    ide.title_font = CreateFontW(-25, 0, 0, 0, 700, 0, 0, 0, 1, 0, 0, 5, 0, u"Yu Gothic UI");
    ide.code_font = CreateFontW(-17, 0, 0, 0, 400, 0, 0, 0, 1, 0, 0, 5, 0, u"Consolas");
    Handle fallback = GetStockObject(17);
    if (!ide.interface_font) ide.interface_font = fallback;
    if (!ide.title_font) ide.title_font = fallback;
    if (!ide.code_font) ide.code_font = fallback;

    ide.title = control(0, u"STATIC", app_title, SS_CENTERIMAGE, 0);
    ide.path = control(0, u"STATIC", u"", SS_CENTERIMAGE | SS_PATHELLIPSIS, 0);
    ide.editor_label = control(0, u"STATIC", u"スクリプト", SS_CENTERIMAGE, 0);
    ide.output_label = control(0, u"STATIC", u"出力と診断", SS_CENTERIMAGE, 0);
    ide.status = control(0, u"STATIC", u"", SS_CENTERIMAGE, 0);
    static const WCHAR *const captions[] = {
        u"新規", u"開く", u"保存", u"別名で保存", u"実行 F5", u"EXEビルド F7",
        u"Webサンプル", u"HTML出力 F8", u"ブラウザーで開く"
    };
    for (int index = 0; index < ACTION_COUNT; index++) {
        DWord style = WS_TABSTOP | (index == ID_WEB_EXPORT - ID_NEW ? BS_DEFPUSHBUTTON : 0);
        ide.buttons[index] = control(0, u"BUTTON", captions[index], style, ID_NEW + index);
        if (!ide.buttons[index]) return 0;
    }
    EnableWindow(ide.buttons[ID_WEB_OPEN - ID_NEW], 0);
    ide.editor = control(WS_EX_CLIENTEDGE, u"EDIT", u"",
        WS_TABSTOP | WS_VSCROLL | WS_HSCROLL | ES_MULTILINE | ES_AUTOVSCROLL |
        ES_AUTOHSCROLL | ES_NOHIDESEL | ES_WANTRETURN, ID_EDITOR);
    ide.output = control(WS_EX_CLIENTEDGE, u"EDIT", u"",
        WS_TABSTOP | WS_VSCROLL | ES_MULTILINE | ES_AUTOVSCROLL | ES_READONLY, 0);
    if (!ide.title || !ide.path || !ide.editor_label || !ide.output_label ||
        !ide.status || !ide.editor || !ide.output) return 0;
    SendMessageW(ide.title, WM_SETFONT, (WParam)ide.title_font, 0);
    SendMessageW(ide.editor, WM_SETFONT, (WParam)ide.code_font, 0);
    SendMessageW(ide.output, WM_SETFONT, (WParam)ide.code_font, 0);
    SendMessageW(ide.editor, EM_SETLIMITTEXT, EDIT_LIMIT, 0);
    return 1;
}

static LResult window_proc(Handle window, unsigned message, WParam wparam, LParam lparam) {
    switch (message) {
        case WM_CREATE:
            ide.window = window;
            if (!create_controls()) return -1;
            load_document(web_sample, u"", 0);
            return 0;
        case WM_SIZE:
            if (ide.editor) layout();
            return 0;
        case WM_GETMINMAXINFO: {
            int32_t *metrics = (int32_t *)lparam;
            metrics[6] = 606;
            metrics[7] = 510;
            return 0;
        }
        case WM_COMMAND: {
            unsigned id = (unsigned)(wparam & 0xffffu);
            unsigned notice = (unsigned)((wparam >> 16) & 0xffffu);
            if (id == ID_EDITOR && notice == EN_CHANGE && !ide.loading) {
                if (!ide.dirty) {
                    ide.dirty = 1;
                    update_filename();
                }
                status(u"未保存の変更があります");
                return 0;
            }
            if (id >= ID_NEW && id <= ID_WEB_OPEN && !notice) {
                action(id);
                return 0;
            }
            break;
        }
        case WM_CTLCOLORSTATIC:
            if ((Handle)lparam == ide.output) {
                SetBkColor((Handle)wparam, COLOR(26, 37, 47));
                SetTextColor((Handle)wparam, COLOR(227, 237, 242));
                return (LResult)ide.output_brush;
            }
            SetBkColor((Handle)wparam, COLOR(241, 245, 248));
            SetTextColor((Handle)wparam, COLOR(30, 49, 65));
            return (LResult)ide.page_brush;
        case WM_CLOSE:
            if (confirm_replacement()) DestroyWindow(window);
            return 0;
        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
    }
    return DefWindowProcW(window, message, wparam, lparam);
}

static int shortcut(const Message *message) {
    if (message->message != WM_KEYDOWN) return 0;
    if (message->wparam == 0x74) { action(ID_RUN); return 1; }
    if (message->wparam == 0x76) { action(ID_BUILD); return 1; }
    if (message->wparam == 0x77) { action(ID_WEB_EXPORT); return 1; }
    if (GetKeyState(0x11) >= 0) return 0;
    switch (message->wparam) {
        case 'N': action(ID_NEW); return 1;
        case 'O': action(ID_OPEN); return 1;
        case 'S': action(GetKeyState(0x10) < 0 ? ID_SAVE_AS : ID_SAVE); return 1;
    }
    return 0;
}

void kh_ide_main(void) {
    ide.instance = GetModuleHandleW(0);
    ide.page_brush = CreateSolidBrush(COLOR(241, 245, 248));
    ide.output_brush = CreateSolidBrush(COLOR(26, 37, 47));
    WindowClass window_class = {0};
    window_class.size = sizeof window_class;
    window_class.procedure = window_proc;
    window_class.instance = ide.instance;
    window_class.icon = LoadIconW(0, SYSTEM_APPLICATION_ICON);
    window_class.cursor = LoadCursorW(0, SYSTEM_ARROW_CURSOR);
    window_class.background = ide.page_brush;
    window_class.class_name = class_name;
    if (!RegisterClassExW(&window_class)) {
        show_error(u"KH言語 IDE を起動できませんでした。");
        ExitProcess(1);
        return;
    }
    Handle window = CreateWindowExW(0, class_name, app_title,
        WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN, DEFAULT_WINDOW_POSITION, DEFAULT_WINDOW_POSITION,
        1060, 700, 0, 0, ide.instance, 0);
    if (!window) {
        show_error(u"KH言語 IDE のウィンドウを作成できませんでした。");
        ExitProcess(1);
        return;
    }
    ShowWindow(window, 1);
    UpdateWindow(window);
    SetFocus(ide.editor);
    Message message = {0};
    int result;
    while ((result = GetMessageW(&message, 0, 0, 0)) > 0) {
        if (!shortcut(&message)) {
            TranslateMessage(&message);
            DispatchMessageW(&message);
        }
    }
    ExitProcess(result < 0 ? 1 : (unsigned)message.wparam);
}
