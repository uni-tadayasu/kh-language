document.addEventListener('click', (event) => {
  if (!(event.target instanceof Element)) return;
  const button = event.target.closest('[data-kh-message]');
  if (!button) return;
  const result = button.nextElementSibling;
  if (result?.classList.contains('kh-result')) {
    result.hidden = false;
    result.textContent = button.dataset.khMessage;
  }
});
