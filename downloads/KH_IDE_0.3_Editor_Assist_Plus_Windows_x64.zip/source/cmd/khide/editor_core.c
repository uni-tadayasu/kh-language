#include "editor_core.h"

#include <stdint.h>

#include "../../internal/lang_unicode.inc"

typedef unsigned short Unit;

typedef struct {
    const Unit *text;
    size_t length;
    size_t offset;
    int starts_line;
    int expects_function;
} Scanner;

typedef struct {
    size_t start;
    size_t end;
    enum KHHighlight kind;
    int closed_string;
} Token;

typedef struct {
    const char *name;
    enum KHHighlight kind;
} Vocabulary;

static const Vocabulary vocabulary[] = {
    {"and", KH_HIGHLIGHT_KEYWORD},
    {"button", KH_HIGHLIGHT_BUILTIN},
    {"css", KH_HIGHLIGHT_BUILTIN},
    {"else", KH_HIGHLIGHT_KEYWORD},
    {"end", KH_HIGHLIGHT_KEYWORD},
    {"false", KH_HIGHLIGHT_KEYWORD},
    {"function", KH_HIGHLIGHT_KEYWORD},
    {"heading", KH_HIGHLIGHT_BUILTIN},
    {"if", KH_HIGHLIGHT_KEYWORD},
    {"image", KH_HIGHLIGHT_BUILTIN},
    {"language", KH_HIGHLIGHT_BUILTIN},
    {"link", KH_HIGHLIGHT_BUILTIN},
    {"not", KH_HIGHLIGHT_KEYWORD},
    {"or", KH_HIGHLIGHT_KEYWORD},
    {"page", KH_HIGHLIGHT_BUILTIN},
    {"repeat", KH_HIGHLIGHT_KEYWORD},
    {"return", KH_HIGHLIGHT_KEYWORD},
    {"say", KH_HIGHLIGHT_KEYWORD},
    {"script", KH_HIGHLIGHT_BUILTIN},
    {"section", KH_HIGHLIGHT_BUILTIN},
    {"section_end", KH_HIGHLIGHT_BUILTIN},
    {"text", KH_HIGHLIGHT_BUILTIN},
    {"theme", KH_HIGHLIGHT_BUILTIN},
    {"true", KH_HIGHLIGHT_KEYWORD},
    {"use", KH_HIGHLIGHT_KEYWORD},
};

#define ITEM_COUNT(array) (sizeof(array) / sizeof((array)[0]))

static int low_surrogate(Unit unit) {
    return unit >= 0xdc00 && unit <= 0xdfff;
}

static int high_surrogate(Unit unit) {
    return unit >= 0xd800 && unit <= 0xdbff;
}

static uint32_t rune_at(const Unit *text, size_t length, size_t offset, size_t *width) {
    Unit first = text[offset];
    *width = 1;
    if (high_surrogate(first) && offset + 1 < length && low_surrogate(text[offset + 1])) {
        *width = 2;
        return 0x10000u + ((uint32_t)(first - 0xd800) << 10) + (text[offset + 1] - 0xdc00);
    }
    return first;
}

static int in_ranges(uint32_t code, const uint32_t ranges[][2], size_t count) {
    size_t start = 0;
    while (start < count) {
        size_t middle = start + (count - start) / 2;
        if (code < ranges[middle][0]) count = middle;
        else if (code > ranges[middle][1]) start = middle + 1;
        else return 1;
    }
    return 0;
}

static int identifier_start(uint32_t code) {
    if (code < 128) return code == '_' || (code >= 'a' && code <= 'z') ||
        (code >= 'A' && code <= 'Z');
    return in_ranges(code, id_start_ranges, ITEM_COUNT(id_start_ranges));
}

static int digit(uint32_t code) {
    return code >= '0' && code <= '9';
}

static int identifier_continue(uint32_t code) {
    if (code < 128) return identifier_start(code) || digit(code);
    return in_ranges(code, id_continue_ranges, ITEM_COUNT(id_continue_ranges));
}

static int newline(Unit unit) {
    return unit == '\r' || unit == '\n';
}

static int whitespace(Unit unit) {
    return (unit >= 9 && unit <= 13) || unit == ' ' || unit == 0xa0 ||
        unit == 0x1680 || (unit >= 0x2000 && unit <= 0x200a) ||
        unit == 0x2028 || unit == 0x2029 || unit == 0x202f ||
        unit == 0x205f || unit == 0x3000 || unit == 0xfeff;
}

static int compare_word(const Unit *text, size_t length, const char *word) {
    size_t index = 0;
    while (index < length && word[index]) {
        if (text[index] != (Unit)(unsigned char)word[index])
            return (int)text[index] - (unsigned char)word[index];
        index++;
    }
    if (index < length) return 1;
    return word[index] ? -1 : 0;
}

static const Vocabulary *lookup(const Unit *text, size_t length) {
    size_t start = 0;
    size_t end = ITEM_COUNT(vocabulary);
    while (start < end) {
        size_t middle = start + (end - start) / 2;
        int comparison = compare_word(text, length, vocabulary[middle].name);
        if (comparison < 0) end = middle;
        else if (comparison > 0) start = middle + 1;
        else return &vocabulary[middle];
    }
    return NULL;
}

static size_t following_unit(const Unit *text, size_t length, size_t offset) {
    while (offset < length && !newline(text[offset]) && whitespace(text[offset])) offset++;
    return offset;
}

static int operator_unit(Unit unit) {
    const char symbols[] = "=+-*/%()<>,";
    for (size_t index = 0; index + 1 < sizeof(symbols); index++) {
        if (unit == (Unit)symbols[index]) return 1;
    }
    return 0;
}

static enum KHHighlight classify_name(Scanner *scanner, size_t start, size_t end) {
    const Unit *text = scanner->text;
    const Vocabulary *entry = lookup(text + start, end - start);
    int is_use = entry && compare_word(text + start, end - start, "use") == 0;
    size_t following = following_unit(text, scanner->length, end);
    Unit next = following < scanner->length ? text[following] : 0;
    if (is_use && scanner->starts_line && next != '=' && next != '(')
        return KH_HIGHLIGHT_KEYWORD;
    if (entry && entry->kind == KH_HIGHLIGHT_KEYWORD && !is_use)
        return KH_HIGHLIGHT_KEYWORD;
    if (scanner->expects_function) return KH_HIGHLIGHT_FUNCTION;
    if (next == '(') return entry && entry->kind == KH_HIGHLIGHT_BUILTIN ?
        KH_HIGHLIGHT_BUILTIN : KH_HIGHLIGHT_FUNCTION;
    return KH_HIGHLIGHT_IDENTIFIER;
}

static int next_token(Scanner *scanner, Token *token) {
    const Unit *text = scanner->text;
    size_t length = scanner->length;
    size_t at = scanner->offset;
    while (at < length && whitespace(text[at])) {
        if (newline(text[at])) {
            scanner->starts_line = 1;
            scanner->expects_function = 0;
        }
        at++;
    }
    if (at == length) {
        scanner->offset = at;
        return 0;
    }

    size_t width;
    uint32_t code = rune_at(text, length, at, &width);
    *token = (Token){.start = at, .kind = KH_HIGHLIGHT_PLAIN};
    if (code == '#') {
        while (at < length && !newline(text[at])) at++;
        token->kind = KH_HIGHLIGHT_COMMENT;
    } else if (code == '"') {
        at++;
        while (at < length && !newline(text[at])) {
            Unit unit = text[at++];
            if (unit == '"') {
                token->closed_string = 1;
                break;
            }
            if (unit == '\\' && at < length && !newline(text[at])) at++;
        }
        token->kind = KH_HIGHLIGHT_STRING;
    } else if (digit(code) || (code == '.' && at + 1 < length && digit(text[at + 1]))) {
        while (at < length && digit(text[at])) at++;
        if (at < length && text[at] == '.') {
            at++;
            while (at < length && digit(text[at])) at++;
        }
        token->kind = KH_HIGHLIGHT_NUMBER;
    } else if (identifier_start(code)) {
        at += width;
        while (at < length && identifier_continue(rune_at(text, length, at, &width))) at += width;
        token->kind = classify_name(scanner, token->start, at);
    } else {
        at += width;
        if ((code == '=' || code == '!' || code == '<' || code == '>') &&
            at < length && text[at] == '=') {
            at++;
            token->kind = KH_HIGHLIGHT_OPERATOR;
        } else if (code == '<' || code == '>' || (code < 128 && operator_unit((Unit)code))) {
            token->kind = KH_HIGHLIGHT_OPERATOR;
        }
    }
    token->end = at;
    scanner->offset = at;
    scanner->starts_line = 0;
    scanner->expects_function = token->kind == KH_HIGHLIGHT_KEYWORD &&
        compare_word(text + token->start, at - token->start, "function") == 0;
    return 1;
}

void kh_editor_highlight(const Unit *text, size_t length,
    void (*span)(size_t start, size_t length, enum KHHighlight kind, void *context),
    void *context) {
    if (!text || !span) return;
    Scanner scanner = {.text = text, .length = length, .starts_line = 1};
    Token token;
    while (next_token(&scanner, &token)) {
        if (token.kind != KH_HIGHLIGHT_PLAIN)
            span(token.start, token.end - token.start, token.kind, context);
    }
}

static int starts_with(const Unit *text, size_t length, const Unit *prefix, size_t prefix_length) {
    if (prefix_length > length) return 0;
    for (size_t index = 0; index < prefix_length; index++) {
        if (text[index] != prefix[index]) return 0;
    }
    return 1;
}

static int name_token(enum KHHighlight kind) {
    return kind == KH_HIGHLIGHT_IDENTIFIER || kind == KH_HIGHLIGHT_FUNCTION ||
        kind == KH_HIGHLIGHT_BUILTIN || kind == KH_HIGHLIGHT_KEYWORD;
}

static int suppressed(Token token, size_t caret) {
    if (caret <= token.start || caret > token.end) return 0;
    return token.kind == KH_HIGHLIGHT_COMMENT || token.kind == KH_HIGHLIGHT_NUMBER ||
        (token.kind == KH_HIGHLIGHT_STRING && (caret < token.end || !token.closed_string));
}

static void offer(KHCompletion *items, size_t *count, size_t capacity, const Unit *text,
    size_t length, enum KHHighlight kind) {
    if (!length || length >= ITEM_COUNT(items[0].text)) return;
    for (size_t index = 0; index < *count; index++) {
        if (starts_with(items[index].text, ITEM_COUNT(items[index].text), text, length) &&
            items[index].text[length] == 0) {
            if (kind == KH_HIGHLIGHT_FUNCTION && items[index].kind == KH_HIGHLIGHT_IDENTIFIER)
                items[index].kind = kind;
            return;
        }
    }
    if (*count == capacity) return;
    KHCompletion *item = &items[(*count)++];
    for (size_t index = 0; index < length; index++) item->text[index] = text[index];
    item->text[length] = 0;
    item->kind = kind;
}

size_t kh_editor_complete(const Unit *text, size_t length, size_t caret,
    KHCompletion *items, size_t capacity, size_t *replace_start, size_t *replace_end) {
    if (caret > length) caret = length;
    if (replace_start) *replace_start = caret;
    if (replace_end) *replace_end = caret;
    if (!text || !items || !capacity) return 0;
    if (caret && caret < length && low_surrogate(text[caret]) && high_surrogate(text[caret - 1])) return 0;

    size_t line_start = caret;
    while (line_start && !newline(text[line_start - 1])) line_start--;
    Scanner line = {.text = text, .length = length, .offset = line_start, .starts_line = 1};
    Token token;
    size_t start = caret;
    size_t end = caret;
    while (next_token(&line, &token) && token.start <= caret) {
        if (suppressed(token, caret)) return 0;
        if (name_token(token.kind) && caret <= token.end) {
            start = token.start;
            end = token.end;
            break;
        }
    }
    if (replace_start) *replace_start = start;
    if (replace_end) *replace_end = end;
    size_t prefix_length = caret - start;
    if (prefix_length >= ITEM_COUNT(items[0].text)) return 0;

    size_t count = 0;
    for (size_t index = 0; index < ITEM_COUNT(vocabulary) && count < capacity; index++) {
        const Vocabulary *entry = &vocabulary[index];
        Unit word[80];
        size_t word_length = 0;
        while (entry->name[word_length]) {
            word[word_length] = (Unit)entry->name[word_length];
            word_length++;
        }
        if (starts_with(word, word_length, text + start, prefix_length))
            offer(items, &count, capacity, word, word_length, entry->kind);
    }
    if (count == capacity) return count;

    Scanner document = {.text = text, .length = length, .starts_line = 1};
    while (next_token(&document, &token)) {
        if ((token.kind != KH_HIGHLIGHT_IDENTIFIER && token.kind != KH_HIGHLIGHT_FUNCTION) ||
            (token.start == start && token.end == end)) continue;
        size_t name_length = token.end - token.start;
        if (starts_with(text + token.start, name_length, text + start, prefix_length))
            offer(items, &count, capacity, text + token.start, name_length, token.kind);
        if (count == capacity) break;
    }
    return count;
}
