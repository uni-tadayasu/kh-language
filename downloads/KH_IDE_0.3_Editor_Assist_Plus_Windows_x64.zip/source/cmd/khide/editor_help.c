#include "editor_help.h"

#define UNITS(literal) (sizeof(literal) / sizeof((literal)[0]) - 1)
#define SNIPPET(before, selection, after) \
    before selection after, UNITS(before), UNITS(selection)
#define NO_SNIPPET NULL, 0, 0

static const KHEditorHelp entries[] = {
    {u"say", u"say 値",
     u"式を評価し、コンソールへ1行表示します。文字列・数値・真偽値などを表示できます。",
     SNIPPET(u"say \"", u"こんにちは", u"\"")},
    {u"if", u"if 条件\n  命令\nend",
     u"条件が true のときに中の命令を実行します。条件は真偽値で、最後に end が必要です。",
     SNIPPET(u"if ", u"true", u"\n  say \"条件を満たしました\"\nend")},
    {u"else", u"if 条件\n  命令\nelse\n  命令\nend",
     u"if の条件が false のときに実行する命令を指定します。1つの if に1回まで書けます。",
     NO_SNIPPET},
    {u"repeat", u"repeat 回数\n  命令\nend",
     u"中の命令を指定した回数だけ繰り返します。回数は0〜10,000の整数です。",
     SNIPPET(u"repeat ", u"3", u"\n  say \"繰り返し\"\nend")},
    {u"function", u"function 名前(引数)\n  return 値\nend",
     u"呼び出して再利用できる関数を定義します。名前や引数には日本語を使えます。",
     SNIPPET(u"function ", u"関数名", u"(引数)\n  return 引数\nend")},
    {u"return", u"return 値",
     u"関数の実行を終了し、呼び出し元へ値を返します。値を省略すると null を返します。",
     SNIPPET(u"return ", u"0", u"")},
    {u"end", u"end",
     u"if、repeat、function のブロックを閉じます。",
     NO_SNIPPET},
    {u"true", u"true",
     u"真を表す値です。if の条件や論理演算に使えます。",
     NO_SNIPPET},
    {u"false", u"false",
     u"偽を表す値です。if の条件や論理演算に使えます。",
     NO_SNIPPET},
    {u"and", u"条件A and 条件B",
     u"両方の条件が true のときに true になります。左が false なら右の式は評価しません。",
     NO_SNIPPET},
    {u"or", u"条件A or 条件B",
     u"どちらかの条件が true のときに true になります。左が true なら右の式は評価しません。",
     NO_SNIPPET},
    {u"not", u"not 条件",
     u"条件の真偽を反転します。true は false、false は true になります。",
     NO_SNIPPET},
    {u"use", u"use \"ファイル名.kh\"",
     u"Web出力時に、同じフォルダーにある .kh をこの位置に読み込みます。1行に1つ書きます。",
     SNIPPET(u"use \"", u"style.kh", u"\"")},

    {u"page", u"page(題名, 説明)\npage(ファイル名, 題名, 説明)",
     u"Webページを作ります。ファイル名を省略すると index.html が作られます。",
     SNIPPET(u"page(\"", u"ページ名", u"\", \"ページの説明\")")},
    {u"heading", u"heading(見出し)",
     u"現在のページに見出しを追加します。セクション内では小見出しになります。",
     SNIPPET(u"heading(\"", u"見出し", u"\")")},
    {u"text", u"text(本文)",
     u"現在のページに本文の段落を追加します。",
     SNIPPET(u"text(\"", u"本文", u"\")")},
    {u"link", u"link(表示名, URL)",
     u"現在のページにリンクを追加します。URLは別ページのファイル名や https:// などを指定できます。",
     SNIPPET(u"link(\"", u"リンク名", u"\", \"about.html\")")},
    {u"image", u"image(画像URL, 代替テキスト)",
     u"Web出力時に画像と代替テキストを追加します。画像ファイルは参照先に用意します。",
     SNIPPET(u"image(\"", u"image.png", u"\", \"画像の説明\")")},
    {u"section", u"section(題名)\n  命令\nsection_end()",
     u"現在のページに内容をまとめる区画を作ります。区画は section_end() で閉じます。",
     SNIPPET(u"section(\"", u"セクション名", u"\")\n  text(\"本文\")\nsection_end()")},
    {u"section_end", u"section_end()",
     u"直近の開いている section を閉じます。引数はありません。",
     SNIPPET(u"section_end()", u"", u"")},
    {u"button", u"button(ボタン名, メッセージ)",
     u"押すとメッセージが表示されるボタンを追加します。",
     SNIPPET(u"button(\"", u"ボタン名", u"\", \"メッセージ\")")},
    {u"theme", u"theme(\"#RRGGBB\")",
     u"Webサイト共通のアクセント色を、#に続く6桁の16進数で指定します。",
     SNIPPET(u"theme(\"", u"#176b58", u"\")")},
    {u"language", u"language(\"ja\")",
     u"Webサイトのページの言語を指定します。たとえば日本語は ja、英語は en です。",
     SNIPPET(u"language(\"", u"ja", u"\")")},
    {u"css", u"css(CSSの文字列)",
     u"Web出力時にスタイルを追加します。指定した文字列は styles.css に入ります。",
     SNIPPET(u"css(\"", u"body { color: #222; }", u"\")")},
    {u"script", u"script(JavaScriptの文字列)",
     u"Web出力時にJavaScriptを追加します。指定した文字列は app.js に入り、ブラウザーで実行されます。",
     SNIPPET(u"script(\"", u"console.log('KH');", u"\")")},

    {u"=", u"名前 = 式", u"式の結果を変数に代入します。等しいかを比べるには == を使います。", NO_SNIPPET},
    {u"==", u"値A == 値B", u"2つの値が等しければ true になります。型が異なる値は等しくなりません。", NO_SNIPPET},
    {u"!=", u"値A != 値B", u"2つの値が等しくなければ true になります。", NO_SNIPPET},
    {u"<", u"数A < 数B", u"左の数が右の数より小さいときに true になります。", NO_SNIPPET},
    {u"<=", u"数A <= 数B", u"左の数が右の数以下のときに true になります。", NO_SNIPPET},
    {u">", u"数A > 数B", u"左の数が右の数より大きいときに true になります。", NO_SNIPPET},
    {u">=", u"数A >= 数B", u"左の数が右の数以上のときに true になります。", NO_SNIPPET},
    {u"+", u"値A + 値B / +数", u"数を加算します。片方が文字列なら連結します。数の前では正の符号を表します。", NO_SNIPPET},
    {u"-", u"数A - 数B / -数", u"左の数から右の数を引きます。数の前では符号を反転します。", NO_SNIPPET},
    {u"*", u"数A * 数B", u"2つの数を掛けます。", NO_SNIPPET},
    {u"/", u"数A / 数B", u"左の数を右の数で割ります。0では割れません。", NO_SNIPPET},
    {u"%", u"数A % 数B", u"左の数を右の数で割った余りを求めます。0では割れません。", NO_SNIPPET},
    {u"(", u"名前(引数) / (式)", u"関数の引数を囲むか、式の計算順を指定します。", NO_SNIPPET},
    {u")", u"名前(引数) / (式)", u"関数の引数や式のかっこを閉じます。", NO_SNIPPET},
    {u",", u"名前(引数A, 引数B)", u"関数の引数や仮引数を区切ります。", NO_SNIPPET},
    {u"#", u"# コメント", u"行末までのコメントを書きます。文字列内の # は通常の文字です。", NO_SNIPPET},
};

const KHEditorHelp *kh_editor_help_lookup(const unsigned short *token, size_t length) {
    if (!token || !length) return NULL;
    for (size_t index = 0; index < sizeof(entries) / sizeof(entries[0]); index++) {
        const unsigned short *name = entries[index].name;
        size_t count = 0;
        while (count < length && name[count] && name[count] == token[count]) count++;
        if (count == length && !name[count]) return &entries[index];
    }
    return NULL;
}
