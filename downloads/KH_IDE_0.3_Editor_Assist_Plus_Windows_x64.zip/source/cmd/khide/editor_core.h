#ifndef KH_EDITOR_CORE_H
#define KH_EDITOR_CORE_H

#include <stddef.h>

enum KHHighlight {
    KH_HIGHLIGHT_PLAIN,
    KH_HIGHLIGHT_KEYWORD,
    KH_HIGHLIGHT_BUILTIN,
    KH_HIGHLIGHT_STRING,
    KH_HIGHLIGHT_COMMENT,
    KH_HIGHLIGHT_NUMBER,
    KH_HIGHLIGHT_FUNCTION,
    KH_HIGHLIGHT_IDENTIFIER,
    KH_HIGHLIGHT_OPERATOR
};

typedef struct {
    unsigned short text[80];
    enum KHHighlight kind;
} KHCompletion;

/* Positions are UTF-16 code units. Gaps between spans use the plain color. */
void kh_editor_highlight(const unsigned short *text, size_t length,
    void (*span)(size_t start, size_t length, enum KHHighlight kind, void *context),
    void *context);

/*
 * Collect vocabulary and document-local names matching the identifier prefix
 * at caret. Return the complete identifier's replacement range, even when the
 * caret is in its middle. Empty prefixes are allowed for manual completion.
 * Names longer than the candidate buffer are skipped, not truncated.
 */
size_t kh_editor_complete(const unsigned short *text, size_t length, size_t caret,
    KHCompletion *items, size_t capacity, size_t *replace_start, size_t *replace_end);

#endif
