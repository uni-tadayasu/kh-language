#ifndef KH_EDITOR_HELP_H
#define KH_EDITOR_HELP_H

#include <stddef.h>

typedef struct {
    const unsigned short *name;
    const unsigned short *signature;
    const unsigned short *description;
    const unsigned short *snippet;
    size_t select_start;
    size_t select_length;
} KHEditorHelp;

/* Looks up an exact, case-sensitive token. Text and selection offsets use UTF-16
   code units. Snippets use LF for line breaks. A null snippet means that
   completion inserts only the name. The returned entry has static lifetime. */
const KHEditorHelp *kh_editor_help_lookup(const unsigned short *token, size_t length);

#endif
