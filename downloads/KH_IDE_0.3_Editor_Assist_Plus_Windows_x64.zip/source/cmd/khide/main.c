#include <stddef.h>
#include <stdint.h>
#include "../../internal/buildexe.h"
#include "../../internal/lang.h"
#include "../../internal/webexport.h"
#include "../../internal/editor_diagnostics.h"
#include "editor_core.h"
#include "editor_help.h"

typedef unsigned short WCHAR;
typedef void *Handle;
typedef uint32_t DWord;
typedef uintptr_t WParam;
typedef intptr_t LParam;
typedef intptr_t LResult;

typedef struct {
    int32_t left, top, right, bottom;
} Rect;

typedef struct { int32_t x, y; } Point;
typedef struct { int32_t first, last; } TextRange;
typedef struct { Handle source; uintptr_t id; unsigned code; } NotifyHeader;
typedef struct {
    DWord capacity, flags, codepage;
    const char *fallback;
    int *used_fallback;
} TextQuery;
typedef struct { DWord flags, codepage; } TextLengthQuery;
typedef struct {
    unsigned size;
    DWord mask, effects;
    int32_t height, offset;
    DWord color;
    unsigned char charset, pitch;
    WCHAR face[32];
    unsigned short padding, weight;
    short spacing;
    DWord background, locale, cookie;
    short style;
    unsigned short kerning;
    unsigned char underline, animation, author, underline_color;
} CharacterFormat;
typedef struct {
    uint32_t first;
    uint16_t second, third;
    unsigned char last[8];
} InterfaceId;
typedef struct {
    int32_t (*query)(void *, const InterfaceId *, void **);
    unsigned (*add_ref)(void *);
    unsigned (*release)(void *);
} UnknownMethods;
typedef struct { const UnknownMethods *methods; } Unknown;
typedef struct {
    UnknownMethods unknown;
    void (*before_freeze[15])(void);
    int32_t (*freeze)(void *, int32_t *);
    int32_t (*unfreeze)(void *, int32_t *);
    void (*begin_collection)(void);
    void (*end_collection)(void);
    int32_t (*undo)(void *, int32_t, int32_t *);
} DocumentMethods;
typedef struct { const DocumentMethods *methods; } RichDocument;

_Static_assert(sizeof(CharacterFormat) == 116, "CHARFORMAT2W layout");
_Static_assert(offsetof(CharacterFormat, underline) == 112, "CHARFORMAT2W underline offset");
_Static_assert(offsetof(DocumentMethods, undo) == 22 * sizeof(void *), "ITextDocument method offset");

typedef struct {
    Handle window;
    unsigned message;
    WParam wparam;
    LParam lparam;
    DWord time;
    int32_t x, y;
    DWord private_value;
} Message;

typedef struct {
    unsigned size;
    unsigned style;
    LResult (*procedure)(Handle, unsigned, WParam, LParam);
    int class_extra;
    int window_extra;
    Handle instance;
    Handle icon;
    Handle cursor;
    Handle background;
    const WCHAR *menu_name;
    const WCHAR *class_name;
    Handle small_icon;
} WindowClass;

typedef struct {
    DWord size;
    Handle owner;
    Handle instance;
    const WCHAR *filter;
    WCHAR *custom_filter;
    DWord max_custom_filter;
    DWord filter_index;
    WCHAR *file;
    DWord max_file;
    WCHAR *file_title;
    DWord max_file_title;
    const WCHAR *initial_dir;
    const WCHAR *title;
    DWord flags;
    unsigned short file_offset;
    unsigned short extension_offset;
    const WCHAR *default_extension;
    LParam custom_data;
    void *hook;
    const WCHAR *template_name;
    void *reserved;
    DWord reserved_flags;
    DWord extended_flags;
} OpenFileName;

_Static_assert(sizeof(Rect) == 16, "RECT layout");
_Static_assert(sizeof(WindowClass) == 80, "WNDCLASSEXW layout");
_Static_assert(sizeof(Message) == 48, "MSG layout");
_Static_assert(sizeof(OpenFileName) == 152, "OPENFILENAMEW layout");

extern void ExitProcess(unsigned code);
extern Handle GetModuleHandleW(const WCHAR *name);
extern Handle LoadLibraryExW(const WCHAR *name, Handle file, DWord flags);
extern int FreeLibrary(Handle module);
extern Handle GetProcessHeap(void);
extern void *HeapAlloc(Handle heap, DWord flags, size_t size);
extern int HeapFree(Handle heap, DWord flags, void *memory);
extern int MultiByteToWideChar(unsigned codepage, DWord flags, const char *text,
                               int count, WCHAR *wide, int capacity);
extern int WideCharToMultiByte(unsigned codepage, DWord flags, const WCHAR *wide,
                               int count, char *text, int capacity,
                               const char *default_char, int *used_default);
extern Handle CreateFileW(const WCHAR *name, DWord access, DWord share,
                          void *security, DWord creation, DWord flags, Handle template_file);
extern int GetFileSizeEx(Handle file, int64_t *size);
extern int ReadFile(Handle file, void *data, DWord size, DWord *read, void *overlapped);
extern int WriteFile(Handle file, const void *data, DWord size, DWord *written, void *overlapped);
extern int CloseHandle(Handle handle);
extern int MoveFileExW(const WCHAR *old_name, const WCHAR *new_name, DWord flags);
extern int DeleteFileW(const WCHAR *name);
extern unsigned GetTempFileNameW(const WCHAR *path, const WCHAR *prefix, unsigned unique, WCHAR *output);

extern unsigned short RegisterClassExW(const WindowClass *window_class);
extern Handle CreateWindowExW(DWord ex_style, const WCHAR *class_name, const WCHAR *name,
                              DWord style, int x, int y, int width, int height,
                              Handle parent, Handle menu, Handle instance, void *param);
extern int ShowWindow(Handle window, int command);
extern int UpdateWindow(Handle window);
extern int GetMessageW(Message *message, Handle window, unsigned first, unsigned last);
extern int TranslateMessage(const Message *message);
extern LResult DispatchMessageW(const Message *message);
extern void PostQuitMessage(int code);
extern LResult DefWindowProcW(Handle window, unsigned message, WParam wparam, LParam lparam);
extern int SetWindowTextW(Handle window, const WCHAR *text);
extern int GetWindowTextW(Handle window, WCHAR *text, int max_count);
extern int GetWindowTextLengthW(Handle window);
extern LResult SendMessageW(Handle window, unsigned message, WParam wparam, LParam lparam);
extern Handle SetFocus(Handle window);
extern int MoveWindow(Handle window, int x, int y, int width, int height, int repaint);
extern int SetWindowPos(Handle window, Handle after, int x, int y, int width, int height, unsigned flags);
extern int GetClientRect(Handle window, Rect *rect);
extern Handle LoadCursorW(Handle instance, const WCHAR *name);
extern Handle LoadIconW(Handle instance, const WCHAR *name);
extern int MessageBoxW(Handle window, const WCHAR *text, const WCHAR *title, unsigned type);
extern int DestroyWindow(Handle window);
extern short GetKeyState(int key);
extern int EnableWindow(Handle window, int enable);
extern Handle GetFocus(void);
extern int GetCursorPos(Point *point);
extern Handle WindowFromPoint(Point point);
extern int MapWindowPoints(Handle from, Handle to, Point *points, unsigned count);
extern int InvalidateRect(Handle window, const Rect *area, int erase);
extern uintptr_t SetTimer(Handle window, uintptr_t id, unsigned milliseconds, void *callback);
extern int KillTimer(Handle window, uintptr_t id);
extern Handle ShellExecuteW(Handle window, const WCHAR *verb, const WCHAR *file,
                            const WCHAR *parameters, const WCHAR *directory, int command);

extern Handle CreateFontW(int height, int width, int escape, int orientation,
                          int weight, DWord italic, DWord underline, DWord strikeout,
                          DWord charset, DWord precision, DWord clip_precision,
                          DWord quality, DWord family, const WCHAR *face);
extern Handle GetStockObject(int object);
extern int DeleteObject(Handle object);
extern DWord SetBkColor(Handle dc, DWord color);
extern DWord SetTextColor(Handle dc, DWord color);
extern Handle CreateSolidBrush(DWord color);

extern int GetOpenFileNameW(OpenFileName *name);
extern int GetSaveFileNameW(OpenFileName *name);
extern DWord CommDlgExtendedError(void);

#define WM_CREATE 0x0001
#define WM_SETREDRAW 0x000b
#define WM_NOTIFY 0x004e
#define WM_TIMER 0x0113
#define WM_MOUSEMOVE 0x0200
#define WM_MOUSEWHEEL 0x020a
#define WM_MOUSEHWHEEL 0x020e
#define WM_IME_STARTCOMPOSITION 0x010d
#define WM_IME_ENDCOMPOSITION 0x010e
#define WM_USER 0x0400
#define SW_HIDE 0
#define SWP_NOACTIVATE 0x0010u
#define SWP_SHOWWINDOW 0x0040u
#define WM_DESTROY 0x0002
#define WM_SIZE 0x0005
#define WM_CLOSE 0x0010
#define WM_GETMINMAXINFO 0x0024
#define WM_SETFONT 0x0030
#define WM_KEYDOWN 0x0100
#define WM_COMMAND 0x0111
#define WM_CTLCOLOREDIT 0x0133
#define WM_CTLCOLORSTATIC 0x0138
#define SIZE_MINIMIZED 1
#define SW_SHOW 5
#define SW_RESTORE 9

#define WS_OVERLAPPEDWINDOW 0x00cf0000u
#define WS_CLIPCHILDREN 0x02000000u
#define WS_VISIBLE 0x10000000u
#define WS_CHILD 0x40000000u
#define WS_VSCROLL 0x00200000u
#define WS_HSCROLL 0x00100000u
#define WS_TABSTOP 0x00010000u
#define WS_EX_CLIENTEDGE 0x00000200u
#define ES_MULTILINE 0x0004u
#define ES_NOOLEDRAGDROP 0x0008u
#define LBS_NOTIFY 0x0001u
#define LBS_NOINTEGRALHEIGHT 0x0100u
#define ES_AUTOVSCROLL 0x0040u
#define ES_AUTOHSCROLL 0x0080u
#define ES_NOHIDESEL 0x0100u
#define ES_READONLY 0x0800u
#define ES_WANTRETURN 0x1000u
#define BS_DEFPUSHBUTTON 1
#define SS_CENTERIMAGE 0x0200
#define SS_NOPREFIX 0x0080u
#define SS_PATHELLIPSIS 0x8000

#define EM_SETSEL 0x00b1
#define EM_SCROLLCARET 0x00b7
#define EM_LINEINDEX 0x00bb
#define EM_LINELENGTH 0x00c1
#define EM_SETLIMITTEXT 0x00c5
#define EM_SETMARGINS 0x00d3
#define EM_GETSEL 0x00b0
#define EM_REPLACESEL 0x00c2
#define EM_POSFROMCHAR 0x00d6
#define EM_CHARFROMPOS 0x00d7
#define EM_EXGETSEL (WM_USER + 52)
#define EM_EXSETSEL (WM_USER + 55)
#define EM_GETOLEINTERFACE (WM_USER + 60)
#define EM_PASTESPECIAL (WM_USER + 64)
#define EM_SETBKGNDCOLOR (WM_USER + 67)
#define EM_SETCHARFORMAT (WM_USER + 68)
#define EM_SETEVENTMASK (WM_USER + 69)
#define EM_EXLIMITTEXT (WM_USER + 53)
#define EM_GETEVENTMASK (WM_USER + 59)
#define EM_GETTEXTEX (WM_USER + 94)
#define EM_GETTEXTLENGTHEX (WM_USER + 95)
#define EM_GETSCROLLPOS (WM_USER + 221)
#define EM_SETSCROLLPOS (WM_USER + 222)
#define EN_SELCHANGE 0x0702u
#define EN_HSCROLL 0x0601u
#define EN_VSCROLL 0x0602u
#define ENM_CHANGE 0x00000001u
#define ENM_SCROLL 0x00000004u
#define ENM_SELCHANGE 0x00080000u
#define LB_ADDSTRING 0x0180
#define LB_RESETCONTENT 0x0184
#define LB_SETCURSEL 0x0186
#define LB_GETCURSEL 0x0188
#define LB_SETITEMHEIGHT 0x01a0
#define LBN_DBLCLK 2
#define CFM_COLOR 0x40000000u
#define CFM_UNDERLINE 0x00000004u
#define CFM_UNDERLINETYPE 0x00800000u
#define CFE_UNDERLINE 0x00000004u
#define GT_RAWTEXT 4u
#define GTL_PRECISE_NUMCHARS 10u
#define CF_UNICODETEXT 13u
#define TOM_SUSPEND (-9999995)
#define TOM_RESUME (-9999994)
#define EDITOR_REFRESH_TIMER 1u
#define EDITOR_COMPLETION_TIMER 2u
#define EDITOR_HOVER_TIMER 3u
#define EDITOR_ANALYSIS_DELAY 230u
#define EDITOR_COMPLETION_DELAY 75u
#define EDITOR_HOVER_DELAY 450u
#define COMPLETION_CAPACITY 48u
#define EN_CHANGE 0x0300u

#define ID_NEW 100
#define ID_OPEN 101
#define ID_SAVE 102
#define ID_SAVE_AS 103
#define ID_RUN 104
#define ID_BUILD 105
#define ID_WEB_SAMPLE 106
#define ID_WEB_EXPORT 107
#define ID_WEB_OPEN 108
#define ID_EDITOR 109
#define ID_REFERENCE 110
#define ID_COMPLETION 111
#define ID_HOVER 112
#define ACTION_COUNT 10

#define OFN_OVERWRITEPROMPT 0x00000002u
#define OFN_HIDEREADONLY 0x00000004u
#define OFN_NOCHANGEDIR 0x00000008u
#define OFN_PATHMUSTEXIST 0x00000800u
#define OFN_FILEMUSTEXIST 0x00001000u
#define OFN_EXPLORER 0x00080000u

#define GENERIC_READ 0x80000000u
#define GENERIC_WRITE 0x40000000u
#define FILE_SHARE_READ 1u
#define OPEN_EXISTING 3u
#define TRUNCATE_EXISTING 5u
#define FILE_ATTRIBUTE_NORMAL 0x80u
#define MOVEFILE_REPLACE_EXISTING 1u
#define MOVEFILE_WRITE_THROUGH 8u

#define MB_ICONERROR 0x10u
#define MB_ICONQUESTION 0x20u
#define MB_YESNOCANCEL 3u
#define MB_DEFBUTTON3 0x200u
#define IDYES 6
#define IDNO 7

#define DEFAULT_WINDOW_POSITION ((int)0x80000000u)
#define SYSTEM_APPLICATION_ICON ((const WCHAR *)(uintptr_t)32512)
#define SYSTEM_ARROW_CURSOR ((const WCHAR *)(uintptr_t)32512)
#define INVALID_HANDLE ((Handle)(intptr_t)-1)
#define EDIT_LIMIT (KH_SOURCE_UNIT_LIMIT * 2)
#define SOURCE_FILE_LIMIT (KH_SOURCE_BYTE_LIMIT + 3)
#define OUTPUT_CAPACITY 2000000
#define PATH_CAPACITY 32768
#define COLOR(red, green, blue) ((DWord)((red) | ((green) << 8) | ((blue) << 16)))

typedef struct {
    Handle instance;
    Handle window;
    Handle title;
    Handle path;
    Handle editor_label;
    Handle output_label;
    Handle editor;
    Handle output;
    Handle status;
    Handle editor_status;
    Handle completion_list;
    Handle hover_tip;
    Handle rich_library;
    RichDocument *rich_document;
    Handle reference_window;
    Handle reference_edit;
    Handle buttons[ACTION_COUNT];
    Handle interface_font;
    Handle title_font;
    Handle code_font;
    Handle page_brush;
    Handle output_brush;
    WCHAR file_path[PATH_CAPACITY];
    WCHAR last_index_path[PATH_CAPACITY];
    int dirty;
    int loading;
    int formatting;
    int composing;
    int applying_completion;
    int hover_state;
    Point hover_point;
    size_t completion_count;
    size_t replace_first, replace_last;
    KHCompletion completions[COMPLETION_CAPACITY];
    KHDiagnostic live_diagnostic;
    int reference_class_registered;
    int reference_minimized;
} Ide;

typedef struct {
    char *bytes;
    size_t length;
    size_t capacity;
    unsigned lines;
} Output;

static Ide ide;
static const WCHAR app_title[] = u"KH言語 IDE 0.3";
static const WCHAR class_name[] = u"KHLanguageIDE";
static const WCHAR reference_class_name[] = u"KHLanguageReference";
static const WCHAR reference_title[] = u"KH言語 IDE - コマンド一覧";
#include "reference_text.inc"
static const WCHAR kh_filter[] = u"KH スクリプト (*.kh)\0*.kh\0すべてのファイル (*.*)\0*.*\0";
static const WCHAR exe_filter[] = u"Windows アプリ (*.exe)\0*.exe\0";
static const WCHAR html_filter[] = u"ホームページ (*.html)\0*.html\0";
static const WCHAR web_sample[] =
    u"# F8 で HTML・CSS・JavaScript を書き出します。\r\n"
    u"サイト名 = \"葛西ウェブ工房\"\r\n"
    u"説明 = \"KH言語で作った、はじめてのホームページです。\"\r\n"
    u"theme(\"#176344\")\r\n"
    u"page(サイト名, 説明)\r\n"
    u"heading(\"ホームページへようこそ\")\r\n"
    u"text(説明)\r\n"
    u"link(\"工房について\", \"about.html\")\r\n"
    u"section(\"できること\")\r\n"
    u"text(\"文章、リンク、ボタンを組み合わせてページを作れます。\")\r\n"
    u"button(\"メッセージを表示\", \"ページを見てくれてありがとう！\")\r\n"
    u"section_end()\r\n"
    u"\r\n"
    u"page(\"about.html\", \"工房について\", \"葛西ウェブ工房の紹介です。\")\r\n"
    u"heading(\"工房について\")\r\n"
    u"text(\"このページも同じ .kh ファイルから作られています。\")\r\n"
    u"link(\"トップへ戻る\", \"index.html\")\r\n";

static void *allocate(size_t size) {
    return HeapAlloc(GetProcessHeap(), 0, size);
}

static void release(void *memory) {
    if (memory) HeapFree(GetProcessHeap(), 0, memory);
}

static size_t wide_length(const WCHAR *text) {
    size_t length = 0;
    while (text[length]) length++;
    return length;
}

static size_t narrow_length(const char *text) {
    size_t length = 0;
    while (text[length]) length++;
    return length;
}

static size_t append_wide(WCHAR *target, size_t capacity, size_t used, const WCHAR *text) {
    while (used + 1 < capacity && *text) target[used++] = *text++;
    target[used] = 0;
    return used;
}

static size_t append_number(WCHAR *target, size_t capacity, size_t used, unsigned value) {
    WCHAR reversed[16];
    size_t count = 0;
    do {
        reversed[count++] = (WCHAR)('0' + value % 10);
        value /= 10;
    } while (value);
    while (count && used + 1 < capacity) target[used++] = reversed[--count];
    target[used] = 0;
    return used;
}

static const WCHAR *basename(const WCHAR *path) {
    const WCHAR *name = path;
    for (const WCHAR *character = path; *character; character++) {
        if (*character == '\\' || *character == '/') name = character + 1;
    }
    return name;
}

static void show_error(const WCHAR *message) {
    MessageBoxW(ide.window, message, app_title, MB_ICONERROR);
}

static void status(const WCHAR *message) {
    SetWindowTextW(ide.status, message);
}

static WCHAR *utf8_as_edit_text(const char *source, int byte_length) {
    if (!byte_length) {
        WCHAR *empty = allocate(sizeof(WCHAR));
        if (empty) empty[0] = 0;
        return empty;
    }
    int count = MultiByteToWideChar(65001, 8, source, byte_length, 0, 0);
    if (count <= 0) return 0;

    WCHAR *wide = allocate((size_t)count * sizeof(WCHAR));
    WCHAR *edit = allocate(((size_t)count * 2 + 1) * sizeof(WCHAR));
    if (!wide || !edit || MultiByteToWideChar(65001, 8, source, byte_length, wide, count) != count) {
        release(wide);
        release(edit);
        return 0;
    }

    size_t used = 0;
    for (int index = 0; index < count; index++) {
        WCHAR character = wide[index];
        if (character == '\r' || character == '\n') {
            if (character == '\r' && index + 1 < count && wide[index + 1] == '\n') index++;
            edit[used++] = '\r';
            edit[used++] = '\n';
        } else {
            edit[used++] = character ? character : 0x2400;
        }
    }
    edit[used] = 0;
    release(wide);
    return edit;
}

static WCHAR *editor_text(size_t *units) {
    int length;
    if (ide.rich_library) {
        const TextLengthQuery query = {GTL_PRECISE_NUMCHARS, 1200};
        length = (int)SendMessageW(ide.editor, EM_GETTEXTLENGTHEX, (WParam)&query, 0);
    } else {
        length = GetWindowTextLengthW(ide.editor);
    }
    if (length < 0 || length > EDIT_LIMIT * 2) return 0;
    WCHAR *wide = allocate(((size_t)length + 1) * sizeof(WCHAR));
    if (!wide) return 0;
    wide[0] = 0;
    if (ide.rich_library) {
        const TextQuery query = {((DWord)length + 1) * sizeof(WCHAR), GT_RAWTEXT, 1200, 0, 0};
        SendMessageW(ide.editor, EM_GETTEXTEX, (WParam)&query, (LParam)wide);
    } else {
        GetWindowTextW(ide.editor, wide, length + 1);
    }
    wide[length] = 0;
    *units = wide_length(wide);
    return wide;
}

static char *source_from_text(WCHAR *wide) {
    size_t cursor = 0;
    for (int index = 0; wide[index]; index++) {
        if (wide[index] == '\r' && wide[index + 1] == '\n') continue;
        wide[cursor++] = wide[index] == '\r' ? '\n' : wide[index];
    }
    wide[cursor] = 0;
    int size = WideCharToMultiByte(65001, 128, wide, -1, 0, 0, 0, 0);
    char *source = size > 0 ? allocate((size_t)size) : 0;
    if (source && !WideCharToMultiByte(65001, 128, wide, -1, source, size, 0, 0)) {
        release(source);
        source = 0;
    }
    return source;
}

static char *editor_source(void) {
    size_t units;
    WCHAR *wide = editor_text(&units);
    if (!wide) return 0;
    char *source = source_from_text(wide);
    release(wide);
    return source;
}

static void refresh_editor(void);
static void schedule_editor_refresh(void);
static void close_completion(void);
static void close_hover(void);

static void update_filename(void) {
    WCHAR title[256];
    size_t used = append_wide(title, 256, 0, app_title);
    used = append_wide(title, 256, used, u"  /  ");
    used = append_wide(title, 256, used, *ide.file_path ? basename(ide.file_path) : u"untitled.kh");
    if (ide.dirty) append_wide(title, 256, used, u"  *");
    SetWindowTextW(ide.window, title);
    SetWindowTextW(ide.path, *ide.file_path ? ide.file_path : u"untitled.kh");
}

static void load_document(const WCHAR *source, const WCHAR *path, int dirty) {
    close_completion();
    close_hover();
    ide.loading = 1;
    SetWindowTextW(ide.editor, source);
    ide.loading = 0;
    append_wide(ide.file_path, PATH_CAPACITY, 0, path);
    ide.dirty = dirty;
    update_filename();
    SetWindowTextW(ide.output, u"Webサイトは F8 で HTML 出力。スクリプトは F5 で実行できます。");
    status(u"編集できます");
    ide.live_diagnostic = (KHDiagnostic){0};
    SetFocus(ide.editor);
    refresh_editor();
}

typedef enum { PATH_SCRIPT, PATH_EXECUTABLE, PATH_WEBSITE } PathKind;

static int select_path(WCHAR *path, int save, PathKind kind) {
    OpenFileName dialog = {0};
    dialog.size = sizeof dialog;
    dialog.owner = ide.window;
    dialog.filter = kind == PATH_WEBSITE ? html_filter : kind == PATH_EXECUTABLE ? exe_filter : kh_filter;
    dialog.filter_index = 1;
    dialog.file = path;
    dialog.max_file = PATH_CAPACITY;
    dialog.default_extension = kind == PATH_WEBSITE ? u"html" : kind == PATH_EXECUTABLE ? u"exe" : u"kh";
    if (kind == PATH_WEBSITE) dialog.title = u"HTML 出力先とサイトフォルダー名を指定";
    else if (kind == PATH_EXECUTABLE) dialog.title = u"実行ファイルの保存先";
    else dialog.title = save ? u"KH スクリプトを保存" : u"KH スクリプトを開く";
    dialog.flags = OFN_EXPLORER | OFN_NOCHANGEDIR | OFN_HIDEREADONLY | OFN_PATHMUSTEXIST;
    if (!save) dialog.flags |= OFN_FILEMUSTEXIST;
    else if (kind != PATH_WEBSITE) dialog.flags |= OFN_OVERWRITEPROMPT;
    int selected = save ? GetSaveFileNameW(&dialog) : GetOpenFileNameW(&dialog);
    if (!selected && CommDlgExtendedError()) show_error(u"ファイル選択画面を開けませんでした。");
    return selected;
}

static int has_extension(const WCHAR *path, const WCHAR *extension) {
    const WCHAR *name = basename(path);
    size_t name_length = wide_length(name);
    size_t ext_length = wide_length(extension);
    if (name_length <= ext_length) return 0;
    name += name_length - ext_length;
    for (size_t index = 0; index < ext_length; index++) {
        WCHAR character = name[index];
        if (character >= 'A' && character <= 'Z') character += 'a' - 'A';
        if (character != extension[index]) return 0;
    }
    return 1;
}

static int write_source(const WCHAR *path, const char *source) {
    WCHAR directory[260];
    WCHAR temp_path[260];
    size_t length = (size_t)(basename(path) - path);
    if (length == 0 || length >= 246) return 0;
    for (size_t index = 0; index < length; index++) directory[index] = path[index];
    directory[length] = 0;
    if (!GetTempFileNameW(directory, u"KH", 0, temp_path)) return 0;

    int saved = 0;
    Handle file = CreateFileW(temp_path, GENERIC_WRITE, 0, 0, TRUNCATE_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
    if (file != INVALID_HANDLE) {
        DWord written = 0;
        DWord size = (DWord)narrow_length(source);
        int result = WriteFile(file, source, size, &written, 0) && written == size;
        int closed = CloseHandle(file);
        saved = result && closed && MoveFileExW(temp_path, path, MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH);
    }
    if (!saved) DeleteFileW(temp_path);
    return saved;
}

static int save_document(int as_new) {
    WCHAR *path = allocate(PATH_CAPACITY * sizeof(WCHAR));
    if (!path) {
        show_error(u"保存に必要なメモリを確保できませんでした。");
        return 0;
    }
    if (as_new || !has_extension(ide.file_path, u".kh")) {
        size_t used = append_wide(path, PATH_CAPACITY, 0, *ide.file_path ? basename(ide.file_path) : u"untitled.kh");
        if (!has_extension(path, u".kh")) append_wide(path, PATH_CAPACITY, used, u".kh");
        if (!select_path(path, 1, PATH_SCRIPT)) {
            release(path);
            return 0;
        }
    } else {
        append_wide(path, PATH_CAPACITY, 0, ide.file_path);
    }
    if (!has_extension(path, u".kh")) {
        show_error(u"ファイル名の末尾を .kh にして保存してください。");
        release(path);
        return 0;
    }
    char *source = editor_source();
    int saved = source && write_source(path, source);
    if (saved) {
        append_wide(ide.file_path, PATH_CAPACITY, 0, path);
        ide.dirty = 0;
        update_filename();
        status(u"KH スクリプトを保存しました");
    } else {
        show_error(u"保存できませんでした。保存先のパスと書き込み権限を確認してください。");
    }
    release(source);
    release(path);
    return saved;
}

static int confirm_replacement(void) {
    if (!ide.dirty) return 1;
    int choice = MessageBoxW(ide.window, u"編集中のスクリプトを保存しますか？",
                             app_title, MB_ICONQUESTION | MB_YESNOCANCEL | MB_DEFBUTTON3);
    if (choice == IDYES) return save_document(0);
    return choice == IDNO;
}

static WCHAR *read_source(const WCHAR *path) {
    Handle file = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
    if (file == INVALID_HANDLE) return 0;
    WCHAR *source = 0;
    int64_t size;
    if (GetFileSizeEx(file, &size) && size >= 0 && size <= SOURCE_FILE_LIMIT) {
        char *bytes = allocate((size_t)size + 1);
        if (bytes) {
            DWord count = 0;
            if (ReadFile(file, bytes, (DWord)size, &count, 0) && count == (DWord)size) {
                unsigned offset = 0;
                if (count >= 3 && (unsigned char)bytes[0] == 0xef &&
                    (unsigned char)bytes[1] == 0xbb && (unsigned char)bytes[2] == 0xbf) offset = 3;
                unsigned check = offset;
                while (check < count && bytes[check]) check++;
                if (check == count) {
                    source = utf8_as_edit_text(bytes + offset, (int)(count - offset));
                    if (source && wide_length(source) > EDIT_LIMIT) {
                        release(source);
                        source = 0;
                    }
                }
            }
            release(bytes);
        }
    }
    CloseHandle(file);
    return source;
}

static void open_document(void) {
    if (!confirm_replacement()) return;
    WCHAR *path = allocate(PATH_CAPACITY * sizeof(WCHAR));
    if (!path) {
        show_error(u"ファイルを開くためのメモリを確保できませんでした。");
        return;
    }
    path[0] = 0;
    if (select_path(path, 0, PATH_SCRIPT)) {
        WCHAR *source = read_source(path);
        if (source) {
            load_document(source, path, 0);
            release(source);
        } else {
            show_error(u"ファイルを読み込めませんでした。UTF-8 で保存したテキストファイルを選んでください。");
        }
    }
    release(path);
}

static void append_output(Output *output, const char *text, size_t length) {
    if (length > output->capacity - output->length) length = output->capacity - output->length;
    for (size_t index = 0; index < length; index++) output->bytes[output->length++] = text[index];
}

static void receive_output(const char *text, size_t length, void *context) {
    Output *output = context;
    if (output->lines++) append_output(output, "\n", 1);
    append_output(output, text, length);
}

static void show_diagnostic(const KHDiagnostic *diagnostic, const WCHAR *previous) {
    WCHAR message[512];
    size_t used = 0;
    used = append_number(message, 512, used, (unsigned)diagnostic->line);
    used = append_wide(message, 512, used, u" 行 ");
    used = append_number(message, 512, used, (unsigned)diagnostic->column);
    used = append_wide(message, 512, used, u" 列  ");
    status(message);
    int remaining = (int)(512 - used);
    if (!MultiByteToWideChar(65001, 0, diagnostic->message, -1, message + used, remaining)) {
        append_wide(message, 512, used, u"コードにエラーがあります。");
    }
    if (*previous) {
        size_t capacity = wide_length(previous) + wide_length(message) + 5;
        WCHAR *combined = allocate(capacity * sizeof(WCHAR));
        if (combined) {
            used = append_wide(combined, capacity, 0, previous);
            used = append_wide(combined, capacity, used, u"\r\n\r\n");
            append_wide(combined, capacity, used, message);
            SetWindowTextW(ide.output, combined);
            release(combined);
        } else {
            SetWindowTextW(ide.output, message);
        }
    } else {
        SetWindowTextW(ide.output, message);
    }
    LResult first = SendMessageW(ide.editor, EM_LINEINDEX, (WParam)(diagnostic->line - 1), 0);
    if (first >= 0) {
        LResult length = SendMessageW(ide.editor, EM_LINELENGTH, (WParam)first, 0);
        LResult column = diagnostic->column - 1;
        if (column > length) column = length;
        SetFocus(ide.editor);
        SendMessageW(ide.editor, EM_SETSEL, (WParam)(first + column),
                     first + column + (column < length ? 1 : 0));
        SendMessageW(ide.editor, EM_SCROLLCARET, 0, 0);
    }
}

static void run_document(void) {
    char *source = editor_source();
    Output output = {0};
    output.capacity = OUTPUT_CAPACITY;
    output.bytes = allocate(output.capacity);
    if (!source || !output.bytes) {
        release(source);
        release(output.bytes);
        show_error(u"実行に必要なメモリを確保できませんでした。");
        return;
    }

    KHDiagnostic diagnostic;
    int ok = kh_run(source, receive_output, &output, &diagnostic);
    WCHAR *visible = utf8_as_edit_text(output.bytes, (int)output.length);
    release(output.bytes);
    release(source);
    if (!visible) {
        show_error(u"実行結果を表示できませんでした。");
        return;
    }
    if (ok) {
        SetWindowTextW(ide.output, output.lines ? visible : u"出力はありません。");
        status(u"実行完了");
    } else {
        show_diagnostic(&diagnostic, visible);
    }
    release(visible);
}

static void propose_name(WCHAR *path, const WCHAR *fallback, const WCHAR *extension) {
    const WCHAR *name = *ide.file_path ? basename(ide.file_path) : fallback;
    size_t used = append_wide(path, PATH_CAPACITY, 0, name);
    if (has_extension(path, u".kh")) used -= 3;
    append_wide(path, PATH_CAPACITY, used, extension);
}

static void build_document(void) {
    char *source = editor_source();
    if (!source) {
        show_error(u"ビルドに必要なメモリを確保できませんでした。");
        return;
    }

    KHDiagnostic diagnostic;
    if (!kh_check(source, &diagnostic)) {
        show_diagnostic(&diagnostic, u"");
        release(source);
        return;
    }

    WCHAR *path = allocate(PATH_CAPACITY * sizeof(WCHAR));
    if (!path) {
        release(source);
        show_error(u"保存先を選ぶためのメモリを確保できませんでした。");
        return;
    }
    propose_name(path, u"program", u".exe");
    if (select_path(path, 1, PATH_EXECUTABLE)) {
        if (!has_extension(path, u".exe")) {
            show_error(u"ファイル名の末尾を .exe にしてください。");
        } else {
            char error[512] = {0};
            if (kh_build_exe(source, path, error, sizeof error)) {
                size_t capacity = wide_length(path) + 100;
                WCHAR *message = allocate(capacity * sizeof(WCHAR));
                if (message) {
                    size_t used = append_wide(message, capacity, 0, u"実行ファイルを作成しました。\r\n");
                    append_wide(message, capacity, used, path);
                    SetWindowTextW(ide.output, message);
                    release(message);
                }
                status(u"ビルド完了");
            } else {
                WCHAR *message = utf8_as_edit_text(error, (int)narrow_length(error));
                show_error(message && *message ? message : u"実行ファイルを作成できませんでした。");
                release(message);
                status(u"ビルドに失敗しました");
            }
        }
    }
    release(path);
    release(source);
}

static void report_web_output(const WCHAR *path) {
    size_t stem_length = wide_length(path) - 5;
    append_wide(ide.last_index_path, PATH_CAPACITY, 0, path);
    append_wide(ide.last_index_path, PATH_CAPACITY, stem_length, u"-site\\index.html");
    EnableWindow(ide.buttons[ID_WEB_OPEN - ID_NEW], 1);
    size_t capacity = wide_length(ide.last_index_path) + 120;
    WCHAR *message = allocate(capacity * sizeof(WCHAR));
    if (message) {
        size_t used = append_wide(message, capacity, 0, u"HTML・CSS・JavaScript を出力しました。\r\n\r\n");
        used = append_wide(message, capacity, used, ide.last_index_path);
        append_wide(message, capacity, used, u"\r\n\r\n「ブラウザーで開く」で確認できます。");
        SetWindowTextW(ide.output, message);
        release(message);
    }
    status(u"HTML 出力完了");
}

static void export_web_document(void) {
    char *source = editor_source();
    WCHAR *path = allocate(PATH_CAPACITY * sizeof(WCHAR));
    if (!source || !path) {
        show_error(u"HTML 出力に必要なメモリを確保できませんでした。");
    } else {
        propose_name(path, u"homepage", u".html");
        if (select_path(path, 1, PATH_WEBSITE)) {
            if (!has_extension(path, u".html")) {
                show_error(u"出力名の末尾を .html にしてください。");
            } else {
                KHDiagnostic diagnostic = {0};
                char error[512] = {0};
                if (kh_export_site(source, ide.file_path, path, &diagnostic, error, sizeof error)) {
                    report_web_output(path);
                } else if (diagnostic.line > 0) {
                    show_diagnostic(&diagnostic, u"");
                } else {
                    WCHAR *message = utf8_as_edit_text(error, (int)narrow_length(error));
                    show_error(message && *message ? message : u"HTML を出力できませんでした。");
                    release(message);
                    status(u"HTML 出力に失敗しました");
                }
            }
        }
    }
    release(path);
    release(source);
}

static void open_web_output(void) {
    if (!*ide.last_index_path) return;
    Handle result = ShellExecuteW(ide.window, u"open", ide.last_index_path, 0, 0, 1);
    if ((intptr_t)result <= 32) show_error(u"ブラウザーで開けませんでした。出力先の index.html を確認してください。");
}

static void open_reference(void);

static void action(unsigned id) {
    close_completion();
    close_hover();
    switch (id) {
        case ID_NEW:
            if (confirm_replacement()) load_document(u"", u"", 0);
            break;
        case ID_OPEN: open_document(); break;
        case ID_SAVE: save_document(0); break;
        case ID_SAVE_AS: save_document(1); break;
        case ID_RUN: run_document(); break;
        case ID_BUILD: build_document(); break;
        case ID_WEB_SAMPLE:
            if (confirm_replacement()) load_document(web_sample, u"", 0);
            break;
        case ID_WEB_EXPORT: export_web_document(); break;
        case ID_WEB_OPEN: open_web_output(); break;
        case ID_REFERENCE: open_reference(); break;
    }
}

static Handle control(DWord ex_style, const WCHAR *class, const WCHAR *text, DWord style, int id) {
    Handle result = CreateWindowExW(ex_style, class, text, WS_CHILD | WS_VISIBLE | style,
                                    0, 0, 0, 0, ide.window, (Handle)(intptr_t)id, ide.instance, 0);
    if (result) SendMessageW(result, WM_SETFONT, (WParam)ide.interface_font, 0);
    return result;
}

static void place(Handle control_window, int x, int y, int width, int height) {
    MoveWindow(control_window, x, y, width > 0 ? width : 1, height > 0 ? height : 1, 1);
}

static TextRange editor_selection(void) {
    TextRange selection = {0};
    if (ide.rich_library) {
        SendMessageW(ide.editor, EM_EXGETSEL, 0, (LParam)&selection);
    } else {
        SendMessageW(ide.editor, EM_GETSEL, (WParam)&selection.first, (LParam)&selection.last);
    }
    return selection;
}

static void select_editor(TextRange range) {
    if (ide.rich_library) SendMessageW(ide.editor, EM_EXSETSEL, 0, (LParam)&range);
    else SendMessageW(ide.editor, EM_SETSEL, (WParam)range.first, (LParam)range.last);
}

static DWord token_color(enum KHHighlight kind) {
    switch (kind) {
        case KH_HIGHLIGHT_KEYWORD: return COLOR(115, 170, 248);
        case KH_HIGHLIGHT_BUILTIN: return COLOR(95, 210, 190);
        case KH_HIGHLIGHT_STRING: return COLOR(244, 172, 133);
        case KH_HIGHLIGHT_COMMENT: return COLOR(143, 181, 124);
        case KH_HIGHLIGHT_NUMBER: return COLOR(181, 218, 163);
        case KH_HIGHLIGHT_FUNCTION: return COLOR(227, 205, 134);
        case KH_HIGHLIGHT_IDENTIFIER: return COLOR(164, 217, 248);
        case KH_HIGHLIGHT_OPERATOR: return COLOR(211, 192, 234);
        default: return COLOR(224, 228, 236);
    }
}

static void format_span(size_t first, size_t last, DWord color, int error) {
    select_editor((TextRange){(int32_t)first, (int32_t)last});
    CharacterFormat format = {0};
    format.size = sizeof(format);
    format.mask = CFM_COLOR | CFM_UNDERLINE | CFM_UNDERLINETYPE;
    format.color = color;
    if (error) {
        format.effects = CFE_UNDERLINE;
        format.underline = 8;  /* CFU_UNDERLINEWAVE */
        format.underline_color = 5;
    }
    SendMessageW(ide.editor, EM_SETCHARFORMAT, 1, (LParam)&format);
}

static void color_token(size_t first, size_t count, enum KHHighlight kind, void *context) {
    size_t limit = *(const size_t *)context;
    if (first >= limit) return;
    size_t last = first + count;
    format_span(first, last < limit ? last : limit, token_color(kind), 0);
}

static int is_line_end(WCHAR unit) {
    return unit == '\r' || unit == '\n';
}

static size_t diagnostic_range(const WCHAR *wide, size_t length, size_t *end) {
    size_t first = 0;
    int line = 1;
    while (first < length && line < ide.live_diagnostic.line) {
        if (wide[first++] == '\r') {
            if (first < length && wide[first] == '\n') first++;
            line++;
        } else if (wide[first - 1] == '\n') line++;
    }
    if (line != ide.live_diagnostic.line || first == length) return length;
    size_t last = first;
    while (last < length && !is_line_end(wide[last])) last++;
    size_t offset = (size_t)(ide.live_diagnostic.column > 0 ? ide.live_diagnostic.column - 1 : 0);
    if (offset >= last - first) {
        *end = last;
        return last > first ? last - 1 : length;
    }
    size_t point = first + offset;
    if (point > first && wide[point] >= 0xdc00 && wide[point] <= 0xdfff &&
        wide[point - 1] >= 0xd800 && wide[point - 1] <= 0xdbff) point--;
    *end = point + 1;
    if (wide[point] >= 0xd800 && wide[point] <= 0xdbff && *end < last &&
        wide[*end] >= 0xdc00 && wide[*end] <= 0xdfff) (*end)++;
    return point;
}

static void paint_editor(const WCHAR *text, size_t length) {
    RichDocument *doc = ide.rich_document;
    if (!doc || !length || doc->methods->undo(doc, TOM_SUSPEND, 0) < 0) return;
    TextRange selection = editor_selection();
    Point scroll = {0};
    SendMessageW(ide.editor, EM_GETSCROLLPOS, 0, (LParam)&scroll);
    LResult events = SendMessageW(ide.editor, EM_GETEVENTMASK, 0, 0);
    ide.formatting = 1;
    SendMessageW(ide.editor, EM_SETEVENTMASK, 0, 0);
    SendMessageW(ide.editor, WM_SETREDRAW, 0, 0);
    format_span(0, length, token_color(KH_HIGHLIGHT_PLAIN), 0);
    /* Bound the number of Rich Edit changes on very large documents. */
    size_t color_limit = length < 40000 ? length : 40000;
    kh_editor_highlight(text, color_limit, color_token, &color_limit);
    if (ide.live_diagnostic.line > 0) {
        size_t last = 0;
        size_t first = diagnostic_range(text, length, &last);
        if (first < last) format_span(first, last, COLOR(255, 125, 135), 1);
    }
    select_editor(selection);
    SendMessageW(ide.editor, EM_SETSCROLLPOS, 0, (LParam)&scroll);
    doc->methods->undo(doc, TOM_RESUME, 0);
    SendMessageW(ide.editor, WM_SETREDRAW, 1, 0);
    SendMessageW(ide.editor, EM_SETEVENTMASK, 0, (LParam)events);
    ide.formatting = 0;
    InvalidateRect(ide.editor, 0, 0);
}

static void display_editor_status(const WCHAR *text, size_t units) {
    WCHAR line[512];
    size_t used = 0;
    if (ide.live_diagnostic.line > 0) {
        used = append_wide(line, 512, used, u"文法エラー  ");
        used = append_number(line, 512, used, (unsigned)ide.live_diagnostic.line);
        used = append_wide(line, 512, used, u"行 ");
        used = append_number(line, 512, used, (unsigned)ide.live_diagnostic.column);
        used = append_wide(line, 512, used, u"列  ");
        if (!MultiByteToWideChar(65001, 0, ide.live_diagnostic.message, -1, line + used, (int)(512 - used))) {
            append_wide(line, 512, used, u"コードの書き方を確認してください。");
        }
    } else {
        TextRange selection = editor_selection();
        size_t caret = selection.last < 0 ? 0 : (size_t)selection.last;
        if (caret > units) caret = units;
        unsigned row = 1, column = 1;
        for (size_t index = 0; index < caret; index++) {
            if (is_line_end(text[index])) {
                if (text[index] == '\r' && index + 1 < caret && text[index + 1] == '\n') index++;
                row++;
                column = 1;
            } else column++;
        }
        used = append_number(line, 512, used, row);
        used = append_wide(line, 512, used, u"行 ");
        used = append_number(line, 512, used, column);
        used = append_wide(line, 512, used, u"列  ·  文法エラーなし  ·  Ctrl+Space で補完  ·  F2 でひな形");
        if (units > 40000 && ide.rich_document) append_wide(line, 512, used, u"  ·  色分けは先頭4万文字");
    }
    SetWindowTextW(ide.editor_status, line);
    InvalidateRect(ide.editor_status, 0, 1);
}

static void refresh_editor(void) {
    if (ide.loading || ide.formatting || ide.composing || !ide.editor) return;
    size_t units = 0;
    WCHAR *wide = editor_text(&units);
    if (!wide) return;
    /* Color offsets refer to Rich Edit's internal CR; the checker accepts CR or LF. */
    int size = WideCharToMultiByte(65001, 128, wide, -1, 0, 0, 0, 0);
    char *source = size > 0 ? allocate((size_t)size) : 0;
    if (source && WideCharToMultiByte(65001, 128, wide, -1, source, size, 0, 0)) {
        kh_editor_check(source, &ide.live_diagnostic);
        paint_editor(wide, units);
        display_editor_status(wide, units);
    }
    release(source);
    release(wide);
}

static void schedule_editor_refresh(void) {
    SetTimer(ide.window, EDITOR_REFRESH_TIMER, EDITOR_ANALYSIS_DELAY, 0);
}

static void close_completion(void) {
    KillTimer(ide.window, EDITOR_COMPLETION_TIMER);
    if (ide.completion_list && ide.completion_count) ShowWindow(ide.completion_list, SW_HIDE);
    ide.completion_count = 0;
}

static const WCHAR *completion_kind(enum KHHighlight kind) {
    switch (kind) {
        case KH_HIGHLIGHT_KEYWORD: return u"命令";
        case KH_HIGHLIGHT_BUILTIN: return u"Web命令";
        case KH_HIGHLIGHT_FUNCTION: return u"関数";
        default: return u"識別子";
    }
}

static int editor_point(size_t caret, Point *point) {
    if (ide.rich_library) {
        point->x = -1;
        point->y = -1;
        SendMessageW(ide.editor, EM_POSFROMCHAR, (WParam)point, (LParam)caret);
    } else {
        LResult packed = SendMessageW(ide.editor, EM_POSFROMCHAR, (WParam)caret, 0);
        point->x = (int16_t)(packed & 0xffff);
        point->y = (int16_t)((packed >> 16) & 0xffff);
    }
    Rect area;
    if (!GetClientRect(ide.editor, &area)) return 0;
    if (point->x < 0 || point->y < 0 || point->x > area.right || point->y >= area.bottom) return 0;
    return 1;
}

static int caret_position(size_t caret, Point *point) {
    if (!editor_point(caret, point)) return 0;
    MapWindowPoints(ide.editor, ide.window, point, 1);
    return 1;
}

static void show_completion(int manual) {
    if (!ide.completion_list || ide.composing || GetFocus() != ide.editor) return;
    close_hover();
    size_t length = 0;
    WCHAR *text = editor_text(&length);
    if (!text) return;
    TextRange selection = editor_selection();
    if (selection.first != selection.last || selection.last < 0 || (size_t)selection.last > length) {
        release(text);
        close_completion();
        return;
    }
    size_t caret = (size_t)selection.last;
    size_t first, last;
    size_t count = kh_editor_complete(text, length, caret, ide.completions, COMPLETION_CAPACITY, &first, &last);
    if (!manual && first == caret) count = 0;
    release(text);
    if (!count) {
        close_completion();
        return;
    }
    Rect area;
    Point point;
    if (!caret_position(caret, &point) || !GetClientRect(ide.window, &area)) {
        close_completion();
        return;
    }
    SendMessageW(ide.completion_list, LB_RESETCONTENT, 0, 0);
    size_t displayed = 0;
    for (; displayed < count; displayed++) {
        WCHAR label[111];
        size_t used = append_wide(label, 111, 0, ide.completions[displayed].text);
        used = append_wide(label, 111, used, u"  ·  ");
        used = append_wide(label, 111, used, completion_kind(ide.completions[displayed].kind));
        const KHEditorHelp *help = kh_editor_help_lookup(ide.completions[displayed].text,
                                                       wide_length(ide.completions[displayed].text));
        if (help && help->snippet) append_wide(label, 111, used, u"  ·  F2 ひな形");
        if (SendMessageW(ide.completion_list, LB_ADDSTRING, 0, (LParam)label) < 0) break;
    }
    if (!displayed) {
        close_completion();
        return;
    }
    ide.completion_count = displayed;
    ide.replace_first = first;
    ide.replace_last = last;
    SendMessageW(ide.completion_list, LB_SETCURSEL, 0, 0);
    int width = 306;
    int height = 24 * (int)(displayed > 7 ? 7 : displayed) + 5;
    int left = point.x + 2;
    int top = point.y + 23;
    if (left + width > area.right - 10) left = area.right - width - 10;
    if (left < 10) left = 10;
    if (top + height > area.bottom - 8) top = point.y - height - 4;
    if (top < 0) top = 0;
    SetWindowPos(ide.completion_list, 0, left, top, width, height, SWP_NOACTIVATE | SWP_SHOWWINDOW);
}

static int accept_completion(void) {
    if (!ide.completion_count) return 0;
    LResult current = SendMessageW(ide.completion_list, LB_GETCURSEL, 0, 0);
    if (current < 0 || (size_t)current >= ide.completion_count) {
        close_completion();
        return 0;
    }
    TextRange target = {(int32_t)ide.replace_first, (int32_t)ide.replace_last};
    const WCHAR *replacement = ide.completions[current].text;
    close_completion();
    ide.applying_completion = 1;
    select_editor(target);
    SendMessageW(ide.editor, EM_REPLACESEL, 1, (LParam)replacement);
    ide.applying_completion = 0;
    SetFocus(ide.editor);
    return 1;
}

static void shift_completion(int amount) {
    LResult current = SendMessageW(ide.completion_list, LB_GETCURSEL, 0, 0);
    LResult length = (LResult)ide.completion_count;
    current = current < 0 ? 0 : (current + amount + length) % length;
    SendMessageW(ide.completion_list, LB_SETCURSEL, (WParam)current, 0);
}


typedef struct {
    const WCHAR *line;
    size_t index;
    size_t start;
    size_t end;
    int at_token_end;
    const KHEditorHelp *help;
} HelpToken;

static int horizontal_space(WCHAR unit) {
    return unit == ' ' || unit == '\t';
}

static void find_help_token(size_t start, size_t length, enum KHHighlight kind, void *context) {
    HelpToken *token = context;
    size_t end = start + length;
    if (token->index < start || token->index > end ||
        (!token->at_token_end && token->index == end) || kind == KH_HIGHLIGHT_STRING) return;
    if (kind == KH_HIGHLIGHT_COMMENT && token->index != start) return;
    const KHEditorHelp *help = kh_editor_help_lookup(token->line + start,
                                                    kind == KH_HIGHLIGHT_COMMENT ? 1 : length);
    if (help && (!token->help || token->index > start)) {
        token->start = start;
        token->end = end;
        token->help = help;
    }
}

static HelpToken editor_help_at(const WCHAR *text, size_t length, size_t index, int at_token_end) {
    size_t line_start = index, line_end = index;
    while (line_start && !is_line_end(text[line_start - 1])) line_start--;
    while (line_end < length && !is_line_end(text[line_end])) line_end++;
    HelpToken token = {.line = text + line_start, .index = index - line_start,
                       .at_token_end = at_token_end};
    kh_editor_highlight(token.line, line_end - line_start, find_help_token, &token);
    token.start += line_start;
    token.end += line_start;
    return token;
}

static void close_hover(void) {
    if (!ide.hover_state) return;
    KillTimer(ide.window, EDITOR_HOVER_TIMER);
    if (ide.hover_state == 2) ShowWindow(ide.hover_tip, SW_HIDE);
    ide.hover_state = 0;
}

static void start_hover(Point point) {
    if (!ide.hover_tip || ide.composing || ide.completion_count) return;
    if (ide.hover_state && point.x == ide.hover_point.x && point.y == ide.hover_point.y) return;
    close_hover();
    ide.hover_point = point;
    ide.hover_state = SetTimer(ide.window, EDITOR_HOVER_TIMER, EDITOR_HOVER_DELAY, 0) ? 1 : 0;
}

static int point_on_help(const HelpToken *token, Point cursor) {
    Point start, end;
    if (!editor_point(token->start, &start) || !editor_point(token->end, &end)) return 0;
    return start.y == end.y && cursor.y >= start.y && cursor.y < start.y + 24 &&
           cursor.x >= start.x && cursor.x < end.x;
}

static void show_hover(void) {
    Point cursor;
    if (!ide.hover_state || ide.composing || ide.completion_count ||
        !GetCursorPos(&cursor) || WindowFromPoint(cursor) != ide.editor) {
        close_hover();
        return;
    }
    if (ide.hover_state == 2) return;
    MapWindowPoints(0, ide.editor, &cursor, 1);
    if (cursor.x != ide.hover_point.x || cursor.y != ide.hover_point.y) {
        close_hover();
        return;
    }

    LResult nearest;
    if (ide.rich_library) {
        nearest = SendMessageW(ide.editor, EM_CHARFROMPOS, 0, (LParam)&cursor);
    } else {
        uint32_t coordinates = (uint16_t)cursor.x | ((uint32_t)(uint16_t)cursor.y << 16);
        nearest = SendMessageW(ide.editor, EM_CHARFROMPOS, 0, coordinates) & 0xffff;
    }
    size_t length = 0;
    WCHAR *text = editor_text(&length);
    if (!text || nearest < 0 || (size_t)nearest > length) {
        release(text);
        close_hover();
        return;
    }
    HelpToken token = editor_help_at(text, length, (size_t)nearest, 0);
    if ((!token.help || !point_on_help(&token, cursor)) && nearest > 0)
        token = editor_help_at(text, length, (size_t)nearest - 1, 0);
    if (!token.help || !point_on_help(&token, cursor)) {
        release(text);
        close_hover();
        return;
    }
    WCHAR content[480];
    size_t used = append_wide(content, 480, 0, token.help->signature);
    used = append_wide(content, 480, used, u"\r\n");
    append_wide(content, 480, used, token.help->description);
    release(text);

    Rect area;
    if (!GetClientRect(ide.window, &area)) {
        close_hover();
        return;
    }
    MapWindowPoints(ide.editor, ide.window, &cursor, 1);
    int width = area.right < 520 ? area.right - 20 : 500;
    int rows = 1;
    for (const WCHAR *at = content; *at; at++) if (*at == '\n') rows++;
    int height = 39 + 21 * rows;
    int x = cursor.x + 10;
    int y = cursor.y + 24;
    if (x + width > area.right - 8) x = area.right - width - 8;
    if (x < 8) x = 8;
    if (y + height > area.bottom - 8) y = cursor.y - height - 6;
    if (y < 2) y = 2;
    SetWindowTextW(ide.hover_tip, content);
    ide.hover_state = 2;
    SetWindowPos(ide.hover_tip, 0, x, y, width, height, SWP_NOACTIVATE | SWP_SHOWWINDOW);
}

static int template_line(const WCHAR *text, size_t length, size_t first, size_t last,
                         size_t *indent_start) {
    size_t line_start = first;
    while (line_start && !is_line_end(text[line_start - 1])) line_start--;
    *indent_start = line_start;
    for (size_t index = line_start; index < first; index++) {
        if (!horizontal_space(text[index])) return 0;
    }
    for (size_t index = last; index < length && !is_line_end(text[index]); index++) {
        if (!horizontal_space(text[index])) return 0;
    }
    return 1;
}

static void insert_template(void) {
    size_t length = 0;
    WCHAR *text = editor_text(&length);
    if (!text) return;
    const KHEditorHelp *help = 0;
    size_t first = 0, last = 0;
    if (ide.completion_count) {
        LResult current = SendMessageW(ide.completion_list, LB_GETCURSEL, 0, 0);
        if (current >= 0 && (size_t)current < ide.completion_count) {
            const WCHAR *name = ide.completions[current].text;
            help = kh_editor_help_lookup(name, wide_length(name));
            first = ide.replace_first;
            last = ide.replace_last;
        }
    } else {
        TextRange selection = editor_selection();
        if (selection.first >= 0 && selection.last >= selection.first && (size_t)selection.last <= length) {
            HelpToken token = editor_help_at(text, length, (size_t)selection.first, 1);
            if (selection.first == selection.last ||
                ((size_t)selection.first == token.start && (size_t)selection.last == token.end)) {
                help = token.help;
                first = token.start;
                last = token.end;
            }
        }
    }
    close_completion();
    close_hover();
    size_t indent_start = 0;
    if (!help || !help->snippet || first > last || last > length ||
        !template_line(text, length, first, last, &indent_start)) {
        status(u"行に命令名だけ入力するか、補完候補を選んで F2 を押してください。");
        release(text);
        SetFocus(ide.editor);
        return;
    }
    size_t snippet_length = wide_length(help->snippet);
    size_t indent_length = first - indent_start;
    size_t breaks = 0;
    for (size_t index = 0; index < snippet_length; index++) {
        if (help->snippet[index] == '\n') breaks++;
    }
    size_t expanded_length = snippet_length + breaks * (indent_length + !ide.rich_library);
    if (length - (last - first) + expanded_length > EDIT_LIMIT) {
        status(u"ひな形を入れると編集可能な文字数を超えます。");
        release(text);
        return;
    }
    WCHAR *expanded = allocate((expanded_length + 1) * sizeof(*expanded));
    if (!expanded) {
        release(text);
        return;
    }
    size_t used = 0, selection_first = 0, selection_last = 0;
    size_t marker_end = help->select_start + help->select_length;
    for (size_t index = 0; index <= snippet_length; index++) {
        if (index == help->select_start) selection_first = used;
        if (index == marker_end) selection_last = used;
        WCHAR unit = help->snippet[index];
        if (unit == '\n') {
            expanded[used++] = '\r';
            if (!ide.rich_library) expanded[used++] = '\n';
            for (size_t space = indent_start; space < first; space++) expanded[used++] = text[space];
        } else {
            expanded[used++] = unit;
        }
    }
    release(text);
    ide.applying_completion = 1;
    select_editor((TextRange){(int32_t)first, (int32_t)last});
    SendMessageW(ide.editor, EM_REPLACESEL, 1, (LParam)expanded);
    select_editor((TextRange){(int32_t)(first + selection_first), (int32_t)(first + selection_last)});
    ide.applying_completion = 0;
    release(expanded);
    SetFocus(ide.editor);
    status(u"ひな形を挿入しました。選択部分を書き換えられます。");
}

static void connect_rich_document(void) {
    static const InterfaceId text_document = {0x8cc497c0, 0xa1df, 0x11ce,
        {0x80, 0x98, 0x00, 0xaa, 0x00, 0x47, 0xbe, 0x5d}};
    Unknown *edit = 0;
    if (SendMessageW(ide.editor, EM_GETOLEINTERFACE, 0, (LParam)&edit) && edit) {
        void *document = 0;
        if (edit->methods->query(edit, &text_document, &document) >= 0) ide.rich_document = document;
        edit->methods->release(edit);
    }
}

static LResult reference_proc(Handle window, unsigned message, WParam wparam, LParam lparam) {
    switch (message) {
        case WM_CREATE:
            ide.reference_edit = CreateWindowExW(WS_EX_CLIENTEDGE, u"EDIT", u"",
                WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_VSCROLL | ES_MULTILINE |
                ES_AUTOVSCROLL | ES_READONLY | ES_NOHIDESEL,
                0, 0, 0, 0, window, 0, ide.instance, 0);
            if (!ide.reference_edit) return -1;
            SendMessageW(ide.reference_edit, WM_SETFONT, (WParam)ide.interface_font, 0);
            SendMessageW(ide.reference_edit, EM_SETMARGINS, 3, (LParam)((9u << 16) | 9u));
            SendMessageW(ide.reference_edit, EM_SETLIMITTEXT, sizeof reference_text / sizeof reference_text[0], 0);
            return SetWindowTextW(ide.reference_edit, reference_text) ? 0 : -1;
        case WM_SIZE: {
            Rect area;
            ide.reference_minimized = (wparam == SIZE_MINIMIZED);
            if (!ide.reference_minimized && ide.reference_edit && GetClientRect(window, &area)) {
                place(ide.reference_edit, 12, 12, area.right - 24, area.bottom - 24);
            }
            return 0;
        }
        case WM_GETMINMAXINFO: {
            int32_t *metrics = (int32_t *)lparam;
            metrics[6] = 360;
            metrics[7] = 260;
            return 0;
        }
        case WM_CLOSE:
            DestroyWindow(window);
            return 0;
        case WM_DESTROY:
            ide.reference_window = 0;
            ide.reference_edit = 0;
            ide.reference_minimized = 0;
            return 0;
    }
    return DefWindowProcW(window, message, wparam, lparam);
}

static void open_reference(void) {
    if (!ide.reference_class_registered) {
        WindowClass reference_class = {0};
        reference_class.size = sizeof reference_class;
        reference_class.procedure = reference_proc;
        reference_class.instance = ide.instance;
        reference_class.cursor = LoadCursorW(0, SYSTEM_ARROW_CURSOR);
        reference_class.background = ide.page_brush;
        reference_class.class_name = reference_class_name;
        if (!RegisterClassExW(&reference_class)) {
            show_error(u"コマンド一覧を開けませんでした。");
            return;
        }
        ide.reference_class_registered = 1;
    }
    if (!ide.reference_window) {
        ide.reference_window = CreateWindowExW(0, reference_class_name, reference_title,
            WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN, DEFAULT_WINDOW_POSITION, DEFAULT_WINDOW_POSITION,
            850, 650, ide.window, 0, ide.instance, 0);
        if (!ide.reference_window) {
            show_error(u"コマンド一覧を開けませんでした。");
            return;
        }
    }
    ShowWindow(ide.reference_window, ide.reference_minimized ? SW_RESTORE : SW_SHOW);
    UpdateWindow(ide.reference_window);
    SetFocus(ide.reference_edit);
}

static void layout(void) {
    Rect area;
    if (!GetClientRect(ide.window, &area)) return;
    int width = area.right;
    int height = area.bottom;
    int width_inside = width - 36;
    int split = width >= 775;
    static const int button_widths[] = {60, 60, 60, 130, 78, 110, 101, 106, 145, 130};

    place(ide.title, 18, 11, 200, 34);
    place(ide.path, 233, 14, width - 251, 25);
    int x = 18;
    int y = 53;
    for (int index = 0; index < ACTION_COUNT; index++) {
        if (x + button_widths[index] > width - 18) {
            x = 18;
            y += 40;
        }
        place(ide.buttons[index], x, y, button_widths[index], 34);
        x += button_widths[index] + 6;
    }
    int labels_top = y + 47;
    int panes_top = labels_top + 26;
    if (split) {
        int editor_width = width_inside * 3 / 5;
        int output_left = 30 + editor_width;
        int output_width = width - output_left - 18;
        place(ide.editor_label, 18, labels_top, editor_width, 24);
        place(ide.output_label, output_left, labels_top, output_width, 24);
        place(ide.editor, 18, panes_top, editor_width, height - panes_top - 64);
        place(ide.output, output_left, panes_top, output_width, height - panes_top - 64);
    } else {
        int output_height = (height - panes_top - 83) / 3;
        if (output_height < 88) output_height = 88;
        int output_top = height - 64 - output_height;
        place(ide.editor_label, 18, labels_top, width_inside, 24);
        place(ide.editor, 18, panes_top, width_inside, output_top - panes_top - 36);
        place(ide.output_label, 18, output_top - 30, width_inside, 24);
        place(ide.output, 18, output_top, width_inside, output_height);
    }
    place(ide.status, 18, height - 56, width_inside, 22);
    place(ide.editor_status, 18, height - 30, width_inside, 22);
}

static int create_controls(void) {
    ide.interface_font = CreateFontW(-16, 0, 0, 0, 400, 0, 0, 0, 1, 0, 0, 5, 0, u"Yu Gothic UI");
    ide.title_font = CreateFontW(-25, 0, 0, 0, 700, 0, 0, 0, 1, 0, 0, 5, 0, u"Yu Gothic UI");
    ide.code_font = CreateFontW(-17, 0, 0, 0, 400, 0, 0, 0, 1, 0, 0, 5, 0, u"Consolas");
    Handle fallback = GetStockObject(17);
    if (!ide.interface_font) ide.interface_font = fallback;
    if (!ide.title_font) ide.title_font = fallback;
    if (!ide.code_font) ide.code_font = fallback;

    ide.title = control(0, u"STATIC", app_title, SS_CENTERIMAGE, 0);
    ide.path = control(0, u"STATIC", u"", SS_CENTERIMAGE | SS_PATHELLIPSIS, 0);
    ide.editor_label = control(0, u"STATIC", u"スクリプト", SS_CENTERIMAGE, 0);
    ide.output_label = control(0, u"STATIC", u"出力と診断", SS_CENTERIMAGE, 0);
    ide.status = control(0, u"STATIC", u"", SS_CENTERIMAGE, 0);
    ide.editor_status = control(0, u"STATIC", u"", SS_CENTERIMAGE | SS_PATHELLIPSIS, 0);
    static const WCHAR *const captions[] = {
        u"新規", u"開く", u"保存", u"別名で保存", u"実行 F5", u"EXEビルド F7",
        u"Webサンプル", u"HTML出力 F8", u"ブラウザーで開く", u"コマンド一覧 F1"
    };
    for (int index = 0; index < ACTION_COUNT; index++) {
        DWord style = WS_TABSTOP | (index == ID_WEB_EXPORT - ID_NEW ? BS_DEFPUSHBUTTON : 0);
        int command = index == ACTION_COUNT - 1 ? ID_REFERENCE : ID_NEW + index;
        ide.buttons[index] = control(0, u"BUTTON", captions[index], style, command);
        if (!ide.buttons[index]) return 0;
    }
    EnableWindow(ide.buttons[ID_WEB_OPEN - ID_NEW], 0);
    DWord editor_style = WS_TABSTOP | WS_VSCROLL | WS_HSCROLL | ES_MULTILINE |
        ES_AUTOVSCROLL | ES_AUTOHSCROLL | ES_NOHIDESEL | ES_WANTRETURN;
    ide.rich_library = LoadLibraryExW(u"Msftedit.dll", 0, 0x00000800u);
    if (ide.rich_library) {
        ide.editor = control(WS_EX_CLIENTEDGE, u"RICHEDIT50W", u"",
                             editor_style | ES_NOOLEDRAGDROP, ID_EDITOR);
        if (!ide.editor) {
            FreeLibrary(ide.rich_library);
            ide.rich_library = 0;
        }
    }
    if (!ide.editor) ide.editor = control(WS_EX_CLIENTEDGE, u"EDIT", u"", editor_style, ID_EDITOR);
    ide.output = control(WS_EX_CLIENTEDGE, u"EDIT", u"",
        WS_TABSTOP | WS_VSCROLL | ES_MULTILINE | ES_AUTOVSCROLL | ES_READONLY, 0);
    ide.completion_list = CreateWindowExW(WS_EX_CLIENTEDGE, u"LISTBOX", u"",
        WS_CHILD | WS_VSCROLL | LBS_NOTIFY | LBS_NOINTEGRALHEIGHT, 0, 0, 0, 0, ide.window,
        (Handle)(intptr_t)ID_COMPLETION, ide.instance, 0);
    ide.hover_tip = CreateWindowExW(WS_EX_CLIENTEDGE, u"STATIC", u"", WS_CHILD | SS_NOPREFIX,
        0, 0, 0, 0, ide.window, (Handle)(intptr_t)ID_HOVER, ide.instance, 0);
    if (ide.hover_tip) SendMessageW(ide.hover_tip, WM_SETFONT, (WParam)ide.interface_font, 0);
    if (!ide.title || !ide.path || !ide.editor_label || !ide.output_label ||
        !ide.status || !ide.editor_status || !ide.editor || !ide.output || !ide.completion_list) return 0;
    SendMessageW(ide.completion_list, WM_SETFONT, (WParam)ide.interface_font, 0);
    SendMessageW(ide.completion_list, LB_SETITEMHEIGHT, 0, 24);
    SendMessageW(ide.title, WM_SETFONT, (WParam)ide.title_font, 0);
    SendMessageW(ide.editor, WM_SETFONT, (WParam)ide.code_font, 0);
    SendMessageW(ide.output, WM_SETFONT, (WParam)ide.code_font, 0);
    if (ide.rich_library) {
        SendMessageW(ide.editor, EM_EXLIMITTEXT, 0, EDIT_LIMIT);
        SendMessageW(ide.editor, EM_SETEVENTMASK, 0, ENM_CHANGE | ENM_SELCHANGE | ENM_SCROLL);
        connect_rich_document();
        if (ide.rich_document) {
            SendMessageW(ide.editor, EM_SETBKGNDCOLOR, 0, COLOR(29, 31, 39));
            CharacterFormat format = {0};
            format.size = sizeof(format);
            format.mask = CFM_COLOR;
            format.color = token_color(KH_HIGHLIGHT_PLAIN);
            SendMessageW(ide.editor, EM_SETCHARFORMAT, 0, (LParam)&format);
        }
    } else {
        SendMessageW(ide.editor, EM_SETLIMITTEXT, EDIT_LIMIT, 0);
    }
    return 1;
}

static LResult window_proc(Handle window, unsigned message, WParam wparam, LParam lparam) {
    switch (message) {
        case WM_CREATE:
            ide.window = window;
            if (!create_controls()) return -1;
            load_document(web_sample, u"", 0);
            return 0;
        case WM_SIZE:
            if (ide.editor) {
                close_completion();
                close_hover();
                layout();
            }
            return 0;
        case WM_GETMINMAXINFO: {
            int32_t *metrics = (int32_t *)lparam;
            metrics[6] = 606;
            metrics[7] = 510;
            return 0;
        }
        case WM_NOTIFY: {
            const NotifyHeader *notification = (const NotifyHeader *)lparam;
            if (notification && notification->source == ide.editor &&
                notification->code == EN_SELCHANGE && !ide.loading && !ide.formatting && !ide.composing) {
                if (ide.completion_count) {
                    TextRange selection = editor_selection();
                    if (selection.first != selection.last || selection.last < (int32_t)ide.replace_first ||
                        selection.last > (int32_t)ide.replace_last) close_completion();
                }
                if (ide.live_diagnostic.line <= 0) {
                    size_t units;
                    WCHAR *wide = editor_text(&units);
                    if (wide) {
                        display_editor_status(wide, units);
                        release(wide);
                    }
                }
            }
            break;
        }
        case WM_TIMER:
            if (wparam == EDITOR_HOVER_TIMER) {
                show_hover();
                return 0;
            }
            if (wparam == EDITOR_REFRESH_TIMER) {
                KillTimer(ide.window, EDITOR_REFRESH_TIMER);
                refresh_editor();
                return 0;
            }
            if (wparam == EDITOR_COMPLETION_TIMER) {
                KillTimer(ide.window, EDITOR_COMPLETION_TIMER);
                show_completion(0);
                return 0;
            }
            break;
        case WM_COMMAND: {
            unsigned id = (unsigned)(wparam & 0xffffu);
            unsigned notice = (unsigned)((wparam >> 16) & 0xffffu);
            if (id == ID_COMPLETION && notice == LBN_DBLCLK) {
                accept_completion();
                return 0;
            }
            if (id == ID_EDITOR && (notice == EN_VSCROLL || notice == EN_HSCROLL) && !ide.formatting) {
                close_completion();
                close_hover();
            }
            if (id == ID_EDITOR && notice == EN_CHANGE && !ide.loading && !ide.formatting) {
                close_completion();
                close_hover();
                if (!ide.dirty) {
                    ide.dirty = 1;
                    update_filename();
                }
                status(u"未保存の変更があります");
                schedule_editor_refresh();
                if (!ide.composing && !ide.applying_completion) {
                    SetTimer(ide.window, EDITOR_COMPLETION_TIMER, EDITOR_COMPLETION_DELAY, 0);
                }
                return 0;
            }
            if (((id >= ID_NEW && id <= ID_WEB_OPEN) || id == ID_REFERENCE) && !notice) {
                action(id);
                return 0;
            }
            break;
        }
        case WM_CTLCOLORSTATIC:
            if (ide.hover_tip && (Handle)lparam == ide.hover_tip) {
                SetBkColor((Handle)wparam, COLOR(26, 37, 47));
                SetTextColor((Handle)wparam, COLOR(244, 246, 250));
                return (LResult)ide.output_brush;
            }
            if ((Handle)lparam == ide.editor_status) {
                SetBkColor((Handle)wparam, COLOR(241, 245, 248));
                SetTextColor((Handle)wparam, ide.live_diagnostic.line > 0 ? COLOR(165, 25, 43) : COLOR(30, 49, 65));
                return (LResult)ide.page_brush;
            }
            if ((Handle)lparam == ide.output) {
                SetBkColor((Handle)wparam, COLOR(26, 37, 47));
                SetTextColor((Handle)wparam, COLOR(227, 237, 242));
                return (LResult)ide.output_brush;
            }
            SetBkColor((Handle)wparam, COLOR(241, 245, 248));
            SetTextColor((Handle)wparam, COLOR(30, 49, 65));
            return (LResult)ide.page_brush;
        case WM_CLOSE:
            if (confirm_replacement()) DestroyWindow(window);
            return 0;
        case WM_DESTROY:
            KillTimer(ide.window, EDITOR_REFRESH_TIMER);
            close_completion();
            close_hover();
            if (ide.rich_document) {
                ide.rich_document->methods->unknown.release(ide.rich_document);
                ide.rich_document = 0;
            }
            PostQuitMessage(0);
            return 0;
    }
    return DefWindowProcW(window, message, wparam, lparam);
}

static int shortcut(const Message *message) {
    if (message->message == WM_MOUSEMOVE) {
        if (message->window == ide.editor) {
            Point point = {(int16_t)(message->lparam & 0xffff), (int16_t)((message->lparam >> 16) & 0xffff)};
            start_hover(point);
        } else {
            close_hover();
        }
    }
    if (message->window == ide.editor) {
        if (message->message == WM_IME_STARTCOMPOSITION) {
            ide.composing = 1;
            close_completion();
            close_hover();
        } else if (message->message == WM_IME_ENDCOMPOSITION) {
            ide.composing = 0;
            schedule_editor_refresh();
            SetTimer(ide.window, EDITOR_COMPLETION_TIMER, EDITOR_COMPLETION_DELAY, 0);
        } else if (message->message == WM_MOUSEWHEEL || message->message == WM_MOUSEHWHEEL) {
            close_completion();
            close_hover();
        }
    }
    if (message->message != WM_KEYDOWN) return 0;
    close_hover();
    if (message->window == ide.editor || message->window == ide.completion_list) {
        if (ide.composing) return 0;
        unsigned key = (unsigned)message->wparam;
        if (key == 0x71) { insert_template(); return 1; }
        if (key == 0x20 && GetKeyState(0x11) < 0) {
            close_completion();
            show_completion(1);
            return 1;
        }
        if (ide.completion_count) {
            if (key == 0x1b) { close_completion(); SetFocus(ide.editor); return 1; }
            if (key == 0x26 || key == 0x28) { shift_completion(key == 0x26 ? -1 : 1); return 1; }
            if (key == 0x09 || key == 0x0d) return accept_completion();
            if (key == 0x21 || key == 0x22 || key == 0x23 || key == 0x24 || key == 0x25 || key == 0x27) close_completion();
        }
        if (message->window == ide.editor && ide.rich_library && key == 'V' && GetKeyState(0x11) < 0) {
            SendMessageW(ide.editor, EM_PASTESPECIAL, CF_UNICODETEXT, 0);
            return 1;
        }
    }
    if (message->wparam == 0x70) { action(ID_REFERENCE); return 1; }
    if (ide.reference_window &&
        (message->window == ide.reference_window || message->window == ide.reference_edit)) {
        if (message->wparam == 0x1b) { DestroyWindow(ide.reference_window); return 1; }
        if (message->wparam == 'A' && GetKeyState(0x11) < 0) {
            SendMessageW(ide.reference_edit, EM_SETSEL, 0, -1);
            return 1;
        }
        return 0;
    }
    if (message->wparam == 0x74) { action(ID_RUN); return 1; }
    if (message->wparam == 0x76) { action(ID_BUILD); return 1; }
    if (message->wparam == 0x77) { action(ID_WEB_EXPORT); return 1; }
    if (GetKeyState(0x11) >= 0) return 0;
    switch (message->wparam) {
        case 'N': action(ID_NEW); return 1;
        case 'O': action(ID_OPEN); return 1;
        case 'S': action(GetKeyState(0x10) < 0 ? ID_SAVE_AS : ID_SAVE); return 1;
    }
    return 0;
}

void kh_ide_main(void) {
    ide.instance = GetModuleHandleW(0);
    ide.page_brush = CreateSolidBrush(COLOR(241, 245, 248));
    ide.output_brush = CreateSolidBrush(COLOR(26, 37, 47));
    WindowClass window_class = {0};
    window_class.size = sizeof window_class;
    window_class.procedure = window_proc;
    window_class.instance = ide.instance;
    window_class.icon = LoadIconW(0, SYSTEM_APPLICATION_ICON);
    window_class.cursor = LoadCursorW(0, SYSTEM_ARROW_CURSOR);
    window_class.background = ide.page_brush;
    window_class.class_name = class_name;
    if (!RegisterClassExW(&window_class)) {
        show_error(u"KH言語 IDE を起動できませんでした。");
        ExitProcess(1);
        return;
    }
    Handle window = CreateWindowExW(0, class_name, app_title,
        WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN, DEFAULT_WINDOW_POSITION, DEFAULT_WINDOW_POSITION,
        1100, 700, 0, 0, ide.instance, 0);
    if (!window) {
        show_error(u"KH言語 IDE のウィンドウを作成できませんでした。");
        ExitProcess(1);
        return;
    }
    ShowWindow(window, 1);
    UpdateWindow(window);
    SetFocus(ide.editor);
    Message message = {0};
    int result;
    while ((result = GetMessageW(&message, 0, 0, 0)) > 0) {
        if (!shortcut(&message)) {
            TranslateMessage(&message);
            DispatchMessageW(&message);
        }
    }
    if (ide.rich_library) FreeLibrary(ide.rich_library);
    ExitProcess(result < 0 ? 1 : (unsigned)message.wparam);
}
