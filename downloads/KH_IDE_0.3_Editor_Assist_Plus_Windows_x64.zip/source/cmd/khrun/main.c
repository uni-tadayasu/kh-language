#include "../../internal/bundle.h"
#include "../../internal/lang.h"
#include "../../internal/winfile.h"
#include <stdlib.h>
#include <string.h>

static Wide module_path[32768];

static char *read_embedded_source(void) {
    Dword path_length = GetModuleFileNameW(NULL, module_path, 32768);
    if (path_length == 0 || path_length >= 32768) return NULL;
    Handle file = CreateFileW(module_path, GENERIC_READ_KH, 7, NULL,
                              OPEN_EXISTING_KH, FILE_ATTRIBUTE_NORMAL_KH, NULL);
    if (file == INVALID_FILE) return NULL;
    unsigned char trailer[KH_TRAILER_SIZE];
    int64_t size = 0;
    char *source = NULL;
    if (GetFileSizeEx(file, &size) && size >= KH_TRAILER_SIZE
        && SetFilePointerEx(file, size - KH_TRAILER_SIZE, NULL, 0)
        && kh_read_all(file, trailer, sizeof(trailer))
        && memcmp(trailer, kh_bundle_magic, sizeof(kh_bundle_magic)) == 0) {
        uint32_t length = kh_read_length(trailer + 8);
        uint32_t inverse = kh_read_length(trailer + 12);
        if (length <= KH_SOURCE_MAX_BYTES && inverse == ~length
            && size - KH_TRAILER_SIZE - length >= 1024
            && SetFilePointerEx(file, size - KH_TRAILER_SIZE - length, NULL, 0)) {
            source = malloc((size_t)length + 1);
            if (source) {
                if (kh_read_all(file, source, length) && !memchr(source, 0, length)) {
                    source[length] = '\0';
                } else {
                    free(source);
                    source = NULL;
                }
            }
        }
    }
    CloseHandle(file);
    return source;
}

static int write_text(Handle output, const char *utf8, size_t length) {
    Dword mode;
    if (!length) return 1;
    if (!GetConsoleMode(output, &mode)) return kh_write_all(output, utf8, length);
    int units = MultiByteToWideChar(65001, 0, utf8, (int)length, NULL, 0);
    if (units <= 0) return 0;
    Wide *text = malloc((size_t)units * sizeof(*text));
    if (!text) return 0;
    int converted = MultiByteToWideChar(65001, 0, utf8, (int)length, text, units);
    size_t written = 0;
    while (converted == units && written < (size_t)units) {
        Dword count = 0;
        Dword remaining = (Dword)((size_t)units - written);
        Dword chunk = remaining > 8000 ? 8000 : remaining;
        if (chunk < remaining && text[written + chunk - 1] >= 0xd800
            && text[written + chunk - 1] <= 0xdbff) --chunk;
        if (!WriteConsoleW(output, text + written, chunk, &count, NULL) || count == 0) break;
        written += count;
    }
    free(text);
    return written == (size_t)units;
}

struct Output { Handle handle; int failed; };

static void print_line(const char *text, size_t length, void *context) {
    struct Output *output = context;
    if (!output->failed &&
        (!write_text(output->handle, text, length) || !write_text(output->handle, "\r\n", 2))) {
        output->failed = 1;
    }
}

static void write_number(Handle output, unsigned int number) {
    char text[10];
    size_t start = sizeof(text);
    do {
        text[--start] = (char)('0' + number % 10);
        number /= 10;
    } while (number);
    write_text(output, text + start, sizeof(text) - start);
}

static void show_diagnostic(Handle error, const KHDiagnostic *diagnostic) {
    write_text(error, "KH line ", 8);
    write_number(error, (unsigned int)diagnostic->line);
    write_text(error, ", column ", 9);
    write_number(error, (unsigned int)diagnostic->column);
    write_text(error, ": ", 2);
    write_text(error, diagnostic->message, strlen(diagnostic->message));
    write_text(error, "\r\n", 2);
}

static void wait_in_own_console(Handle output) {
    Handle input = GetStdHandle((Dword)-10);
    Dword processes[2];
    Dword mode;
    Dword output_mode;
    if (GetConsoleProcessList(processes, 2) == 1 && GetConsoleMode(input, &mode)
        && GetConsoleMode(output, &output_mode)) {
        const char prompt[] = "\r\nPress Enter to close...";
        write_text(output, prompt, sizeof(prompt) - 1);
        Wide character;
        Dword count = 0;
        do {
            if (!ReadConsoleW(input, &character, 1, &count, NULL) || count == 0) break;
        } while (character != '\n');
    }
}

void kh_runtime_main(void) {
    struct Output output = {GetStdHandle((Dword)-11), 0};
    Handle error = GetStdHandle((Dword)-12);
    KHDiagnostic diagnostic;
    char *source = read_embedded_source();
    Dword exit_code = 1;
    if (!source) {
        const char message[] = "KH: could not read the program embedded in this executable.\r\n";
        write_text(error, message, sizeof(message) - 1);
    } else if (!kh_run(source, print_line, &output, &diagnostic)) {
        show_diagnostic(error, &diagnostic);
    } else if (!output.failed) {
        exit_code = 0;
    }
    free(source);
    wait_in_own_console(output.handle);
    ExitProcess(exit_code);
}
