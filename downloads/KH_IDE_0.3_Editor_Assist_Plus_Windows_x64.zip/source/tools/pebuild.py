#!/usr/bin/env python3
"""Cross-build freestanding Windows x64 C programs with GCC and GNU binutils.

GCC emits x86-64 ELF objects with the Microsoft calling convention. Translate
their sections and relocations to COFF, and provide PE imports from system DLLs.
"""

import argparse
import collections
import pathlib
import re
import struct
import subprocess
import tempfile
from dataclasses import dataclass, field

U32 = struct.Struct("<I")
COFF_HEADER = struct.Struct("<HHIIIHH")
COFF_SECTION = struct.Struct("<8sIIIIIIHHI")
COFF_SYMBOL = struct.Struct("<8sIhHBB")
COFF_RELOCATION = struct.Struct("<IIH")
ELF_HEADER = struct.Struct("<16sHHIQQQIHHHHHH")
ELF_SECTION = struct.Struct("<IIQQQQIIQQ")
ELF_SYMBOL = struct.Struct("<IBBHQQ")
ELF_RELOCATION = struct.Struct("<QQq")

CODE = 0x60000020
DATA = 0xC0000040
RODATA = 0x40000040
BSS = 0xC0000080
REL32 = 4
ADDR32NB = 3

DLL_FUNCTIONS = {
    "kernel32": """
        CloseHandle CreateDirectoryW CreateFileW DeleteFileW ExitProcess FlushFileBuffers FreeLibrary
        GetCommandLineW GetConsoleMode GetConsoleProcessList GetCurrentProcessId
        GetFileAttributesW GetFileSizeEx GetFileType GetLastError
        GetModuleFileNameW GetModuleHandleW GetProcessHeap GetStdHandle
        GetTempFileNameW HeapAlloc HeapFree HeapReAlloc LoadLibraryExW LoadLibraryW MultiByteToWideChar
        MoveFileExW RemoveDirectoryW ReadConsoleW ReadFile SetConsoleOutputCP SetFilePointerEx
        WideCharToMultiByte WriteConsoleW WriteFile
    """,
    "user32": """
        CreateWindowExW DefWindowProcW DestroyWindow DispatchMessageW EnableWindow FillRect
        GetClientRect GetCursorPos GetFocus GetKeyState GetMessageW GetWindowTextLengthW GetWindowTextW
        InvalidateRect KillTimer LoadCursorW LoadIconW MapWindowPoints MessageBoxW MoveWindow
        PostQuitMessage RegisterClassExW SendMessageW SetFocus SetTimer
        SetWindowTextW SetWindowPos ShowWindow TranslateMessage UpdateWindow WindowFromPoint
    """,
    "gdi32": """
        CreateFontW CreateSolidBrush DeleteObject GetStockObject SetBkColor
        SetTextColor
    """,
    "comdlg32": "CommDlgExtendedError GetOpenFileNameW GetSaveFileNameW",
    "shell32": "CommandLineToArgvW ShellExecuteW",
    "msvcrt": """
        _snprintf calloc ceil exit floor fmod free malloc memchr memcmp memcpy
        memmove memset realloc strchr strcmp strcpy strlen strncmp strrchr
        strstr strtod
    """,
}
DLL_ALIASES = {"snprintf": ("msvcrt", "_snprintf")}


@dataclass
class Section:
    name: str
    data: bytearray
    size: int
    characteristics: int
    align: int = 1
    relocations: list = field(default_factory=list)


@dataclass
class Symbol:
    name: str
    value: int = 0
    section: int = 0
    external: bool = True
    function: bool = False


def cstring(data, offset):
    end = data.index(0, offset)
    return data[offset:end].decode("utf-8")


def write_coff(path, sections, symbols):
    strings = bytearray(4)
    offsets = {}

    def string_offset(name):
        if name not in offsets:
            offsets[name] = len(strings)
            strings.extend(name.encode("utf-8") + b"\0")
        return offsets[name]

    section_headers = bytearray()
    raw = bytearray()
    initial_size = COFF_HEADER.size + len(sections) * COFF_SECTION.size

    for section in sections:
        section_name = section.name.encode("utf-8")
        if len(section_name) > 8:
            section_name = f"/{string_offset(section.name)}".encode()
        data_offset = initial_size + len(raw) if section.data else 0
        raw.extend(section.data)
        relocation_offset = initial_size + len(raw) if section.relocations else 0
        for address, symbol, kind in section.relocations:
            raw.extend(COFF_RELOCATION.pack(address, symbol, kind))
        alignment = section.align.bit_length() << 20
        section_headers.extend(COFF_SECTION.pack(
            section_name, 0, 0, section.size, data_offset, relocation_offset, 0,
            len(section.relocations), 0, section.characteristics | alignment,
        ))

    table_offset = initial_size + len(raw)
    symbol_table = bytearray()
    for symbol in symbols:
        name = symbol.name.encode("utf-8")
        if len(name) > 8:
            name = b"\0" * 4 + U32.pack(string_offset(symbol.name))
        symbol_table.extend(COFF_SYMBOL.pack(
            name, symbol.value, symbol.section, 0x20 if symbol.function else 0,
            2 if symbol.external else 3, 0,
        ))

    U32.pack_into(strings, 0, len(strings))
    header = COFF_HEADER.pack(0x8664, len(sections), 0, table_offset, len(symbols), 0, 0)
    path.write_bytes(header + section_headers + raw + symbol_table + strings)


def convert_elf(source, target):
    data = source.read_bytes()
    header = ELF_HEADER.unpack_from(data)
    ident, _, machine, _, _, _, section_table, _, _, _, _, _, count, section_names = header
    if ident[:6] != b"\x7fELF\x02\x01" or machine != 62:
        raise ValueError(f"Expected an x86-64 ELF object: {source}")
    elf_sections = [
        ELF_SECTION.unpack_from(data, section_table + index * ELF_SECTION.size)
        for index in range(count)
    ]

    def section_data(index):
        section = elf_sections[index]
        return data[section[4]:section[4] + section[5]]

    section_map = {}
    sections = []
    for index, section in enumerate(elf_sections):
        name_at, kind, flags, _, _, size, _, _, alignment, _ = section
        if not flags & 2:
            continue
        name = cstring(section_data(section_names), name_at)
        if kind == 8:
            coff_name, characteristics = ".bss", BSS
        elif kind == 1 and flags & 4:
            coff_name, characteristics = ".text", CODE
        elif kind == 1 and flags & 1:
            coff_name, characteristics = ".data", DATA
        elif kind == 1:
            coff_name, characteristics = ".rdata", RODATA
        else:
            raise ValueError(f"Unsupported ELF allocated section: {name}")
        contents = bytearray(section_data(index)) if kind != 8 else bytearray()
        sections.append(Section(coff_name, contents, size, characteristics, max(1, alignment)))
        section_map[index] = len(sections)

    symtab_index, symtab = next((i, s) for i, s in enumerate(elf_sections) if s[1] == 2)
    names = section_data(symtab[6])
    symbols = []
    symbol_map = {}

    for index, symbol in enumerate(ELF_SYMBOL.iter_unpack(section_data(symtab_index))):
        name_at, info, _, index_at, value, _ = symbol
        kind, binding = info & 15, info >> 4
        if index == 0 or kind == 4:
            continue
        if index_at != 0 and index_at not in section_map:
            continue
        name = cstring(names, name_at) if name_at else f".s{index_at}"
        symbol_map[index] = len(symbols)
        symbols.append(Symbol(name, value, section_map.get(index_at, 0), binding != 0, kind == 2))

    for reltab in elf_sections:
        _, kind, _, _, offset, size, _, index, _, _ = reltab
        if kind != 4 or index not in section_map:
            continue
        section = sections[section_map[index] - 1]
        for address, info, addend in ELF_RELOCATION.iter_unpack(data[offset:offset + size]):
            symbol_index = info >> 32
            relocation = info & 0xFFFFFFFF
            if relocation in (2, 4):  # ELF PC32 and PLT32 -> COFF REL32
                kind, fmt, adjusted = REL32, "<i", addend + 4
            elif relocation == 1:  # ELF 64 -> COFF ADDR64
                kind, fmt, adjusted = 1, "<q", addend
            elif relocation in (10, 11):  # ELF 32 and 32S -> COFF ADDR32
                kind, fmt, adjusted = 2, "<I", addend & 0xFFFFFFFF
            else:
                raise ValueError(f"Unsupported ELF relocation {relocation} in {source}")
            struct.pack_into(fmt, section.data, address, adjusted)
            section.relocations.append((address, symbol_map[symbol_index], kind))

    write_coff(target, sections, symbols)
    definitions = {s.name for s in symbols if s.external and s.section}
    references = {s.name for s in symbols if s.external and not s.section}
    return definitions, references


def write_imports(path, imports):
    sections = [
        Section(".text", bytearray(), 0, CODE, 4),
        Section(".idata$2", bytearray(), 0, DATA, 4),
        Section(".idata$4", bytearray(), 0, DATA, 8),
        Section(".idata$5", bytearray(), 0, DATA, 8),
        Section(".idata$6", bytearray(), 0, DATA, 2),
        Section(".idata$7", bytearray(), 0, DATA),
    ]
    symbols = []

    def append(section_number, contents, name=None, external=False, function=False):
        section = sections[section_number - 1]
        start = len(section.data)
        section.data.extend(contents)
        section.size = len(section.data)
        if name is None:
            return start
        index = len(symbols)
        symbols.append(Symbol(name, start, section_number, external, function))
        return start, index

    def reference(section_number, address, symbol, kind=ADDR32NB):
        sections[section_number - 1].relocations.append((address, symbol, kind))

    for dll, names in imports.items():
        _, dll_name = append(6, (dll + ".dll").encode() + b"\0", f"dll.{dll}")
        ilt_start = len(sections[2].data)
        iat_start = len(sections[3].data)
        ilt_symbol = len(symbols)
        symbols.append(Symbol(f"ilt.{dll}", ilt_start, 3, False))
        iat_symbol = len(symbols)
        symbols.append(Symbol(f"iat.{dll}", iat_start, 4, False))
        directory = append(2, b"\0" * 20)
        reference(2, directory, ilt_symbol)
        reference(2, directory + 12, dll_name)
        reference(2, directory + 16, iat_symbol)

        for name, exported in names:
            import_name = b"\0\0" + exported.encode() + b"\0"
            if len(import_name) % 2:
                import_name += b"\0"
            _, hint_name = append(5, import_name, f"hint.{name}")
            ilt = append(3, b"\0" * 8)
            iat, iat_entry = append(4, b"\0" * 8, f"__imp_{name}", True)
            stub, _ = append(1, b"\xff\x25\0\0\0\0\x90\x90", name, True, True)
            reference(3, ilt, hint_name)
            reference(4, iat, hint_name)
            reference(1, stub + 2, iat_entry, REL32)

        append(3, b"\0" * 8)
        append(4, b"\0" * 8)

    write_coff(path, sections, symbols)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("-o", "--output", type=pathlib.Path, required=True)
    parser.add_argument("--entry", default="start")
    parser.add_argument("--subsystem", choices=("windows", "console"), default="console")
    parser.add_argument("-I", dest="include", action="append", default=[])
    parser.add_argument("-D", dest="define", action="append", default=[])
    parser.add_argument("--import-dll", action="append", default=[], metavar="DLL:FUNCTION")
    parser.add_argument("sources", nargs="+", type=pathlib.Path)
    args = parser.parse_args()
    names = {name: (dll, name) for dll, functions in DLL_FUNCTIONS.items() for name in functions.split()}
    names.update(DLL_ALIASES)

    for item in args.import_dll:
        dll, colon, name = item.partition(":")
        if not colon or not re.fullmatch(r"[A-Za-z_][A-Za-z_0-9]*", name):
            parser.error(f"Invalid DLL import: {item}")
        names[name] = dll, name

    with tempfile.TemporaryDirectory(prefix="kh-pe-") as temp:
        work = pathlib.Path(temp)
        definitions = set()
        references = set()
        objects = []

        sources = [*args.sources, pathlib.Path(__file__).with_name("chkstk.S")]
        for index, source in enumerate(sources):
            native = work / f"{index}.elf.o"
            target = work / f"{index}.obj"
            flags = [
                "-mabi=ms", "-mno-red-zone", "-mstack-arg-probe", "-fshort-wchar",
                "-ffreestanding", "-fno-asynchronous-unwind-tables",
                "-fno-unwind-tables", "-fno-stack-protector", "-fno-stack-clash-protection",
                "-fPIE", "-fno-ident", "-fno-jump-tables", "-O2", "-Wall", "-Wextra",
            ]
            flags += [f"-I{path}" for path in args.include]
            flags += [f"-D{define}" for define in args.define]
            subprocess.run(["gcc", *flags, "-c", str(source), "-o", str(native)], check=True)
            provided, needed = convert_elf(native, target)
            definitions.update(provided)
            references.update(needed)
            objects.append(target)

        imports = collections.defaultdict(list)
        for name in sorted(references - definitions):
            if name not in names:
                parser.error(f"Missing definition or DLL import for {name!r}")
            dll, exported = names[name]
            imports[dll].append((name, exported))

        if imports:
            target = work / "imports.obj"
            write_imports(target, imports)
            objects.append(target)

        args.output.parent.mkdir(parents=True, exist_ok=True)
        subprocess.run([
            "ld", "-m", "i386pep", "--subsystem", args.subsystem, "--entry", args.entry,
            "--dynamicbase", "--nxcompat", "--high-entropy-va", "--strip-all",
            "-o", str(args.output), *map(str, objects),
        ], check=True)


if __name__ == "__main__":
    main()
