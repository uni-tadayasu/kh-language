#ifndef KH_LANG_H
#define KH_LANG_H

#include <stddef.h>

#define KH_SOURCE_UNIT_LIMIT 200000
#define KH_SOURCE_BYTE_LIMIT (KH_SOURCE_UNIT_LIMIT * 3)

typedef struct {
    int line;
    int column;
    char message[256];
} KHDiagnostic;

/* Text is UTF-8 and valid for the duration of the callback. */
typedef void (*KHOutput)(const char *text, size_t length, void *context);

typedef enum {
    KH_WEB_NULL, KH_WEB_TEXT, KH_WEB_NUMBER, KH_WEB_BOOLEAN
} KHHostType;

typedef struct {
    KHHostType type;
    const char *text;
    size_t length;
    double number;
    int boolean;
} KHHostValue;

/* Name and text spans use UTF-8 and need not be NUL-terminated.
   They remain valid for the duration of the call. Return positive for success,
   zero for an unknown name, or negative with a NUL-terminated error message. */
typedef int (*KHHostCall)(const char *name, size_t name_length,
                         const KHHostValue *args, size_t argc,
                         char *error, size_t error_size, void *context);

/* The source is NUL-terminated UTF-8. Returns 1 on success, or 0 on error. */
int kh_check(const char *source, KHDiagnostic *diagnostic);
int kh_run(const char *source, KHOutput output, void *context, KHDiagnostic *diagnostic);
int kh_run_host(const char *source, KHOutput output, void *output_context,
                KHHostCall host_call, void *host_context, KHDiagnostic *diagnostic);

#endif
