#ifndef KH_WEBINCLUDE_H
#define KH_WEBINCLUDE_H

#include "lang.h"

#define KH_WEB_INCLUDE_COUNT 32
#define KH_WEB_INCLUDE_NAME_MAX 83

/* On success, the loader transfers a malloc-owned buffer and its byte length.
   The buffer need not be NUL-terminated. On failure it transfers no memory. */
typedef int (*KHWebLoad)(const char *name, char **source, size_t *length, void *context);

typedef struct {
    char *source;
    struct KHWebLine *lines;
    size_t line_count;
    char *files[KH_WEB_INCLUDE_COUNT];
    size_t file_count;
} KHWebSource;

/* Expands whole-line use directives. A NULL loader permits root-only input. */
int kh_expand_web_source(const char *source, KHWebLoad load, void *context,
                         KHWebSource *expanded, KHDiagnostic *diagnostic,
                         char *error, size_t capacity);

/* Main-file diagnostics retain line and column. Included-file diagnostics move
   into error as name.kh:line:column: message and use diagnostic.line = 0. */
void kh_remap_web_diagnostic(const KHWebSource *expanded, KHDiagnostic *diagnostic,
                             char *error, size_t capacity);
void kh_free_web_source(KHWebSource *expanded);

#endif
