#include "web.h"

#include <stdlib.h>
#include <string.h>

enum { PAGE_LIMIT = 24, SECTION_LIMIT = 12, BYTE_LIMIT = 4 * 1024 * 1024 };

typedef struct {
    char *text;
    size_t length, capacity;
} Buffer;

typedef struct {
    const char *text;
    size_t length;
} Span;

typedef struct {
    char *name, *title, *description;
    Buffer body;
    unsigned int depth;
} Page;

typedef struct {
    Page pages[PAGE_LIMIT];
    size_t count, bytes;
    Buffer styles, scripts;
    char accent[8], language[24];
} Website;

static const char stylesheet[] =
    ":root { color-scheme: light; --kh-ink: #172328; --kh-muted: #526169; --kh-line: #d8e0df; }\n"
    "*, *::before, *::after { box-sizing: border-box; }\n"
    "body { margin: 0; color: var(--kh-ink); background: #f7f9f8; "
    "font-family: system-ui, \"Yu Gothic UI\", sans-serif; line-height: 1.7; overflow-wrap: anywhere; }\n"
    ".kh-container { width: min(100% - 2.5rem, 48rem); margin-inline: auto; }\n"
    ".kh-header { background: white; border-block: .4rem solid var(--kh-accent); "
    "border-block-end: 1px solid var(--kh-line); padding: clamp(2.5rem, 10vw, 5.5rem) 0 2.75rem; }\n"
    "h1, h2, h3 { line-height: 1.25; text-wrap: balance; }\n"
    "h1 { font-size: clamp(2.25rem, 7vw, 4.6rem); letter-spacing: -.035em; margin: 0; }\n"
    ".kh-header p { color: var(--kh-muted); max-width: 62ch; margin: 1rem 0 0; }\n"
    "main { padding-block: 2.75rem 4.5rem; }\n"
    "main > :first-child, section > :first-child { margin-top: 0; }\n"
    "section { background: white; border: 1px solid var(--kh-line); border-radius: .8rem; "
    "margin-block: 1.25rem; padding: clamp(1rem, 5vw, 1.8rem); }\n"
    "section > :last-child { margin-bottom: 0; }\n"
    "img { display: block; max-width: 100%; height: auto; border-radius: .55rem; }\n"
    "a { color: #17504a; text-decoration-thickness: .08em; text-underline-offset: .18em; }\n"
    "button { color: var(--kh-accent-ink); background: var(--kh-accent); border: 0; border-radius: .55rem; "
    "font: inherit; font-weight: 650; padding: .65em 1em; cursor: pointer; text-align: start; }\n"
    "button:hover { filter: brightness(.9); }\n"
    ":focus-visible { outline: 3px solid #195a8a; outline-offset: 4px; }\n"
    ".kh-result { border-inline-start: .2rem solid var(--kh-accent); padding-inline-start: .75rem; "
    "white-space: pre-wrap; }\n";

static const char javascript[] =
    "document.addEventListener('click', (event) => {\n"
    "  if (!(event.target instanceof Element)) return;\n"
    "  const button = event.target.closest('[data-kh-message]');\n"
    "  if (!button) return;\n"
    "  const result = button.nextElementSibling;\n"
    "  if (result?.classList.contains('kh-result')) {\n"
    "    result.hidden = false;\n"
    "    result.textContent = button.dataset.khMessage;\n"
    "  }\n"
    "});\n";

static int is_name(Span span, const char *name) {
    size_t length = strlen(name);
    return span.length == length && memcmp(span.text, name, length) == 0;
}

static int append(Website *web, Buffer *buffer, const char *text, size_t length) {
    if (length > BYTE_LIMIT - web->bytes) return 0;
    size_t required = buffer->length + length + 1;
    if (required > buffer->capacity) {
        size_t capacity = buffer->capacity ? buffer->capacity : 256;
        while (capacity < required) capacity *= 2;
        char *next = realloc(buffer->text, capacity);
        if (!next) return 0;
        buffer->text = next;
        buffer->capacity = capacity;
    }
    if (length) memcpy(buffer->text + buffer->length, text, length);
    buffer->length += length;
    buffer->text[buffer->length] = 0;
    web->bytes += length;
    return 1;
}

static int literal(Website *web, Buffer *buffer, const char *text) {
    return append(web, buffer, text, strlen(text));
}

static int escaped(Website *web, Buffer *buffer, Span text) {
    size_t start = 0;
    for (size_t i = 0; i < text.length; i++) {
        const char *replacement = NULL;
        switch (text.text[i]) {
            case '&': replacement = "&amp;"; break;
            case '<': replacement = "&lt;"; break;
            case '>': replacement = "&gt;"; break;
            case '"': replacement = "&quot;"; break;
            case '\'': replacement = "&#39;"; break;
            case '\r': replacement = "&#13;"; break;
            default: break;
        }
        if (replacement) {
            if (!append(web, buffer, text.text + start, i - start)
                || !literal(web, buffer, replacement)) return 0;
            start = i + 1;
        }
    }
    return append(web, buffer, text.text + start, text.length - start);
}

static int element(Website *web, Buffer *buffer, const char *open, Span text, const char *close) {
    return literal(web, buffer, open) && escaped(web, buffer, text) && literal(web, buffer, close);
}

static void copy_error(char *error, size_t capacity, const char *message) {
    if (capacity) {
        size_t length = strlen(message);
        if (length >= capacity) length = capacity - 1;
        memcpy(error, message, length);
        error[length] = 0;
    }
}

static int web_error(char *error, size_t capacity, const char *message) {
    copy_error(error, capacity, message);
    return -1;
}

static Span span_of(const char *text) {
    Span span = {text, strlen(text)};
    return span;
}

static char *duplicate(Span text) {
    char *copy = malloc(text.length + 1);
    if (copy) {
        if (text.length) memcpy(copy, text.text, text.length);
        copy[text.length] = 0;
    }
    return copy;
}

static int ascii_letter(unsigned char c) {
    return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z');
}

static int ascii_digit(unsigned char c) {
    return c >= '0' && c <= '9';
}

static char lower_ascii(char c) {
    return c >= 'A' && c <= 'Z' ? (char)(c + ('a' - 'A')) : c;
}

static int starts_with_ci(Span text, const char *prefix) {
    size_t length = strlen(prefix);
    if (text.length < length) return 0;
    for (size_t i = 0; i < length; i++) {
        if (lower_ascii(text.text[i]) != lower_ascii(prefix[i])) return 0;
    }
    return 1;
}

static int equals_ci(Span text, const char *expected) {
    return text.length == strlen(expected) && starts_with_ci(text, expected);
}

static int valid_filename(Span text) {
    if (text.length <= 5 || text.length > 64
        || memcmp(text.text + text.length - 5, ".html", 5)) return 0;
    Span stem = {text.text, text.length - 5};
    if (!ascii_letter((unsigned char)stem.text[0]) && !ascii_digit((unsigned char)stem.text[0])) return 0;
    for (size_t i = 1; i < stem.length; i++) {
        unsigned char c = (unsigned char)stem.text[i];
        if (!(ascii_letter(c) || ascii_digit(c) || c == '-' || c == '_')) return 0;
    }
    if (equals_ci(stem, "con") || equals_ci(stem, "prn") || equals_ci(stem, "aux")
        || equals_ci(stem, "nul")) return 0;
    return !(stem.length == 4 && (starts_with_ci(stem, "com") || starts_with_ci(stem, "lpt"))
        && stem.text[3] >= '1' && stem.text[3] <= '9');
}

static int valid_url(Span text, int link) {
    if (!text.length || text.length > 4096) return 0;
    for (size_t i = 0; i < text.length; i++) {
        unsigned char c = (unsigned char)text.text[i];
        if (c <= 32 || c == 127 || c == '\\') return 0;
    }
    if (text.length > 1 && text.text[0] == '/' && text.text[1] == '/') return 0;
    if (text.text[0] == '#') return link;
    if (starts_with_ci(text, "https://")) return text.length > 8 && text.text[8] != '/';
    if (starts_with_ci(text, "http://")) return text.length > 7 && text.text[7] != '/';
    if (starts_with_ci(text, "mailto:")) return link && text.length > 7;
    for (size_t i = 0; i < text.length && !strchr("/?#", text.text[i]); i++) {
        if (text.text[i] == ':') return 0;
    }
    return 1;
}

static int valid_language(Span text) {
    if (text.length < 2 || text.length >= sizeof(((Website *)0)->language)) return 0;
    size_t subtag = 0;
    int first = 1;
    for (size_t i = 0; i < text.length; i++) {
        unsigned char c = (unsigned char)text.text[i];
        if (c == '-') {
            if (!subtag || (first && subtag < 2)) return 0;
            subtag = 0;
            first = 0;
        } else {
            if ((!ascii_letter(c) && (first || !ascii_digit(c))) || ++subtag > 8) return 0;
        }
    }
    return subtag && (!first || subtag >= 2);
}

static int hex_value(char c) {
    c = lower_ascii(c);
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    return -1;
}

static int valid_theme(Span text) {
    if (text.length != 7 || text.text[0] != '#') return 0;
    for (size_t i = 1; i < text.length; i++) {
        if (hex_value(text.text[i]) < 0) return 0;
    }
    return 1;
}

static const char *theme_ink(const char *accent) {
    double components[3];
    for (int i = 0; i < 3; i++) {
        double srgb = (hex_value(accent[1 + i * 2]) * 16 + hex_value(accent[2 + i * 2])) / 255.0;
        if (srgb <= 0.04045) {
            components[i] = srgb / 12.92;
        } else {
            /* Polynomial approximation of the sRGB gamma transform. */
            components[i] = srgb * (srgb * (srgb * 0.305306011 + 0.682171111) + 0.012522878);
        }
    }
    double luminance = 0.2126 * components[0] + 0.7152 * components[1] + 0.0722 * components[2];
    return luminance > 0.179 ? "#000" : "#fff";
}

static int text_args(const KHHostValue *args, size_t count) {
    for (size_t i = 0; i < count; i++) {
        if (args[i].type != KH_WEB_TEXT) return 0;
        for (size_t j = 0; j < args[i].length; j++) {
            unsigned char c = (unsigned char)args[i].text[j];
            if (c < 32 && c != '\t' && c != '\r' && c != '\n') return 0;
        }
    }
    return 1;
}

enum Command {
    UNKNOWN, PAGE, HEADING, TEXT, LINK, IMAGE, SECTION, SECTION_END,
    BUTTON, CSS, SCRIPT, THEME, LANGUAGE
};

static const struct CommandSpec {
    const char *name;
    enum Command kind;
    unsigned int minimum, maximum;
    const char *usage;
} commands[] = {
    {"page", PAGE, 2, 3, "page needs a title and description, with an optional .html filename first."},
    {"heading", HEADING, 1, 1, "heading needs one text argument."},
    {"text", TEXT, 1, 1, "text needs one text argument."},
    {"link", LINK, 2, 2, "link needs a label and URL."},
    {"image", IMAGE, 2, 2, "image needs a source URL and alt text."},
    {"section", SECTION, 1, 1, "section needs one title argument."},
    {"section_end", SECTION_END, 0, 0, "section_end does not take arguments."},
    {"button", BUTTON, 2, 2, "button needs a label and message."},
    {"css", CSS, 1, 1, "css needs one CSS text argument."},
    {"script", SCRIPT, 1, 1, "script needs one JavaScript text argument."},
    {"theme", THEME, 1, 1, "theme needs a color such as \"#176b58\"."},
    {"language", LANGUAGE, 1, 1, "language needs a language tag such as \"ja\" or \"en-US\"."}
};

static int add_page(Website *web, Span name, Span title, Span description,
                    char *error, size_t error_size) {
    if (web->count && web->pages[web->count - 1].depth) {
        return web_error(error, error_size, "Close the open section with section_end() before starting a page.");
    }
    if (web->count >= PAGE_LIMIT) return web_error(error, error_size, "A website can contain up to 24 pages.");
    if (!valid_filename(name)) {
        return web_error(error, error_size, "Use a simple .html filename such as \"about.html\" with no folders.");
    }
    if (!title.length || title.length > 400 || description.length > 1000) {
        return web_error(error, error_size, "Use a nonempty page title and a short description.");
    }
    for (size_t i = 0; i < web->count; i++) {
        if (equals_ci(name, web->pages[i].name)) {
            return web_error(error, error_size, "Each page needs a different .html filename.");
        }
    }
    Page *page = &web->pages[web->count++];
    page->name = duplicate(name);
    page->title = duplicate(title);
    page->description = duplicate(description);
    if (!page->name || !page->title || !page->description) {
        return web_error(error, error_size, "There is not enough memory to create a website page.");
    }
    return 1;
}

static int web_call(const char *name, size_t name_length, const KHHostValue *args, size_t count,
                    char *error, size_t error_size, void *context) {
    Website *web = context;
    const struct CommandSpec *command = NULL;
    for (size_t i = 0; i < sizeof(commands) / sizeof(commands[0]); i++) {
        if (is_name((Span){name, name_length}, commands[i].name)) {
            command = &commands[i];
            break;
        }
    }
    if (!command) return 0;
    if (count < command->minimum || count > command->maximum) {
        return web_error(error, error_size, command->usage);
    }
    if (!text_args(args, count)) {
        return web_error(error, error_size, "Website arguments must be text without control characters.");
    }
    Span first = count > 0 ? (Span){args[0].text, args[0].length} : span_of("");
    Span second = count > 1 ? (Span){args[1].text, args[1].length} : span_of("");
    if (command->kind == PAGE) {
        if (count == 2) return add_page(web, span_of("index.html"), first, second, error, error_size);
        return add_page(web, first, second, (Span){args[2].text, args[2].length}, error, error_size);
    }
    if (command->kind == THEME || command->kind == LANGUAGE) {
        int is_theme = command->kind == THEME;
        if (!(is_theme ? valid_theme(first) : valid_language(first))) {
            return web_error(error, error_size, command->usage);
        }
        char *destination = is_theme ? web->accent : web->language;
        memcpy(destination, first.text, first.length);
        destination[first.length] = 0;
        return 1;
    }
    int ok = 0;
    if (command->kind == CSS || command->kind == SCRIPT) {
        Buffer *asset = command->kind == CSS ? &web->styles : &web->scripts;
        ok = append(web, asset, first.text, first.length) && literal(web, asset, "\n");
    } else {
        if (!web->count) return web_error(error, error_size, "Start with page(title, description).");
        Page *page = &web->pages[web->count - 1];
        Buffer *body = &page->body;
        switch (command->kind) {
            case HEADING:
                ok = page->depth
                    ? element(web, body, "<h3>", first, "</h3>\n")
                    : element(web, body, "<h2>", first, "</h2>\n");
                break;
            case TEXT:
                ok = element(web, body, "<p>", first, "</p>\n");
                break;
            case LINK:
                if (!valid_url(second, 1)) return web_error(error, error_size, "Use a local, http, https, or mailto link.");
                ok = element(web, body, "<p><a href=\"", second, "\">")
                    && element(web, body, "", first, "</a></p>\n");
                break;
            case IMAGE:
                if (!valid_url(first, 0)) return web_error(error, error_size, "Use a local, http, or https image URL.");
                ok = element(web, body, "<p><img src=\"", first, "\" alt=\"")
                    && element(web, body, "", second, "\" loading=\"lazy\" decoding=\"async\"></p>\n");
                break;
            case SECTION:
                if (page->depth >= SECTION_LIMIT) return web_error(error, error_size, "Too many nested sections.");
                ok = page->depth
                    ? element(web, body, "<section>\n<h3>", first, "</h3>\n")
                    : element(web, body, "<section>\n<h2>", first, "</h2>\n");
                page->depth++;
                break;
            case SECTION_END:
                if (!page->depth) return web_error(error, error_size, "section_end() needs a matching section().");
                ok = literal(web, body, "</section>\n");
                page->depth--;
                break;
            case BUTTON:
                ok = element(web, body, "<div class=\"kh-action\"><button type=\"button\" data-kh-message=\"", second, "\">")
                    && element(web, body, "", first, "</button><p class=\"kh-result\" role=\"status\" hidden></p></div>\n");
                break;
            default:
                return 0;
        }
    }
    return ok ? 1 : web_error(error, error_size, "The website is too large or there is not enough memory.");
}

static int render_page(Website *web, const Page *page, Buffer *html) {
    return element(web, html, "<!doctype html>\n<html lang=\"", span_of(web->language), "\">\n")
        && literal(web, html, "<head>\n<meta charset=\"utf-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n")
        && element(web, html, "<title>", span_of(page->title), "</title>\n")
        && element(web, html, "<meta name=\"description\" content=\"", span_of(page->description), "\">\n")
        && literal(web, html, "<link rel=\"stylesheet\" href=\"styles.css\">\n<script defer src=\"app.js\"></script>\n")
        && element(web, html, "</head>\n<body>\n<header class=\"kh-header\"><div class=\"kh-container\">\n<h1>", span_of(page->title), "</h1>\n")
        && (!*page->description || element(web, html, "<p>", span_of(page->description), "</p>\n"))
        && literal(web, html, "</div></header>\n<main class=\"kh-container\">\n")
        && append(web, html, page->body.text, page->body.length)
        && literal(web, html, "</main>\n</body>\n</html>\n");
}

static int render_styles(Website *web, Buffer *result) {
    return literal(web, result, ":root { --kh-accent: ")
        && literal(web, result, web->accent)
        && literal(web, result, "; --kh-accent-ink: ")
        && literal(web, result, theme_ink(web->accent))
        && literal(web, result, "; }\n")
        && literal(web, result, stylesheet)
        && append(web, result, web->styles.text, web->styles.length);
}

static int render_scripts(Website *web, Buffer *result) {
    return literal(web, result, javascript)
        && append(web, result, web->scripts.text, web->scripts.length);
}

static int finish_file(KHWebFile *file, const char *name, Buffer *contents, int rendered) {
    file->name = rendered ? duplicate(span_of(name)) : NULL;
    file->text = contents->text;
    file->length = contents->length;
    *contents = (Buffer){0};
    return file->name != NULL;
}

void kh_free_site(KHSite *site) {
    if (!site) return;
    for (size_t i = 0; i < site->count; i++) {
        free(site->files[i].name);
        free(site->files[i].text);
    }
    free(site->files);
    *site = (KHSite){0};
}

static void free_website(Website *web) {
    for (size_t i = 0; i < web->count; i++) {
        Page *page = &web->pages[i];
        free(page->name);
        free(page->title);
        free(page->description);
        free(page->body.text);
    }
    free(web->styles.text);
    free(web->scripts.text);
}

static int fail_site(KHDiagnostic *diagnostic, const char *message) {
    diagnostic->line = 1;
    diagnostic->column = 1;
    copy_error(diagnostic->message, sizeof(diagnostic->message), message);
    return 0;
}

static int write_site(Website *web, KHSite *site, KHDiagnostic *diagnostic) {
    size_t index_page = 0;
    while (index_page < web->count && strcmp(web->pages[index_page].name, "index.html")) index_page++;
    if (index_page == web->count) {
        return fail_site(diagnostic, "Create index.html using page(title, description).");
    }
    if (web->pages[web->count - 1].depth) {
        return fail_site(diagnostic, "Close all open sections with section_end().");
    }

    size_t count = web->count + 2;
    site->files = calloc(count, sizeof(*site->files));
    if (!site->files) return fail_site(diagnostic, "There is not enough memory to create the website.");
    site->count = count;
    Buffer contents = {0};
    int ok = 1;
    for (size_t i = 0; i < web->count && ok; i++) {
        size_t page_index = i == 0 ? index_page : i <= index_page ? i - 1 : i;
        Page *page = &web->pages[page_index];
        int rendered = render_page(web, page, &contents);
        ok = finish_file(&site->files[i], page->name, &contents, rendered);
    }
    if (ok) {
        int rendered = render_styles(web, &contents);
        ok = finish_file(&site->files[web->count], "styles.css", &contents, rendered);
    }
    if (ok) {
        int rendered = render_scripts(web, &contents);
        ok = finish_file(&site->files[web->count + 1], "app.js", &contents, rendered);
    }
    if (!ok) {
        kh_free_site(site);
        return fail_site(diagnostic, "The website is too large or there is not enough memory.");
    }
    return 1;
}

int kh_generate_site(const char *source, KHSite *site, KHDiagnostic *diagnostic) {
    KHDiagnostic local_diagnostic;
    if (!diagnostic) diagnostic = &local_diagnostic;
    if (!site) return fail_site(diagnostic, "A website result is required.");
    *site = (KHSite){0};
    Website web = {.accent = "#176b58", .language = "ja"};
    int ok = kh_run_host(source, NULL, NULL, web_call, &web, diagnostic);
    if (ok) ok = write_site(&web, site, diagnostic);
    free_website(&web);
    return ok;
}
