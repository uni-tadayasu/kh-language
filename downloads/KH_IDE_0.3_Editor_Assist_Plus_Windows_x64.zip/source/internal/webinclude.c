#include "webinclude.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

enum {
    INCLUDE_DEPTH_LIMIT = 8,
    EXPANDED_BYTE_LIMIT = 800000,
    EXPANDED_LINE_LIMIT = 200000,
    ROOT_FILE = -1
};

struct KHWebLine {
    int file;
    int original_line;
};

typedef struct {
    KHWebSource *result;
    KHWebLoad load;
    void *context;
    KHDiagnostic *diagnostic;
    char *error;
    size_t error_capacity;
    size_t expanded_length;
    size_t expanded_capacity;
    size_t line_capacity;
    size_t input_length;
    const char *active[INCLUDE_DEPTH_LIMIT];
} Expander;

static unsigned char ascii_lower(unsigned char value) {
    if (value >= 'A' && value <= 'Z') return (unsigned char)(value - 'A' + 'a');
    return value;
}

static int same_name(const char *left, const char *right) {
    while (*left && ascii_lower((unsigned char)*left) == ascii_lower((unsigned char)*right)) {
        ++left;
        ++right;
    }
    return *left == *right;
}

static int reserved_name(const char *name, size_t length) {
    if (length != 3 && length != 4) return 0;
    char stem[5] = {0};
    for (size_t index = 0; index < length; ++index) {
        stem[index] = (char)ascii_lower((unsigned char)name[index]);
    }
    if (length == 3) {
        return !strcmp(stem, "con") || !strcmp(stem, "prn")
            || !strcmp(stem, "aux") || !strcmp(stem, "nul");
    }
    return stem[3] >= '0' && stem[3] <= '9'
        && (!memcmp(stem, "com", 3) || !memcmp(stem, "lpt", 3));
}

static int valid_name(const char *name, size_t length) {
    if (length < 4 || length > KH_WEB_INCLUDE_NAME_MAX) return 0;
    size_t stem_length = length - 3;
    if (name[stem_length] != '.' || ascii_lower((unsigned char)name[stem_length + 1]) != 'k'
        || ascii_lower((unsigned char)name[stem_length + 2]) != 'h'
        || reserved_name(name, stem_length)) return 0;
    for (size_t index = 0; index < stem_length; ++index) {
        unsigned char character = ascii_lower((unsigned char)name[index]);
        if ((character >= 'a' && character <= 'z') || (character >= '0' && character <= '9')
            || character == '_' || character == '-') continue;
        return 0;
    }
    return 1;
}

static int spacing(char character) {
    return character == ' ' || character == '\t';
}

static int valid_utf8(const char *text, size_t length) {
    const unsigned char *bytes = (const unsigned char *)text;
    for (size_t index = 0; index < length;) {
        unsigned char first = bytes[index++];
        if (first < 0x80) continue;
        unsigned char low = 0x80;
        unsigned char high = 0xbf;
        size_t tails;
        if (first >= 0xc2 && first <= 0xdf) {
            tails = 1;
        } else if (first >= 0xe0 && first <= 0xef) {
            tails = 2;
            if (first == 0xe0) low = 0xa0;
            if (first == 0xed) high = 0x9f;
        } else if (first >= 0xf0 && first <= 0xf4) {
            tails = 3;
            if (first == 0xf0) low = 0x90;
            if (first == 0xf4) high = 0x8f;
        } else {
            return 0;
        }
        if (length - index < tails || bytes[index] < low || bytes[index] > high) return 0;
        ++index;
        while (--tails) {
            if ((bytes[index++] & 0xc0) != 0x80) return 0;
        }
    }
    return 1;
}

static int read_directive(const char *start, const char *end, int *column,
                          char name[KH_WEB_INCLUDE_NAME_MAX + 1], const char **message) {
    const char *cursor = start;
    while (cursor != end && spacing(*cursor)) ++cursor;
    if (end - cursor < 3 || memcmp(cursor, "use", 3)) return 0;
    *column = (int)(cursor - start) + 1;
    cursor += 3;
    if (cursor != end && !spacing(*cursor) && *cursor != '#') return 0;
    while (cursor != end && spacing(*cursor)) ++cursor;
    if (cursor != end && (*cursor == '=' || *cursor == '(')) return 0;
    if (cursor == end || *cursor != '"') {
        *message = "Write use \"name.kh\" on its own line.";
        return -1;
    }
    const char *name_start = ++cursor;
    while (cursor != end && *cursor != '"') ++cursor;
    if (cursor == end) {
        *message = "Close the .kh filename with a double quote.";
        return -1;
    }
    size_t name_length = (size_t)(cursor - name_start);
    if (!valid_name(name_start, name_length)) {
        *message = "use expects a .kh filename in the same folder, using ASCII letters, digits, _ or -.";
        return -1;
    }
    memcpy(name, name_start, name_length);
    name[name_length] = '\0';
    ++cursor;
    while (cursor != end && spacing(*cursor)) ++cursor;
    if (cursor != end && *cursor != '#') {
        *message = "Only a comment can follow the .kh filename.";
        return -1;
    }
    return 1;
}

static void format_error(char *error, size_t capacity, const char *name, int line,
                         int column, const char *message) {
    if (!error || capacity == 0) return;
    snprintf(error, capacity, "%s:%d:%d: %s", name, line, column, message);
    error[capacity - 1] = '\0';
}

static int fail(Expander *state, int file, int line, int column, const char *message) {
    KHDiagnostic *diagnostic = state->diagnostic;
    snprintf(diagnostic->message, sizeof(diagnostic->message), "%s", message);
    diagnostic->message[sizeof(diagnostic->message) - 1] = '\0';
    if (file == ROOT_FILE) {
        diagnostic->line = line;
        diagnostic->column = column;
    } else {
        diagnostic->line = 0;
        diagnostic->column = 0;
        format_error(state->error, state->error_capacity, state->result->files[file],
                     line, column, message);
    }
    return 0;
}

static int append_line(Expander *state, int file, int line, const char *source, size_t length) {
    KHWebSource *result = state->result;
    size_t separator = result->line_count != 0;
    size_t required = state->expanded_length + separator + length + 1;
    if (required > EXPANDED_BYTE_LIMIT + 1 || result->line_count == EXPANDED_LINE_LIMIT) {
        return fail(state, file, line, 1, "The expanded website source is too large.");
    }
    if (required > state->expanded_capacity) {
        size_t capacity = state->expanded_capacity ? state->expanded_capacity * 2 : 256;
        if (capacity < required) capacity = required;
        char *buffer = realloc(result->source, capacity);
        if (!buffer) return fail(state, file, line, 1, "Could not allocate expanded website source.");
        result->source = buffer;
        state->expanded_capacity = capacity;
    }
    if (result->line_count == state->line_capacity) {
        size_t capacity = state->line_capacity ? state->line_capacity * 2 : 32;
        struct KHWebLine *lines = realloc(result->lines, capacity * sizeof(*lines));
        if (!lines) return fail(state, file, line, 1, "Could not allocate website source locations.");
        result->lines = lines;
        state->line_capacity = capacity;
    }

    if (separator) result->source[state->expanded_length++] = '\n';
    memcpy(result->source + state->expanded_length, source, length);
    state->expanded_length += length;
    result->source[state->expanded_length] = '\0';
    result->lines[result->line_count++] = (struct KHWebLine){file, line};
    return 1;
}

static int expand_lines(Expander *state, const char *source, size_t length, int file, size_t depth);

static int expand_include(Expander *state, const char *name, int file,
                          int line, int column, size_t depth) {
    if (!state->load) {
        return fail(state, file, line, column, "Save the main .kh file before using related files.");
    }
    for (size_t index = 0; index < depth; ++index) {
        if (same_name(state->active[index], name)) {
            return fail(state, file, line, column, "Circular use directive.");
        }
    }
    if (depth >= INCLUDE_DEPTH_LIMIT || state->result->file_count == KH_WEB_INCLUDE_COUNT) {
        return fail(state, file, line, column, "Too many nested or repeated use directives.");
    }

    char *source = NULL;
    size_t length = 0;
    char message[160];
    if (!state->load(name, &source, &length, state->context)) {
        snprintf(message, sizeof(message), "Could not read \"%s\" in the main .kh file's folder.", name);
        return fail(state, file, line, column, message);
    }
    if (length > EXPANDED_BYTE_LIMIT - state->input_length) {
        free(source);
        return fail(state, file, line, column, "The combined .kh input is too large.");
    }
    if (length && (!source || memchr(source, '\0', length) || !valid_utf8(source, length))) {
        free(source);
        snprintf(message, sizeof(message), "\"%s\" must be UTF-8 text with no NUL bytes.", name);
        return fail(state, file, line, column, message);
    }
    size_t name_length = strlen(name);
    char *saved_name = malloc(name_length + 1);
    if (!saved_name) {
        free(source);
        return fail(state, file, line, column, "Could not allocate an included filename.");
    }
    memcpy(saved_name, name, name_length + 1);
    int included_file = (int)state->result->file_count;
    state->result->files[state->result->file_count++] = saved_name;
    state->active[depth] = saved_name;
    state->input_length += length;
    int ok = expand_lines(state, source ? source : "", length, included_file, depth + 1);
    free(source);
    return ok;
}

static int expand_lines(Expander *state, const char *source, size_t length, int file, size_t depth) {
    const char *end = source + length;
    if (length >= 3 && !memcmp(source, "\xef\xbb\xbf", 3)) source += 3;
    int line = 1;
    for (;;) {
        const char *line_end = source;
        while (line_end != end && *line_end != '\r' && *line_end != '\n') ++line_end;
        char name[KH_WEB_INCLUDE_NAME_MAX + 1];
        const char *message = NULL;
        int column = 1;
        int directive = read_directive(source, line_end, &column, name, &message);
        if (directive < 0) return fail(state, file, line, column, message);
        if (directive > 0) {
            if (!expand_include(state, name, file, line, column, depth)) return 0;
        } else if (!append_line(state, file, line, source, (size_t)(line_end - source))) {
            return 0;
        }
        if (line_end == end) break;
        source = line_end + 1;
        if (*line_end == '\r' && source != end && *source == '\n') ++source;
        ++line;
    }
    return 1;
}

int kh_expand_web_source(const char *source, KHWebLoad load, void *context,
                         KHWebSource *expanded, KHDiagnostic *diagnostic,
                         char *error, size_t capacity) {
    KHDiagnostic discard = {0};
    if (!diagnostic) diagnostic = &discard;
    memset(diagnostic, 0, sizeof(*diagnostic));
    if (error && capacity) error[0] = '\0';
    if (!expanded) return 0;
    memset(expanded, 0, sizeof(*expanded));
    Expander state = { .result = expanded, .load = load, .context = context,
                       .diagnostic = diagnostic, .error = error, .error_capacity = capacity };
    if (!source) return fail(&state, ROOT_FILE, 1, 1, "Expected a main .kh source file.");
    state.input_length = strlen(source);
    if (state.input_length > EXPANDED_BYTE_LIMIT) {
        return fail(&state, ROOT_FILE, 1, 1, "The main .kh input is too large.");
    }
    if (!valid_utf8(source, state.input_length)) {
        return fail(&state, ROOT_FILE, 1, 1, "The main .kh file must be valid UTF-8.");
    }
    if (expand_lines(&state, source, state.input_length, ROOT_FILE, 0)) return 1;
    kh_free_web_source(expanded);
    return 0;
}

void kh_remap_web_diagnostic(const KHWebSource *expanded, KHDiagnostic *diagnostic,
                             char *error, size_t capacity) {
    if (!expanded || !diagnostic || diagnostic->line < 1
        || (size_t)diagnostic->line > expanded->line_count) return;
    struct KHWebLine location = expanded->lines[diagnostic->line - 1];
    diagnostic->line = location.original_line;
    if (location.file != ROOT_FILE) {
        format_error(error, capacity, expanded->files[location.file], diagnostic->line,
                     diagnostic->column, diagnostic->message);
        diagnostic->line = 0;
        diagnostic->column = 0;
    }
}

void kh_free_web_source(KHWebSource *expanded) {
    if (!expanded) return;
    free(expanded->source);
    free(expanded->lines);
    for (size_t index = 0; index < expanded->file_count; ++index) free(expanded->files[index]);
    memset(expanded, 0, sizeof(*expanded));
}
