#include "editor_diagnostics.h"
#include "webinclude.h"

#include <string.h>

static int blank_include(const char *name, char **source, size_t *length, void *context) {
    (void)name;
    (void)context;
    *source = NULL;
    *length = 0;
    return 1;
}

/* Included files can supply block delimiters. Suppress only diagnostics that
   a blank include on the corresponding side of the error might explain. */
static int could_depend_on_include(const KHWebSource *expanded, const KHDiagnostic *diagnostic) {
    if (!expanded->file_count || diagnostic->line < 1) return 0;

    size_t first = 1;
    size_t end = (size_t)diagnostic->line;
    const char *message = diagnostic->message;
    if (strncmp(message, "Add an end to close this ", sizeof("Add an end to close this ") - 1) == 0) {
        first = end + 1;
        end = expanded->line_count + 1;
    } else if (strcmp(message, "This end has no matching if, repeat, or function.") != 0 &&
               strcmp(message, "else must be inside an if block and can appear there only once.") != 0 &&
               strcmp(message, "return can only appear inside a function.") != 0 &&
               strcmp(message, "Define functions outside other blocks.") != 0 &&
               strcmp(message, "These blocks are nested too deeply.") != 0) {
        return 0;
    }

    KHDiagnostic location = {0};
    for (size_t line = first; line < end; ++line) {
        location.line = (int)line;
        kh_remap_web_diagnostic(expanded, &location, NULL, 0);
        if (location.line == 0) return 1;
    }
    return 0;
}

int kh_editor_check(const char *source, KHDiagnostic *diagnostic) {
    KHDiagnostic local = {0};
    if (!diagnostic) diagnostic = &local;

    KHWebSource expanded = {0};
    if (!kh_expand_web_source(source, blank_include, NULL, &expanded, diagnostic, NULL, 0)) {
        return 0;
    }

    int valid = kh_check(expanded.source, diagnostic);
    if (!valid && could_depend_on_include(&expanded, diagnostic)) {
        *diagnostic = (KHDiagnostic){0};
        valid = 1;
    } else if (!valid) {
        kh_remap_web_diagnostic(&expanded, diagnostic, NULL, 0);
        if (diagnostic->line == 0) diagnostic->line = diagnostic->column = 1;
    }
    kh_free_web_source(&expanded);
    return valid;
}
