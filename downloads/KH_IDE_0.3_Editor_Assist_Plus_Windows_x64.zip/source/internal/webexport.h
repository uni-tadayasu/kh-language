#ifndef KH_WEBEXPORT_H
#define KH_WEBEXPORT_H

#include "lang.h"

/* The chosen .html path names a new sibling folder ending in "-site". */
int kh_export_site(const char *source, const unsigned short *source_path,
                   const unsigned short *selected_html_path,
                   KHDiagnostic *diagnostic, char *error, size_t capacity);

#endif
