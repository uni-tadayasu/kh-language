#ifndef KH_BUNDLE_H
#define KH_BUNDLE_H

#include <stdint.h>

#define KH_SOURCE_MAX_BYTES 800000u
#define KH_TRAILER_SIZE 16u

static const unsigned char kh_bundle_magic[8] = {'K', 'H', 'E', 'X', 'E', 1, '\r', '\n'};

static inline void kh_store_length(unsigned char *bytes, uint32_t length) {
    for (unsigned int index = 0; index < 4; ++index) {
        bytes[index] = (unsigned char)(length >> (index * 8));
        bytes[index + 4] = (unsigned char)(~length >> (index * 8));
    }
}

static inline uint32_t kh_read_length(const unsigned char *bytes) {
    uint32_t length = 0;
    for (unsigned int index = 0; index < 4; ++index) {
        length |= (uint32_t)bytes[index] << (index * 8);
    }
    return length;
}

#endif
