#include "buildexe.h"
#include "bundle.h"
#include "lang.h"
#include "winfile.h"
#include <stdlib.h>
#include <string.h>

extern const unsigned char kh_runtime_image[];
extern const unsigned char kh_runtime_image_end[];

static void set_error(char *error, size_t capacity, const char *message, Dword code) {
    if (!error || capacity == 0) return;
    size_t used = 0;
    while (used + 1 < capacity && *message) error[used++] = *message++;
    if (code && capacity - used > 15) {
        const char *label = " (Windows ";
        while (*label) error[used++] = *label++;
        char digits[10];
        size_t length = 0;
        do {
            digits[length++] = (char)('0' + code % 10);
            code /= 10;
        } while (code);
        while (length && used + 2 < capacity) error[used++] = digits[--length];
        error[used++] = ')';
    }
    error[used] = '\0';
}

static Wide *temporary_path(const Wide *path, size_t *suffix_start) {
    size_t length = 0;
    while (path[length]) ++length;
    if (length == 0 || length > 32730) return NULL;
    Wide *temporary = malloc((length + 27) * sizeof(*temporary));
    if (!temporary) return NULL;
    memcpy(temporary, path, length * sizeof(*temporary));
    const Wide suffix[] = {'.', 'k', 'h', 't', 'm', 'p', '-', 0};
    memcpy(temporary + length, suffix, sizeof(suffix));
    *suffix_start = length + 7;
    return temporary;
}

static void write_hex(Wide *text, Dword value) {
    const char digits[] = "0123456789abcdef";
    for (int index = 7; index >= 0; --index) {
        text[index] = (Wide)digits[value & 15];
        value >>= 4;
    }
}

int kh_build_exe(const char *utf8_source, const Wide *path,
                 char *error, size_t error_size) {
    KHDiagnostic diagnostic;
    if (!utf8_source || !path) {
        set_error(error, error_size, "Invalid build input.", 0);
        return 0;
    }
    size_t source_length = strlen(utf8_source);
    if (source_length > KH_SOURCE_MAX_BYTES) {
        set_error(error, error_size, "The KH source is too large.", 0);
        return 0;
    }
    if (!kh_check(utf8_source, &diagnostic)) {
        set_error(error, error_size, diagnostic.message, 0);
        return 0;
    }
    size_t suffix_start = 0;
    Wide *temporary = temporary_path(path, &suffix_start);
    if (!temporary) {
        set_error(error, error_size, "Could not prepare the output path.", 0);
        return 0;
    }

    static Dword sequence;
    Handle output = INVALID_FILE;
    Dword code = 0;
    write_hex(temporary + suffix_start, GetCurrentProcessId());
    temporary[suffix_start + 8] = '-';
    temporary[suffix_start + 17] = 0;
    for (int attempt = 0; attempt < 32; ++attempt) {
        write_hex(temporary + suffix_start + 9, sequence++);
        output = CreateFileW(temporary, GENERIC_WRITE_KH, 0, NULL,
                             CREATE_NEW_KH, FILE_ATTRIBUTE_NORMAL_KH, NULL);
        if (output != INVALID_FILE) break;
        code = GetLastError();
        if (code != 80 && code != 183) break;
    }
    if (output == INVALID_FILE) {
        set_error(error, error_size, "Could not create the output file.", code);
        free(temporary);
        return 0;
    }

    unsigned char trailer[KH_TRAILER_SIZE];
    memcpy(trailer, kh_bundle_magic, sizeof(kh_bundle_magic));
    kh_store_length(trailer + 8, (uint32_t)source_length);
    size_t image_length = (uintptr_t)kh_runtime_image_end - (uintptr_t)kh_runtime_image;
    int written = kh_write_all(output, kh_runtime_image, image_length)
               && kh_write_all(output, utf8_source, source_length)
               && kh_write_all(output, trailer, sizeof(trailer));
    if (!written) code = GetLastError();
    if (!CloseHandle(output) && written) {
        written = 0;
        code = GetLastError();
    }
    if (written && !MoveFileExW(temporary, path, 0x1u | 0x8u)) {
        written = 0;
        code = GetLastError();
    }
    if (!written) {
        DeleteFileW(temporary);
        set_error(error, error_size, "Could not save the executable.", code);
    }
    free(temporary);
    return written;
}
