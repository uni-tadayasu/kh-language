#ifndef KH_WINFILE_H
#define KH_WINFILE_H

#include <stddef.h>
#include <stdint.h>

typedef unsigned short Wide;
typedef unsigned int Dword;
typedef void *Handle;

extern Handle CreateFileW(const Wide *, Dword, Dword, void *, Dword, Dword, Handle);
extern int GetFileSizeEx(Handle, int64_t *);
extern int SetFilePointerEx(Handle, int64_t, int64_t *, Dword);
extern int ReadFile(Handle, void *, Dword, Dword *, void *);
extern int WriteFile(Handle, const void *, Dword, Dword *, void *);
extern int CloseHandle(Handle);
extern Dword GetLastError(void);
extern int DeleteFileW(const Wide *);
extern int MoveFileExW(const Wide *, const Wide *, Dword);
extern Dword GetCurrentProcessId(void);
extern Dword GetModuleFileNameW(Handle, Wide *, Dword);
extern Handle GetStdHandle(Dword);
extern int GetConsoleMode(Handle, Dword *);
extern Dword GetConsoleProcessList(Dword *, Dword);
extern int WriteConsoleW(Handle, const Wide *, Dword, Dword *, void *);
extern int ReadConsoleW(Handle, Wide *, Dword, Dword *, void *);
extern int MultiByteToWideChar(Dword, Dword, const char *, int, Wide *, int);
extern void ExitProcess(Dword);

#define INVALID_FILE ((Handle)(intptr_t)-1)
#define GENERIC_READ_KH 0x80000000u
#define GENERIC_WRITE_KH 0x40000000u
#define CREATE_NEW_KH 1u
#define OPEN_EXISTING_KH 3u
#define FILE_ATTRIBUTE_NORMAL_KH 0x80u

static inline int kh_read_all(Handle file, void *buffer, size_t size) {
    unsigned char *bytes = buffer;
    while (size != 0) {
        Dword count = 0;
        Dword requested = size > 1048576u ? 1048576u : (Dword)size;
        if (!ReadFile(file, bytes, requested, &count, NULL) || count == 0) return 0;
        bytes += count;
        size -= count;
    }
    return 1;
}

static inline int kh_write_all(Handle file, const void *buffer, size_t size) {
    const unsigned char *bytes = buffer;
    while (size != 0) {
        Dword count = 0;
        Dword requested = size > 1048576u ? 1048576u : (Dword)size;
        if (!WriteFile(file, bytes, requested, &count, NULL) || count == 0) return 0;
        bytes += count;
        size -= count;
    }
    return 1;
}

#endif
