#ifndef KH_WEB_H
#define KH_WEB_H

#include "lang.h"

typedef struct {
    char *name;
    char *text;
    size_t length;
} KHWebFile;

typedef struct {
    KHWebFile *files;
    size_t count;
} KHSite;

/* Generates a static website from UTF-8 KH source. Release results with kh_free_site. */
int kh_generate_site(const char *source, KHSite *site, KHDiagnostic *diagnostic);
void kh_free_site(KHSite *site);

#endif
