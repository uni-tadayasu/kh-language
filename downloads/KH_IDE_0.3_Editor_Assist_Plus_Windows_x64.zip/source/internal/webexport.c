#include "webexport.h"
#include "web.h"
#include "webinclude.h"
#include "winfile.h"

#include <stdlib.h>
#include <string.h>

extern int CreateDirectoryW(const Wide *, void *);
extern int RemoveDirectoryW(const Wide *);
extern Dword GetFileAttributesW(const Wide *);

enum { MAX_KH_FILE_BYTES = 800003, MAX_WINDOWS_PATH = 32767 };

struct WebProject {
    const Wide *source_path;
    size_t parent_length;
};

static size_t wide_length(const Wide *path) {
    size_t length = 0;
    while (path[length]) ++length;
    return length;
}

static size_t parent_length(const Wide *path) {
    size_t result = 0;
    for (size_t index = 0; path[index]; ++index) {
        if (path[index] == '\\' || path[index] == '/') result = index + 1;
    }
    return result;
}

static void copy_narrow_to_wide(Wide *destination, const char *source) {
    do {
        *destination++ = (Wide)(unsigned char)*source;
    } while (*source++);
}

static void set_error(char *error, size_t capacity, const char *message, Dword code) {
    if (!error || !capacity) return;
    size_t used = 0;
    while (*message && used + 1 < capacity) error[used++] = *message++;
    if (code && capacity - used >= 23) {
        const char *label = " (Windows ";
        while (*label) error[used++] = *label++;
        char digits[10];
        size_t count = 0;
        do {
            digits[count++] = (char)('0' + code % 10);
            code /= 10;
        } while (code);
        while (count) error[used++] = digits[--count];
        error[used++] = ')';
    }
    error[used] = 0;
}

static unsigned int ascii_lower(unsigned int character) {
    return character >= 'A' && character <= 'Z' ? character + ('a' - 'A') : character;
}

static int is_main_file(const struct WebProject *project, const char *name) {
    const Wide *main_name = project->source_path + project->parent_length;
    while (*name && ascii_lower(*main_name) == ascii_lower((unsigned char)*name)) {
        ++name;
        ++main_name;
    }
    return !*main_name && !*name;
}

static int load_component(const char *name, char **source, size_t *length, void *context) {
    struct WebProject *project = context;
    size_t name_length = strlen(name);
    if (is_main_file(project, name) || project->parent_length + name_length >= MAX_WINDOWS_PATH) {
        return 0;
    }
    Wide *path = malloc((project->parent_length + name_length + 1) * sizeof(*path));
    if (!path) return 0;
    memcpy(path, project->source_path, project->parent_length * sizeof(*path));
    copy_narrow_to_wide(path + project->parent_length, name);
    Handle file = CreateFileW(path, GENERIC_READ_KH, 1, NULL, OPEN_EXISTING_KH,
                              FILE_ATTRIBUTE_NORMAL_KH, NULL);
    free(path);
    if (file == INVALID_FILE) return 0;
    int64_t size;
    char *bytes = NULL;
    if (GetFileSizeEx(file, &size) && size >= 0 && size <= MAX_KH_FILE_BYTES) {
        bytes = malloc((size_t)size + 1);
        if (bytes && !kh_read_all(file, bytes, (size_t)size)) {
            free(bytes);
            bytes = NULL;
        }
    }
    CloseHandle(file);
    if (!bytes) return 0;
    bytes[size] = 0;
    *source = bytes;
    *length = (size_t)size;
    return 1;
}

static void hex8(Wide *destination, Dword value) {
    const char digits[] = "0123456789abcdef";
    for (int index = 7; index >= 0; --index) {
        destination[index] = (Wide)digits[value & 15];
        value >>= 4;
    }
}

static int has_html_extension(const Wide *path, size_t length) {
    if (length - parent_length(path) <= 5) return 0;
    const char extension[] = ".html";
    for (size_t index = 0; index < 5; ++index) {
        Wide character = path[length - 5 + index];
        if (character >= 'A' && character <= 'Z') character += 'a' - 'A';
        if (character != (Wide)extension[index]) return 0;
    }
    return 1;
}

static int write_site(const KHSite *site, const Wide *chosen_path, char *error, size_t capacity) {
    size_t length = wide_length(chosen_path);
    if (length > MAX_WINDOWS_PATH - 400 || !has_html_extension(chosen_path, length)) {
        set_error(error, capacity, "Choose a valid output name ending in .html.", 0);
        return 0;
    }
    Wide *folder = malloc((length + 1) * sizeof(*folder));
    Wide *temporary = malloc((length + 401) * sizeof(*temporary));
    if (!folder || !temporary) {
        free(folder);
        free(temporary);
        set_error(error, capacity, "Could not allocate a path for the website output.", 0);
        return 0;
    }

    memcpy(folder, chosen_path, (length - 5) * sizeof(*folder));
    copy_narrow_to_wide(folder + length - 5, "-site");

    size_t parent = parent_length(chosen_path);
    memcpy(temporary, chosen_path, parent * sizeof(*temporary));
    copy_narrow_to_wide(temporary + parent, ".kh-site-");
    hex8(temporary + parent + 9, GetCurrentProcessId());
    temporary[parent + 17] = '-';
    size_t stage_length = parent + 26;
    temporary[stage_length] = 0;

    static Dword sequence;
    Dword code = 0;
    int created = 0;
    for (int attempt = 0; attempt < 32; ++attempt) {
        hex8(temporary + parent + 18, sequence++);
        if (CreateDirectoryW(temporary, NULL)) {
            created = 1;
            break;
        }
        code = GetLastError();
        if (code != 80 && code != 183) break;
    }
    if (!created) {
        set_error(error, capacity, "Could not create a temporary website folder.", code);
        free(folder);
        free(temporary);
        return 0;
    }

    size_t touched = 0;
    for (size_t index = 0; index < site->count; ++index) {
        const KHWebFile *entry = &site->files[index];
        temporary[stage_length] = '\\';
        copy_narrow_to_wide(temporary + stage_length + 1, entry->name);
        Handle file = CreateFileW(temporary, GENERIC_WRITE_KH, 0, NULL, CREATE_NEW_KH,
                                  FILE_ATTRIBUTE_NORMAL_KH, NULL);
        if (file == INVALID_FILE) {
            code = GetLastError();
            goto write_failed;
        }
        ++touched;
        int written = kh_write_all(file, entry->text, entry->length);
        if (!written) code = GetLastError();
        if (!CloseHandle(file) && written) {
            written = 0;
            code = GetLastError();
        }
        if (!written) goto write_failed;
    }

    temporary[stage_length] = 0;
    if (MoveFileExW(temporary, folder, 0x8u)) {
        free(folder);
        free(temporary);
        return 1;
    }
    code = GetLastError();
    if (code == 80 || code == 183 || GetFileAttributesW(folder) != 0xffffffffu) {
        set_error(error, capacity, "That website folder already exists. Choose a different name.", 0);
    } else {
        set_error(error, capacity, "Could not move the website to its destination.", code);
    }
    goto clean_stage;

write_failed:
    set_error(error, capacity, "Could not write a website file.", code);
clean_stage:
    for (size_t index = 0; index < touched; ++index) {
        temporary[stage_length] = '\\';
        copy_narrow_to_wide(temporary + stage_length + 1, site->files[index].name);
        DeleteFileW(temporary);
    }
    temporary[stage_length] = 0;
    RemoveDirectoryW(temporary);
    free(folder);
    free(temporary);
    return 0;
}

int kh_export_site(const char *source, const Wide *source_path, const Wide *selected_html_path,
                   KHDiagnostic *diagnostic, char *error, size_t capacity) {
    if (error && capacity) error[0] = 0;
    if (!diagnostic || !source || !selected_html_path) {
        set_error(error, capacity, "The website export is missing its source or destination.", 0);
        return 0;
    }
    memset(diagnostic, 0, sizeof(*diagnostic));
    struct WebProject project = {source_path, source_path ? parent_length(source_path) : 0};
    KHWebSource expanded = {0};
    if (!kh_expand_web_source(source, project.parent_length ? load_component : NULL,
                              &project, &expanded, diagnostic, error, capacity)) {
        kh_free_web_source(&expanded);
        return 0;
    }
    KHSite site = {0};
    int generated = kh_generate_site(expanded.source, &site, diagnostic);
    if (!generated) kh_remap_web_diagnostic(&expanded, diagnostic, error, capacity);
    kh_free_web_source(&expanded);
    int exported = generated && write_site(&site, selected_html_path, error, capacity);
    kh_free_site(&site);
    return exported;
}
