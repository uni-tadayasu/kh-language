#include "lang.h"

#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "lang_unicode.inc"

enum {
    TOKEN_LIMIT = 256, BLOCK_LIMIT = 40, EXPRESSION_LIMIT = 40,
    CALL_LIMIT = 30, RUNTIME_DEPTH_LIMIT = 180, STEP_LIMIT = 50000,
    REPEAT_LIMIT = 10000, STRING_LIMIT = 100000, OUTPUT_SIZE_LIMIT = 400000,
    OUTPUT_LINE_LIMIT = 5000, SCOPE_BUCKETS = 127, LIVE_TEXT_LIMIT = 32 * 1024 * 1024
};

typedef struct { const char *bytes; size_t length; } Slice;
typedef struct { int line, column; } Location;

typedef struct ArenaPage {
    struct ArenaPage *next;
    size_t used, capacity;
    max_align_t alignment;
    unsigned char data[];
} ArenaPage;

typedef struct { ArenaPage *page; KHDiagnostic *error; } Arena;

static void fail(KHDiagnostic *error, Location location, const char *message) {
    if (error->line) return;
    error->line = location.line;
    error->column = location.column;
    snprintf(error->message, sizeof(error->message), "%s", message);
}

static void fail_name(KHDiagnostic *error, Location location, const char *start,
                      Slice name, const char *end) {
    if (error->line) return;
    error->line = location.line;
    error->column = location.column;
    size_t length = name.length > 100 ? 100 : name.length;
    while (length < name.length && ((unsigned char)name.bytes[length] & 0xc0) == 0x80) length--;
    snprintf(error->message, sizeof(error->message), "%s%.*s%s%s",
             start, (int)length, name.bytes, length < name.length ? "…" : "", end);
}

static void *allocate(Arena *arena, size_t size, Location location) {
    size_t alignment = _Alignof(max_align_t);
    size = (size + alignment - 1) & ~(alignment - 1);
    ArenaPage *page = arena->page;
    if (!page || page->capacity - page->used < size) {
        size_t capacity = size > 16384 ? size : 16384;
        page = malloc(sizeof(*page) + capacity);
        if (!page) {
            fail(arena->error, location, "There is not enough memory to run this program.");
            return NULL;
        }
        page->next = arena->page;
        page->used = 0;
        page->capacity = capacity;
        arena->page = page;
    }
    void *block = page->data + page->used;
    page->used += size;
    memset(block, 0, size);
    return block;
}

static void free_arena(Arena *arena) {
    while (arena->page) {
        ArenaPage *next = arena->page->next;
        free(arena->page);
        arena->page = next;
    }
}

static int text_is(Slice text, const char *word) {
    size_t length = strlen(word);
    return text.length == length && !memcmp(text.bytes, word, length);
}

static int same_slice(Slice a, Slice b) {
    return a.length == b.length && (!a.length || !memcmp(a.bytes, b.bytes, a.length));
}

static size_t bucket(Slice key) {
    uint32_t hash = 2166136261u;
    for (size_t i = 0; i < key.length; i++) hash = (hash ^ (unsigned char)key.bytes[i]) * 16777619u;
    return hash % SCOPE_BUCKETS;
}

/* Invalid UTF-8 consumes one byte and is represented by a replacement character. */
static uint32_t read_rune(const char *text, const char *end, size_t *width) {
    unsigned char first = (unsigned char)text[0];
    *width = 1;
    if (first < 0x80) return first;
    size_t count;
    uint32_t code, minimum;
    if (first >= 0xc2 && first <= 0xdf) {
        count = 2; code = first & 0x1f; minimum = 0x80;
    } else if (first >= 0xe0 && first <= 0xef) {
        count = 3; code = first & 0x0f; minimum = 0x800;
    } else if (first >= 0xf0 && first <= 0xf4) {
        count = 4; code = first & 0x07; minimum = 0x10000;
    } else return 0xfffd;
    if ((size_t)(end - text) < count) return 0xfffd;
    for (size_t i = 1; i < count; i++) {
        unsigned char part = (unsigned char)text[i];
        if ((part & 0xc0) != 0x80) return 0xfffd;
        code = (code << 6) | (part & 0x3f);
    }
    if (code < minimum || code > 0x10ffff || (code >= 0xd800 && code <= 0xdfff)) return 0xfffd;
    *width = count;
    return code;
}

static size_t utf16_length(const char *text, size_t length) {
    size_t units = 0;
    const char *end = text + length;
    while (text < end) {
        size_t width;
        uint32_t code = read_rune(text, end, &width);
        units += code > 0xffff ? 2 : 1;
        text += width;
    }
    return units;
}

static size_t write_rune(char *text, uint32_t code) {
    if (code < 0x80) {
        text[0] = (char)code;
        return 1;
    }
    if (code < 0x800) {
        text[0] = (char)(0xc0 | (code >> 6));
        text[1] = (char)(0x80 | (code & 0x3f));
        return 2;
    }
    if (code < 0x10000) {
        text[0] = (char)(0xe0 | (code >> 12));
        text[1] = (char)(0x80 | ((code >> 6) & 0x3f));
        text[2] = (char)(0x80 | (code & 0x3f));
        return 3;
    }
    text[0] = (char)(0xf0 | (code >> 18));
    text[1] = (char)(0x80 | ((code >> 12) & 0x3f));
    text[2] = (char)(0x80 | ((code >> 6) & 0x3f));
    text[3] = (char)(0x80 | (code & 0x3f));
    return 4;
}

static int in_ranges(uint32_t code, const uint32_t ranges[][2], size_t count) {
    size_t start = 0, end = count;
    while (start < end) {
        size_t middle = start + (end - start) / 2;
        if (code < ranges[middle][0]) end = middle;
        else if (code > ranges[middle][1]) start = middle + 1;
        else return 1;
    }
    return 0;
}

static int identifier_start(uint32_t code) {
    return code == '_' || in_ranges(code, id_start_ranges, sizeof(id_start_ranges) / sizeof(id_start_ranges[0]));
}

static int identifier_continue(uint32_t code) {
    return code == '_' || in_ranges(code, id_continue_ranges, sizeof(id_continue_ranges) / sizeof(id_continue_ranges[0]));
}

static int whitespace(uint32_t code) {
    return (code >= 9 && code <= 13) || code == ' ' || code == 0xa0 ||
           code == 0x1680 || (code >= 0x2000 && code <= 0x200a) ||
           code == 0x2028 || code == 0x2029 || code == 0x202f ||
           code == 0x205f || code == 0x3000 || code == 0xfeff;
}

static int digit(char value) { return value >= '0' && value <= '9'; }

typedef struct OwnedText {
    size_t references;
    size_t *live_bytes;
    char bytes[];
} OwnedText;
typedef enum { V_NULL, V_NUMBER, V_TEXT, V_BOOL } ValueKind;
typedef struct {
    ValueKind kind;
    double number;
    Slice text;
    size_t units;
    OwnedText *owner;
} Value;

typedef enum { T_END, T_NAME, T_KEYWORD, T_SYMBOL, T_LITERAL } TokenKind;
typedef struct {
    Location location;
    Slice text;
    TokenKind kind;
    Value literal;
} Token;

static int keyword(Slice word) {
    static const char *words[] = {"say", "if", "else", "repeat", "end", "function", "return", "true", "false", "and", "or", "not"};
    for (size_t i = 0; i < sizeof(words) / sizeof(words[0]); i++) {
        if (text_is(word, words[i])) return 1;
    }
    return 0;
}

static int hex_value(char value) {
    if (digit(value)) return value - '0';
    if (value >= 'a' && value <= 'f') return value - 'a' + 10;
    if (value >= 'A' && value <= 'F') return value - 'A' + 10;
    return -1;
}

static int read_hex4(const char *text, const char *end, uint32_t *code) {
    if (end - text < 4) return 0;
    *code = 0;
    for (int i = 0; i < 4; i++) {
        int digit_value = hex_value(text[i]);
        if (digit_value < 0) return 0;
        *code = (*code << 4) | (uint32_t)digit_value;
    }
    return 1;
}

static Value lex_text(Arena *arena, const char **next, const char *end, Location location) {
    const char *start = *next + 1;
    const char *close = start;
    while (close < end && *close != '"') {
        if (*close++ == '\\' && close < end) close++;
    }
    if (close == end) {
        fail(arena->error, location, "Close this text with a double quote (\").");
        return (Value){0};
    }
    char *buffer = allocate(arena, (size_t)(close - start) + 1, location);
    if (!buffer) return (Value){0};
    size_t count = 0;
    const char *at = start;
    while (at < close) {
        unsigned char current = (unsigned char)*at++;
        if (current < 0x20) goto invalid_escape;
        if (current != '\\') {
            buffer[count++] = (char)current;
            continue;
        }
        switch (*at++) {
        case '"': buffer[count++] = '"'; break;
        case '\\': buffer[count++] = '\\'; break;
        case '/': buffer[count++] = '/'; break;
        case 'b': buffer[count++] = '\b'; break;
        case 'f': buffer[count++] = '\f'; break;
        case 'n': buffer[count++] = '\n'; break;
        case 'r': buffer[count++] = '\r'; break;
        case 't': buffer[count++] = '\t'; break;
        case 'u': {
            uint32_t code, second;
            if (!read_hex4(at, close, &code)) goto invalid_escape;
            at += 4;
            if (code >= 0xd800 && code <= 0xdbff && close - at >= 6 &&
                at[0] == '\\' && at[1] == 'u' && read_hex4(at + 2, close, &second) &&
                second >= 0xdc00 && second <= 0xdfff) {
                code = 0x10000 + ((code - 0xd800) << 10) + second - 0xdc00;
                at += 6;
            } else if (code >= 0xd800 && code <= 0xdfff) {
                code = 0xfffd;
            }
            count += write_rune(buffer + count, code);
            break;
        }
        default: goto invalid_escape;
        }
    }
    buffer[count] = 0;
    *next = close + 1;
    return (Value){.kind = V_TEXT, .text = {buffer, count}, .units = utf16_length(buffer, count)};

invalid_escape:
    fail(arena->error, location, "This text contains an invalid escape or control character.");
    return (Value){0};
}

static void lex_line(Arena *arena, Slice line, int line_number, Token *tokens) {
    const char *at = line.bytes;
    const char *end = at + line.length;
    int column = 1;
    size_t count = 0;
    while (at < end) {
        size_t width;
        uint32_t code = read_rune(at, end, &width);
        if (whitespace(code)) {
            at += width;
            column += code > 0xffff ? 2 : 1;
            continue;
        }
        if (code == '#') break;
        Location location = {line_number, column};
        if (count >= TOKEN_LIMIT) {
            fail(arena->error, location, "This line is too long. Split the expression across separate assignments.");
            return;
        }
        Token token = {.location = location};
        const char *start = at;
        if (code == '"') {
            token.kind = T_LITERAL;
            token.literal = lex_text(arena, &at, end, location);
        } else if (digit(*at) || (*at == '.' && end - at >= 2 && digit(at[1]))) {
            while (at < end && digit(*at)) at++;
            if (at < end && *at == '.') {
                at++;
                while (at < end && digit(*at)) at++;
            }
            size_t size = (size_t)(at - start);
            char number[1024];
            if (size >= sizeof(number)) {
                char *large = allocate(arena, size + 1, location);
                if (!large) return;
                memcpy(large, start, size);
                token.literal.number = strtod(large, NULL);
            } else {
                memcpy(number, start, size);
                number[size] = 0;
                token.literal.number = strtod(number, NULL);
            }
            if (!isfinite(token.literal.number)) fail(arena->error, location, "This number is too large.");
            token.kind = T_LITERAL;
            token.literal.kind = V_NUMBER;
        } else if (identifier_start(code)) {
            at += width;
            while (at < end && identifier_continue(read_rune(at, end, &width))) at += width;
            token.kind = keyword((Slice){start, (size_t)(at - start)}) ? T_KEYWORD : T_NAME;
        } else if (end - at >= 2 && at[1] == '=' && strchr("=!<>", *at) && code < 0x80) {
            at += 2;
            token.kind = T_SYMBOL;
        } else if (code < 0x80 && strchr("=+-*/%()<>,", *at)) {
            at++;
            token.kind = T_SYMBOL;
        } else {
            fail_name(arena->error, location, "Unexpected character \"", (Slice){at, width}, "\".");
        }
        if (arena->error->line) return;
        token.text = (Slice){start, (size_t)(at - start)};
        column += (int)utf16_length(start, token.text.length);
        tokens[count++] = token;
    }
    tokens[count] = (Token){.location = {line_number, column}, .kind = T_END};
}

typedef enum {
    E_LITERAL, E_VARIABLE, E_CALL, E_UNARY, E_BINARY
} ExprKind;
typedef enum {
    OP_NONE, OP_OR, OP_AND, OP_NOT, OP_EQ, OP_NE, OP_LT, OP_LE, OP_GT, OP_GE,
    OP_ADD, OP_SUB, OP_MUL, OP_DIV, OP_REM
} Operation;

typedef struct Expr {
    ExprKind kind;
    Location location;
    Slice name;
    Value literal;
    Operation op;
    struct Expr *left, *right;
    struct Expr *arguments, *next;
    size_t argument_count;
} Expr;

typedef struct Parameter {
    Slice name;
    struct Parameter *next;
} Parameter;

typedef enum {
    S_SAY, S_ASSIGN, S_CALL, S_IF, S_REPEAT, S_RETURN, S_FUNCTION, S_ELSE, S_END
} StatementKind;

typedef struct Statement Statement;
typedef struct { Statement *first, *last; } Block;
struct Statement {
    StatementKind kind;
    Location location;
    Slice name;
    Location name_location;
    Expr *value;
    Block body, alternate;
    Parameter *parameters;
    size_t parameter_count;
    Statement *next, *next_function;
};

typedef struct {
    Block body;
    Statement *functions[SCOPE_BUCKETS];
} Program;

typedef struct {
    Arena *arena;
    Token *tokens;
    size_t index;
} LineParser;

static Token *peek(LineParser *parser) { return &parser->tokens[parser->index]; }

static Token *take(LineParser *parser) {
    Token *token = peek(parser);
    if (token->kind != T_END) parser->index++;
    return token;
}

static int match(LineParser *parser, const char *value) {
    Token *token = peek(parser);
    if (token->kind == T_LITERAL || !text_is(token->text, value)) return 0;
    take(parser);
    return 1;
}

static int expect(LineParser *parser, const char *value, const char *message) {
    if (match(parser, value)) return 1;
    fail(parser->arena->error, peek(parser)->location, message);
    return 0;
}

static Token *expect_name(LineParser *parser, const char *message) {
    Token *token = take(parser);
    if (token->kind == T_NAME) return token;
    fail(parser->arena->error, token->location, message);
    return NULL;
}

static Expr *new_expression(LineParser *parser, Token *token, ExprKind kind) {
    Expr *expression = allocate(parser->arena, sizeof(*expression), token->location);
    if (!expression) return NULL;
    expression->kind = kind;
    expression->location = token->location;
    expression->name = token->text;
    return expression;
}

static Expr *parse_expression(LineParser *parser, int minimum, int depth);

static Expr *parse_call(LineParser *parser, Token *token, int depth) {
    Expr *call = new_expression(parser, token, E_CALL);
    if (!call || match(parser, ")")) return call;
    Expr **next = &call->arguments;
    do {
        Expr *argument = parse_expression(parser, 1, depth + 1);
        if (!argument) return NULL;
        *next = argument;
        next = &argument->next;
        call->argument_count++;
    } while (match(parser, ","));
    if (!expect(parser, ")", "Close the function call with ). Separate arguments with commas.")) return NULL;
    return call;
}

static Expr *parse_primary(LineParser *parser, int depth) {
    Token *token = take(parser);
    if (token->kind == T_LITERAL) {
        Expr *expression = new_expression(parser, token, E_LITERAL);
        if (expression) expression->literal = token->literal;
        return expression;
    }
    if (token->kind == T_NAME) {
        if (match(parser, "(")) return parse_call(parser, token, depth);
        return new_expression(parser, token, E_VARIABLE);
    }
    if (token->kind == T_KEYWORD &&
        (text_is(token->text, "true") || text_is(token->text, "false"))) {
        Expr *expression = new_expression(parser, token, E_LITERAL);
        if (expression) {
            expression->literal.kind = V_BOOL;
            expression->literal.number = text_is(token->text, "true");
        }
        return expression;
    }
    int is_not = token->kind == T_KEYWORD && text_is(token->text, "not");
    if (is_not || (token->kind == T_SYMBOL &&
                   (text_is(token->text, "-") || text_is(token->text, "+")))) {
        Expr *expression = new_expression(parser, token, E_UNARY);
        if (!expression) return NULL;
        expression->op = is_not ? OP_NOT : token->text.bytes[0] == '-' ? OP_SUB : OP_ADD;
        expression->left = parse_expression(parser, is_not ? 4 : 8, depth + 1);
        return expression->left ? expression : NULL;
    }
    if (token->kind == T_SYMBOL && text_is(token->text, "(")) {
        Expr *inside = parse_expression(parser, 1, depth + 1);
        if (!inside || !expect(parser, ")", "Close this expression with ).")) return NULL;
        return inside;
    }
    fail(parser->arena->error, token->location,
         "Expected a number, text in double quotes, true or false, a variable, or a function call.");
    return NULL;
}

static Operation binary_operator(const Token *token, int *priority) {
    static const struct {
        const char *text;
        Operation operation;
        int priority;
    } operators[] = {
        {"or", OP_OR, 1}, {"and", OP_AND, 2},
        {"==", OP_EQ, 4}, {"!=", OP_NE, 4},
        {"<", OP_LT, 5}, {"<=", OP_LE, 5}, {">", OP_GT, 5}, {">=", OP_GE, 5},
        {"+", OP_ADD, 6}, {"-", OP_SUB, 6},
        {"*", OP_MUL, 7}, {"/", OP_DIV, 7}, {"%", OP_REM, 7}
    };
    if (token->kind != T_SYMBOL && token->kind != T_KEYWORD) return OP_NONE;
    for (size_t i = 0; i < sizeof(operators) / sizeof(operators[0]); i++) {
        if (text_is(token->text, operators[i].text)) {
            *priority = operators[i].priority;
            return operators[i].operation;
        }
    }
    return OP_NONE;
}

static Expr *parse_expression(LineParser *parser, int minimum, int depth) {
    if (depth > EXPRESSION_LIMIT) {
        fail(parser->arena->error, peek(parser)->location, "This expression is nested too deeply.");
        return NULL;
    }
    Expr *left = parse_primary(parser, depth);
    while (left) {
        int priority = 0;
        Operation operation = binary_operator(peek(parser), &priority);
        if (operation == OP_NONE || priority < minimum) break;
        Expr *binary = new_expression(parser, take(parser), E_BINARY);
        if (!binary) return NULL;
        binary->op = operation;
        binary->left = left;
        binary->right = parse_expression(parser, priority + 1, depth + 1);
        if (!binary->right) return NULL;
        left = binary;
    }
    return left;
}

static void parse_parameters(LineParser *parser, Statement *statement) {
    if (!expect(parser, "(", "Put the function's parameter names inside parentheses, even when empty.")) return;
    if (match(parser, ")")) return;
    Parameter **next = &statement->parameters;
    do {
        Token *token = expect_name(parser, "Expected a parameter name.");
        if (!token) return;
        for (Parameter *parameter = statement->parameters; parameter; parameter = parameter->next) {
            if (same_slice(parameter->name, token->text)) {
                fail_name(parser->arena->error, token->location, "The parameter \"", token->text,
                          "\" appears more than once.");
                return;
            }
        }
        Parameter *parameter = allocate(parser->arena, sizeof(*parameter), token->location);
        if (!parameter) return;
        parameter->name = token->text;
        *next = parameter;
        next = &parameter->next;
        statement->parameter_count++;
    } while (match(parser, ","));
    expect(parser, ")", "Close the parameter list with ). Separate parameter names with commas.");
}

static Statement *parse_statement(LineParser *parser) {
    Token *token = take(parser);
    Statement *statement = allocate(parser->arena, sizeof(*statement), token->location);
    if (!statement) return NULL;
    statement->location = token->location;
    statement->name = token->text;
    if (token->kind == T_KEYWORD && text_is(token->text, "say")) {
        statement->kind = S_SAY;
        statement->value = parse_expression(parser, 1, 0);
    } else if (token->kind == T_KEYWORD && text_is(token->text, "if")) {
        statement->kind = S_IF;
        statement->value = parse_expression(parser, 1, 0);
    } else if (token->kind == T_KEYWORD && text_is(token->text, "repeat")) {
        statement->kind = S_REPEAT;
        statement->value = parse_expression(parser, 1, 0);
    } else if (token->kind == T_KEYWORD && text_is(token->text, "function")) {
        statement->kind = S_FUNCTION;
        Token *name = expect_name(parser, "Expected a function name after function.");
        if (!name) return NULL;
        statement->name = name->text;
        statement->name_location = name->location;
        parse_parameters(parser, statement);
    } else if (token->kind == T_KEYWORD && text_is(token->text, "return")) {
        statement->kind = S_RETURN;
        if (peek(parser)->kind != T_END) statement->value = parse_expression(parser, 1, 0);
    } else if (token->kind == T_KEYWORD && text_is(token->text, "else")) {
        statement->kind = S_ELSE;
    } else if (token->kind == T_KEYWORD && text_is(token->text, "end")) {
        statement->kind = S_END;
    } else if (token->kind == T_NAME && match(parser, "=")) {
        statement->kind = S_ASSIGN;
        statement->value = parse_expression(parser, 1, 0);
    } else if (token->kind == T_NAME && match(parser, "(")) {
        statement->kind = S_CALL;
        statement->value = parse_call(parser, token, 0);
    } else {
        fail(parser->arena->error, token->location,
             "Start the line with a command such as say, a variable assignment, or a function call.");
        return NULL;
    }
    if (parser->arena->error->line) return NULL;
    Token *extra = peek(parser);
    if (extra->kind != T_END) {
        const char *message = extra->kind == T_SYMBOL && text_is(extra->text, "=")
            ? "Use == to compare values. Use = to assign a variable."
            : "There is extra text at the end of this line.";
        fail(parser->arena->error, extra->location, message);
        return NULL;
    }
    return statement;
}

static void append_statement(Block *block, Statement *statement) {
    if (block->last) block->last->next = statement;
    else block->first = statement;
    block->last = statement;
}

static Statement *find_function(Program *program, Slice name) {
    Statement *function = program->functions[bucket(name)];
    while (function && !same_slice(function->name, name)) function = function->next_function;
    return function;
}

static void parse_program(const char *source, Arena *arena, Program *program) {
    if (!source) {
        fail(arena->error, (Location){1, 1}, "Expected KH source code as text.");
        return;
    }
    size_t length = strlen(source);
    if (length > KH_SOURCE_BYTE_LIMIT || utf16_length(source, length) > KH_SOURCE_UNIT_LIMIT) {
        fail(arena->error, (Location){1, 1}, "This program is too large to run here.");
        return;
    }
    struct Frame {
        Statement *statement;
        Block *block;
        int in_function;
    } frames[BLOCK_LIMIT + 1] = {{NULL, &program->body, 0}};
    Token *tokens = allocate(arena, (TOKEN_LIMIT + 1) * sizeof(*tokens), (Location){1, 1});
    if (!tokens) return;
    int depth = 0, line_number = 1;
    const char *line = source;
    while (*line) {
        const char *end = line;
        while (*end && *end != '\n' && *end != '\r') end++;
        lex_line(arena, (Slice){line, (size_t)(end - line)}, line_number++, tokens);
        if (arena->error->line) return;
        line = end;
        if (*line == '\r') line++;
        if (*line == '\n') line++;
        if (tokens[0].kind == T_END) continue;

        LineParser parser = {arena, tokens, 0};
        Statement *statement = parse_statement(&parser);
        if (!statement) return;
        struct Frame *frame = &frames[depth];
        switch (statement->kind) {
        case S_ELSE:
            if (!frame->statement || frame->statement->kind != S_IF ||
                frame->block == &frame->statement->alternate) {
                fail(arena->error, statement->location,
                     "else must be inside an if block and can appear there only once.");
                return;
            }
            frame->block = &frame->statement->alternate;
            break;
        case S_END:
            if (!depth) {
                fail(arena->error, statement->location, "This end has no matching if, repeat, or function.");
                return;
            }
            depth--;
            break;
        case S_FUNCTION: {
            if (depth) {
                fail(arena->error, statement->location, "Define functions outside other blocks.");
                return;
            }
            if (find_function(program, statement->name)) {
                fail_name(arena->error, statement->name_location, "The function \"", statement->name,
                          "\" is already defined.");
                return;
            }
            size_t index = bucket(statement->name);
            statement->next_function = program->functions[index];
            program->functions[index] = statement;
            frames[++depth] = (struct Frame){statement, &statement->body, 1};
            break;
        }
        case S_IF:
        case S_REPEAT:
            if (depth >= BLOCK_LIMIT) {
                fail(arena->error, statement->location, "These blocks are nested too deeply.");
                return;
            }
            append_statement(frame->block, statement);
            frames[++depth] = (struct Frame){statement, &statement->body, frame->in_function};
            break;
        case S_RETURN:
            if (!frame->in_function) {
                fail(arena->error, statement->location, "return can only appear inside a function.");
                return;
            }
            append_statement(frame->block, statement);
            break;
        default:
            append_statement(frame->block, statement);
        }
    }
    Statement *unclosed = frames[depth].statement;
    if (unclosed) {
        const char *message = "Add an end to close this if block.";
        if (unclosed->kind == S_REPEAT) message = "Add an end to close this repeat block.";
        if (unclosed->kind == S_FUNCTION) message = "Add an end to close this function block.";
        fail(arena->error, unclosed->location, message);
    }
}

typedef struct Variable {
    Slice name;
    Value value;
    struct Variable *next;
} Variable;

typedef struct { Variable *variables[SCOPE_BUCKETS]; } Scope;

typedef struct {
    Program *program;
    KHDiagnostic *error;
    KHOutput output;
    void *output_context;
    KHHostCall host_call;
    void *host_context;
    Scope global;
    size_t steps, output_lines, output_units, live_text_bytes;
} Runtime;

static void release(Value value) {
    if (value.owner && --value.owner->references == 0) {
        *value.owner->live_bytes -= sizeof(*value.owner) + value.text.length + 1;
        free(value.owner);
    }
}

static Value retain(Value value) {
    if (value.owner) value.owner->references++;
    return value;
}

static void free_scope(Scope *scope) {
    for (size_t i = 0; i < SCOPE_BUCKETS; i++) {
        Variable *variable = scope->variables[i];
        while (variable) {
            Variable *next = variable->next;
            release(variable->value);
            free(variable);
            variable = next;
        }
    }
}

static Variable *lookup(Scope *scope, Slice name, size_t index) {
    Variable *variable = scope->variables[index];
    while (variable && !same_slice(variable->name, name)) variable = variable->next;
    return variable;
}

/* Store consumes the caller's reference to value. */
static void store(Runtime *runtime, Scope *scope, Slice name, Location location, Value value) {
    size_t index = bucket(name);
    Variable *variable = lookup(scope, name, index);
    if (variable) {
        release(variable->value);
    } else {
        variable = malloc(sizeof(*variable));
        if (!variable) {
            release(value);
            fail(runtime->error, location, "There is not enough memory to run this program.");
            return;
        }
        variable->name = name;
        variable->next = scope->variables[index];
        scope->variables[index] = variable;
    }
    variable->value = value;
}

static int step(Runtime *runtime, Location location, int depth) {
    if (runtime->error->line) return 0;
    if (depth > RUNTIME_DEPTH_LIMIT) {
        fail(runtime->error, location, "This expression or block is nested too deeply at runtime.");
        return 0;
    }
    if (++runtime->steps > STEP_LIMIT) {
        fail(runtime->error, location, "The program has reached its execution limit. Try fewer repeats or calls.");
        return 0;
    }
    return 1;
}

static Value boolean_value(int value) {
    return (Value){.kind = V_BOOL, .number = value != 0};
}

static Value number_value(Runtime *runtime, Location location, double value) {
    if (!isfinite(value)) fail(runtime->error, location, "The calculation is outside the supported number range.");
    return (Value){.kind = V_NUMBER, .number = value};
}

static Slice display(Value value, char buffer[64]) {
    switch (value.kind) {
    case V_TEXT:
        return value.text;
    case V_BOOL:
        return value.number ? (Slice){"true", 4} : (Slice){"false", 5};
    case V_NUMBER: {
        if (value.number == 0) return (Slice){"0", 1};
        char significant[32];
        for (int precision = 1; precision <= 17; precision++) {
            snprintf(significant, sizeof(significant), "%.*e", precision - 1, value.number);
            if (strtod(significant, NULL) == value.number) break;
        }
        const char *exponent_at = strchr(significant, 'e');
        if (!exponent_at) return (Slice){"0", 1};
        int exponent = (int)strtod(exponent_at + 1, NULL);
        char digits[17] = {0};
        int count = 0;
        const char *at = significant;
        char *out = buffer;
        if (*at == '-') *out++ = *at++;
        while (at < exponent_at) {
            if (*at != '.') digits[count++] = *at;
            at++;
        }
        if (exponent >= -6 && exponent < 21) {
            if (exponent < 0) {
                *out++ = '0';
                *out++ = '.';
                for (int i = -1; i > exponent; i--) *out++ = '0';
                memcpy(out, digits, (size_t)count);
                out += count;
            } else {
                int integer_count = exponent + 1;
                for (int i = 0; i < integer_count; i++) *out++ = i < count ? digits[i] : '0';
                if (integer_count < count) {
                    *out++ = '.';
                    memcpy(out, digits + integer_count, (size_t)(count - integer_count));
                    out += count - integer_count;
                }
            }
        } else {
            *out++ = digits[0];
            if (count > 1) {
                *out++ = '.';
                memcpy(out, digits + 1, (size_t)(count - 1));
                out += count - 1;
            }
            out += snprintf(out, 12, "e%+d", exponent);
        }
        *out = 0;
        return (Slice){buffer, (size_t)(out - buffer)};
    }
    default:
        return (Slice){"null", 4};
    }
}

static int equal_values(Value left, Value right) {
    if (left.kind != right.kind) return 0;
    if (left.kind == V_TEXT) return same_slice(left.text, right.text);
    return left.number == right.number;
}

static Value joined_text(Runtime *runtime, Location location, Value left, Value right) {
    char first_buffer[64], second_buffer[64];
    Slice first = display(left, first_buffer);
    Slice second = display(right, second_buffer);
    size_t units = (left.kind == V_TEXT ? left.units : first.length) +
                   (right.kind == V_TEXT ? right.units : second.length);
    if (units > STRING_LIMIT) {
        fail(runtime->error, location, "The joined text is too long.");
        return (Value){0};
    }
    size_t length = first.length + second.length;
    size_t allocation = sizeof(OwnedText) + length + 1;
    if (allocation > LIVE_TEXT_LIMIT - runtime->live_text_bytes) {
        fail(runtime->error, location, "The program has too much text in memory.");
        return (Value){0};
    }
    OwnedText *owner = malloc(allocation);
    if (!owner) {
        fail(runtime->error, location, "There is not enough memory to run this program.");
        return (Value){0};
    }
    owner->references = 1;
    owner->live_bytes = &runtime->live_text_bytes;
    runtime->live_text_bytes += allocation;
    memcpy(owner->bytes, first.bytes, first.length);
    memcpy(owner->bytes + first.length, second.bytes, second.length);
    owner->bytes[length] = 0;
    return (Value){.kind = V_TEXT, .text = {owner->bytes, length}, .units = units, .owner = owner};
}

static Value binary(Runtime *runtime, Expr *expression, Value left, Value right) {
    Location location = expression->location;
    Operation operation = expression->op;
    if (operation == OP_EQ) return boolean_value(equal_values(left, right));
    if (operation == OP_NE) return boolean_value(!equal_values(left, right));
    if (operation == OP_ADD && (left.kind == V_TEXT || right.kind == V_TEXT)) {
        return joined_text(runtime, location, left, right);
    }
    if (left.kind != V_NUMBER || right.kind != V_NUMBER) {
        fail_name(runtime->error, location, "", expression->name, " needs numbers on both sides of the operator.");
        return (Value){0};
    }
    double a = left.number, b = right.number;
    switch (operation) {
    case OP_ADD: return number_value(runtime, location, a + b);
    case OP_SUB: return number_value(runtime, location, a - b);
    case OP_MUL: return number_value(runtime, location, a * b);
    case OP_DIV:
        if (b != 0) return number_value(runtime, location, a / b);
        fail(runtime->error, location, "Cannot divide by zero.");
        break;
    case OP_REM:
        if (b != 0) return number_value(runtime, location, fmod(a, b));
        fail(runtime->error, location, "Cannot find a remainder with zero.");
        break;
    case OP_LT: return boolean_value(a < b);
    case OP_LE: return boolean_value(a <= b);
    case OP_GT: return boolean_value(a > b);
    case OP_GE: return boolean_value(a >= b);
    default: break;
    }
    return (Value){0};
}

static Value evaluate(Runtime *runtime, Expr *expression, Scope *scope, int depth, int calls);
static int execute_block(Runtime *runtime, Block *block, Scope *scope,
                         int depth, int calls, Value *returned);

static KHHostValue host_argument(Value value) {
    switch (value.kind) {
    case V_NULL: return (KHHostValue){.type = KH_WEB_NULL};
    case V_NUMBER: return (KHHostValue){.type = KH_WEB_NUMBER, .number = value.number};
    case V_TEXT: return (KHHostValue){.type = KH_WEB_TEXT, .text = value.text.bytes,
                                     .length = value.text.length};
    case V_BOOL: return (KHHostValue){.type = KH_WEB_BOOLEAN, .boolean = value.number != 0};
    }
    return (KHHostValue){0};
}

static void call_host(Runtime *runtime, Expr *expression, Scope *scope, int depth, int calls) {
    Location location = expression->location;
    size_t count = expression->argument_count;
    Value *values = NULL;
    KHHostValue *arguments = NULL;
    if (count) {
        values = malloc(count * sizeof(*values));
        arguments = malloc(count * sizeof(*arguments));
        if (!values || !arguments) {
            free(values);
            free(arguments);
            fail(runtime->error, location, "There is not enough memory to run this program.");
            return;
        }
    }

    size_t evaluated = 0;
    int result = 0;
    char error[sizeof(runtime->error->message)] = {0};
    for (Expr *argument = expression->arguments; argument; argument = argument->next) {
        Value value = evaluate(runtime, argument, scope, depth + 1, calls);
        values[evaluated] = value;
        arguments[evaluated++] = host_argument(value);
        if (runtime->error->line) break;
    }
    if (!runtime->error->line) {
        result = runtime->host_call(expression->name.bytes, expression->name.length,
                                    arguments, count, error, sizeof(error), runtime->host_context);
    }

    for (size_t index = 0; index < evaluated; index++) release(values[index]);
    free(arguments);
    free(values);

    if (result < 0) {
        error[sizeof(error) - 1] = '\0';
        fail(runtime->error, location, *error ? error : "The host command failed.");
    } else if (!result) {
        fail_name(runtime->error, location, "The function \"", expression->name, "\" is not defined.");
    }
}

static Value call(Runtime *runtime, Expr *expression, Scope *scope, int depth, int calls) {
    Location location = expression->location;
    Statement *function = find_function(runtime->program, expression->name);
    if (!function) {
        if (runtime->host_call) call_host(runtime, expression, scope, depth, calls);
        else fail_name(runtime->error, location, "The function \"", expression->name, "\" is not defined.");
        return (Value){0};
    }
    if (function->parameter_count != expression->argument_count) {
        char message[96];
        const char *plural = function->parameter_count == 1 ? "argument" : "arguments";
        snprintf(message, sizeof(message), "\" expects %u %s, but received %u.",
                 (unsigned)function->parameter_count, plural, (unsigned)expression->argument_count);
        fail_name(runtime->error, location, "\"", expression->name, message);
        return (Value){0};
    }
    if (calls >= CALL_LIMIT) {
        fail(runtime->error, location, "The function call limit was reached. Check for repeated self-calls.");
        return (Value){0};
    }

    Scope local = {0};
    Value result = {0};
    Expr *argument = expression->arguments;
    for (Parameter *parameter = function->parameters; parameter; parameter = parameter->next) {
        Value value = evaluate(runtime, argument, scope, depth + 1, calls);
        if (runtime->error->line) {
            release(value);
            break;
        }
        store(runtime, &local, parameter->name, location, value);
        if (runtime->error->line) break;
        argument = argument->next;
    }
    if (!runtime->error->line) execute_block(runtime, &function->body, &local, depth + 1, calls + 1, &result);
    free_scope(&local);
    return result;
}

static Value logical(Runtime *runtime, Expr *expression, Scope *scope, int depth, int calls, Value left) {
    const char *message = expression->op == OP_AND
        ? "and needs true or false on both sides."
        : "or needs true or false on both sides.";
    if (left.kind != V_BOOL) {
        fail(runtime->error, expression->location, message);
        return (Value){0};
    }
    if ((expression->op == OP_AND && !left.number) || (expression->op == OP_OR && left.number)) {
        return left;
    }
    Value right = evaluate(runtime, expression->right, scope, depth + 1, calls);
    if (right.kind == V_BOOL) return right;
    release(right);
    fail(runtime->error, expression->location, message);
    return (Value){0};
}

static Value evaluate(Runtime *runtime, Expr *expression, Scope *scope, int depth, int calls) {
    Location location = expression->location;
    if (!step(runtime, location, depth)) return (Value){0};
    switch (expression->kind) {
    case E_LITERAL:
        return expression->literal;
    case E_VARIABLE: {
        size_t index = bucket(expression->name);
        Variable *variable = lookup(scope, expression->name, index);
        if (!variable && scope != &runtime->global) variable = lookup(&runtime->global, expression->name, index);
        if (variable) return retain(variable->value);
        fail_name(runtime->error, location, "The variable \"", expression->name,
                  "\" has no value yet. Set it with = first.");
        break;
    }
    case E_CALL:
        return call(runtime, expression, scope, depth, calls);
    case E_UNARY: {
        Value operand = evaluate(runtime, expression->left, scope, depth + 1, calls);
        if (expression->op == OP_NOT) {
            if (operand.kind == V_BOOL) return boolean_value(!operand.number);
            fail(runtime->error, location, "not needs true or false after it.");
        } else if (operand.kind == V_NUMBER) {
            return number_value(runtime, location, expression->op == OP_SUB ? -operand.number : operand.number);
        } else {
            fail_name(runtime->error, location, "", expression->name, " needs a number after it.");
        }
        release(operand);
        break;
    }
    case E_BINARY: {
        Value left = evaluate(runtime, expression->left, scope, depth + 1, calls);
        Value result = {0};
        if (!runtime->error->line) {
            if (expression->op == OP_AND || expression->op == OP_OR) {
                result = logical(runtime, expression, scope, depth, calls, left);
            } else {
                Value right = evaluate(runtime, expression->right, scope, depth + 1, calls);
                if (!runtime->error->line) result = binary(runtime, expression, left, right);
                release(right);
            }
        }
        release(left);
        return result;
    }
    }
    return (Value){0};
}

static int execute_block(Runtime *runtime, Block *block, Scope *scope,
                         int depth, int calls, Value *returned) {
    for (Statement *statement = block->first; statement; statement = statement->next) {
        Location location = statement->location;
        if (!step(runtime, location, depth)) break;
        Value value = {0};
        if (statement->kind == S_CALL) value = call(runtime, statement->value, scope, depth, calls);
        else if (statement->value) value = evaluate(runtime, statement->value, scope, depth + 1, calls);
        if (runtime->error->line) {
            release(value);
            break;
        }
        switch (statement->kind) {
        case S_SAY: {
            char buffer[64];
            Slice text = display(value, buffer);
            size_t units = value.kind == V_TEXT ? value.units : text.length;
            if (++runtime->output_lines > OUTPUT_LINE_LIMIT ||
                (runtime->output_units += units + 1) > OUTPUT_SIZE_LIMIT) {
                fail(runtime->error, location, "The output is too large. Try using fewer say commands.");
            } else if (runtime->output) {
                runtime->output(text.bytes, text.length, runtime->output_context);
            }
            break;
        }
        case S_ASSIGN:
            store(runtime, scope, statement->name, location, value);
            continue;
        case S_IF:
            if (value.kind != V_BOOL) {
                fail(runtime->error, location, "if needs a condition that gives true or false.");
                break;
            }
            if (execute_block(runtime, value.number ? &statement->body : &statement->alternate,
                              scope, depth + 1, calls, returned)) return 1;
            break;
        case S_REPEAT:
            if (value.kind != V_NUMBER || value.number < 0 || value.number > REPEAT_LIMIT ||
                value.number != (int)value.number) {
                fail(runtime->error, location, "repeat needs a whole number from 0 to 10,000.");
                break;
            }
            for (int index = 0; index < (int)value.number && step(runtime, location, depth); index++) {
                if (execute_block(runtime, &statement->body, scope, depth + 1, calls, returned)) return 1;
            }
            break;
        case S_RETURN:
            *returned = value;
            return 1;
        default:
            break;
        }
        release(value);
    }
    return 0;
}

int kh_check(const char *source, KHDiagnostic *diagnostic) {
    KHDiagnostic local = {0};
    if (!diagnostic) diagnostic = &local;
    *diagnostic = local;
    Arena arena = {.error = diagnostic};
    Program program = {0};
    parse_program(source, &arena, &program);
    free_arena(&arena);
    return !diagnostic->line;
}

int kh_run_host(const char *source, KHOutput output, void *output_context,
                KHHostCall host_call, void *host_context, KHDiagnostic *diagnostic) {
    KHDiagnostic local = {0};
    if (!diagnostic) diagnostic = &local;
    *diagnostic = local;
    Arena arena = {.error = diagnostic};
    Program program = {0};
    parse_program(source, &arena, &program);
    if (!diagnostic->line) {
        Runtime runtime = {.program = &program, .error = diagnostic,
                           .output = output, .output_context = output_context,
                           .host_call = host_call, .host_context = host_context};
        Value returned = {0};
        execute_block(&runtime, &program.body, &runtime.global, 0, 0, &returned);
        release(returned);
        free_scope(&runtime.global);
    }
    free_arena(&arena);
    return !diagnostic->line;
}

int kh_run(const char *source, KHOutput output, void *context, KHDiagnostic *diagnostic) {
    return kh_run_host(source, output, context, NULL, NULL, diagnostic);
}
