#ifndef KH_EDITOR_DIAGNOSTICS_H
#define KH_EDITOR_DIAGNOSTICS_H

#include "lang.h"

/* Check the editor's UTF-8 buffer without running it or reading other files.
   Locations are 1-based, with columns measured in UTF-16 code units.
   A block boundary that depends on a use directive is checked at export. */
int kh_editor_check(const char *source, KHDiagnostic *diagnostic);

#endif
