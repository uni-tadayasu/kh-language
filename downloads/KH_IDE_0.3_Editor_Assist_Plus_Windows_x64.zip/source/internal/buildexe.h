#ifndef KH_BUILDEXE_H
#define KH_BUILDEXE_H

#include <stddef.h>

/* path is a NUL-terminated UTF-16 Windows path. Returns 1 on success. */
int kh_build_exe(const char *utf8_source, const unsigned short *path,
                 char *error, size_t error_size);

#endif
