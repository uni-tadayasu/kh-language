#define _DARWIN_C_SOURCE 1
#define _GNU_SOURCE 1
#define _POSIX_C_SOURCE 200809L

#include "internal/lang.h"
#include "internal/web.h"
#include "internal/webinclude.h"

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#if defined(__linux__)
#include <sys/syscall.h>
#endif

#define SOURCE_LIMIT (KH_SOURCE_BYTE_LIMIT + 3u)

typedef struct {
    int folder;
    struct stat main_file;
} Project;

static int fail_errno(const char *path) {
    int saved = errno;
    fprintf(stderr, "kh: %s: %s\n", path, strerror(saved));
    return 1;
}

static int report_diagnostic(const char *path, const KHDiagnostic *diagnostic,
                             const char *error) {
    if (diagnostic->line > 0) {
        fprintf(stderr, "%s:%d:%d: %s\n", path, diagnostic->line,
                diagnostic->column, diagnostic->message);
    } else if (error && *error) {
        fprintf(stderr, "%s\n", error);
    } else {
        fprintf(stderr, "kh: %s: %s\n", path, diagnostic->message);
    }
    return 1;
}

static char *parent_path(const char *path) {
    const char *slash = strrchr(path, '/');
    if (!slash) return strdup(".");
    return strndup(path, slash == path ? 1 : (size_t)(slash - path));
}

static int read_source(int fd, const struct stat *status, char **source, size_t *length) {
    if (!S_ISREG(status->st_mode)) {
        errno = EINVAL;
        return 0;
    }
    if (status->st_size < 0 || status->st_size > SOURCE_LIMIT) {
        errno = EFBIG;
        return 0;
    }
    size_t capacity = (size_t)status->st_size + 1;
    char *buffer = malloc(capacity + 1);
    if (!buffer) return 0;

    size_t used = 0;
    for (;;) {
        ssize_t count = read(fd, buffer + used, capacity - used);
        if (count == 0) break;
        if (count < 0) {
            if (errno == EINTR) continue;
            goto failed;
        }
        used += (size_t)count;
        if (used > SOURCE_LIMIT) {
            errno = EFBIG;
            goto failed;
        }
        if (used == capacity) {
            capacity *= 2;
            if (capacity > SOURCE_LIMIT + 1) capacity = SOURCE_LIMIT + 1;
            char *larger = realloc(buffer, capacity + 1);
            if (!larger) goto failed;
            buffer = larger;
        }
    }
    if (memchr(buffer, 0, used)) {
        errno = EILSEQ;
        goto failed;
    }
    buffer[used] = '\0';
    *source = buffer;
    *length = used;
    return 1;

failed:;
    int saved = errno;
    free(buffer);
    errno = saved;
    return 0;
}

static int read_main(const char *path, char **source, Project *project) {
    char *parent = parent_path(path);
    if (!parent) return 0;
    project->folder = open(parent, O_RDONLY | O_DIRECTORY);
    free(parent);
    if (project->folder < 0) return 0;
    const char *basename = strrchr(path, '/');
    int file = openat(project->folder, basename ? basename + 1 : path,
                      O_RDONLY | O_NONBLOCK);
    if (file < 0) return 0;
    size_t length = 0;
    int ok = fstat(file, &project->main_file) == 0
          && read_source(file, &project->main_file, source, &length);
    int saved = errno;
    close(file);
    errno = saved;
    return ok;
}

static int load_component(const char *name, char **source, size_t *length, void *context) {
    Project *project = context;
    int file = openat(project->folder, name, O_RDONLY | O_NONBLOCK);
    if (file < 0) return 0;
    struct stat status;
    int ok = fstat(file, &status) == 0
          && (status.st_dev != project->main_file.st_dev || status.st_ino != project->main_file.st_ino)
          && read_source(file, &status, source, length);
    close(file);
    return ok;
}

static void print_output(const char *text, size_t length, void *context) {
    int *failed = context;
    if (!*failed && (fwrite(text, 1, length, stdout) != length || fputc('\n', stdout) == EOF)) {
        *failed = 1;
    }
}

static int run_script(const char *path, const char *source) {
    int failed = 0;
    KHDiagnostic diagnostic;
    if (!kh_run(source, print_output, &failed, &diagnostic)) {
        return report_diagnostic(path, &diagnostic, NULL);
    }
    if (failed || fflush(stdout) == EOF) return fail_errno("stdout");
    return 0;
}

static int rename_new_folder(const char *from, const char *to) {
#if defined(__APPLE__)
    return renamex_np(from, to, RENAME_EXCL);
#elif defined(__linux__) && defined(SYS_renameat2)
    /* Linux's RENAME_NOREPLACE flag. */
    return (int)syscall(SYS_renameat2, AT_FDCWD, from, AT_FDCWD, to, 1u);
#else
    (void)from;
    (void)to;
    errno = ENOTSUP;
    return -1;
#endif
}

static int write_entry(int folder, const KHWebFile *entry) {
    int file = openat(folder, entry->name, O_WRONLY | O_CREAT | O_EXCL, 0666);
    if (file < 0) return 0;
    size_t used = 0;
    while (used < entry->length) {
        ssize_t count = write(file, entry->text + used, entry->length - used);
        if (count < 0 && errno == EINTR) continue;
        if (count <= 0) {
            int saved = count == 0 ? EIO : errno;
            close(file);
            unlinkat(folder, entry->name, 0);
            errno = saved;
            return 0;
        }
        used += (size_t)count;
    }
    if (close(file) == 0) return 1;
    int saved = errno;
    unlinkat(folder, entry->name, 0);
    errno = saved;
    return 0;
}

static int export_site(const char *destination, const KHSite *site) {
    char *path = strdup(destination);
    if (!path) return fail_errno(destination);
    size_t path_length = strlen(path);
    while (path_length > 1 && path[path_length - 1] == '/') path[--path_length] = '\0';
    if (!path_length) {
        free(path);
        errno = EINVAL;
        return fail_errno(destination);
    }

    struct stat existing;
    if (lstat(path, &existing) == 0) {
        free(path);
        errno = EEXIST;
        return fail_errno(destination);
    }
    if (errno != ENOENT) {
        int result = fail_errno(destination);
        free(path);
        return result;
    }

    char *parent = parent_path(path);
    const char suffix[] = ".kh-site-XXXXXX";
    char *temporary = parent ? malloc(strlen(parent) + sizeof(suffix) + 1) : NULL;
    if (!temporary) {
        int result = fail_errno(destination);
        free(parent);
        free(path);
        return result;
    }
    sprintf(temporary, "%s/%s", parent, suffix);
    free(parent);
    if (!mkdtemp(temporary)) {
        int result = fail_errno(destination);
        free(temporary);
        free(path);
        return result;
    }

    int folder = open(temporary, O_RDONLY | O_DIRECTORY);
    size_t written = 0;
    if (folder >= 0) {
        while (written < site->count && write_entry(folder, &site->files[written])) {
            ++written;
        }
    }
    int complete = folder >= 0 && written == site->count;
    if (complete) {
        mode_t previous = umask(0);
        umask(previous);
        complete = fchmod(folder, 0777 & ~previous) == 0 && rename_new_folder(temporary, path) == 0;
    }
    int result = 0;
    if (!complete) {
        result = fail_errno(destination);
        for (size_t index = 0; index < written; ++index) {
            unlinkat(folder, site->files[index].name, 0);
        }
        rmdir(temporary);
    }
    if (folder >= 0) close(folder);
    free(temporary);
    free(path);
    if (result == 0) printf("KH: %s/index.html\n", destination);
    return result;
}

static int build_site(const char *path, const char *source, const char *destination,
                      Project *project) {
    KHDiagnostic diagnostic;
    char error[512];
    KHWebSource expanded;
    if (!kh_expand_web_source(source, load_component, project, &expanded, &diagnostic,
                              error, sizeof(error))) {
        return report_diagnostic(path, &diagnostic, error);
    }
    KHSite site;
    int result;
    if (!kh_generate_site(expanded.source, &site, &diagnostic)) {
        kh_remap_web_diagnostic(&expanded, &diagnostic, error, sizeof(error));
        result = report_diagnostic(path, &diagnostic, error);
    } else {
        result = export_site(destination, &site);
    }
    kh_free_site(&site);
    kh_free_web_source(&expanded);
    return result;
}

static void usage(FILE *out) {
    fputs("KH 0.3\n"
          "Usage:\n"
          "  kh run script.kh\n"
          "  kh web index.kh output-directory\n"
          "  kh --version\n", out);
}

int main(int argc, char **argv) {
    if (argc == 2 && strcmp(argv[1], "--version") == 0) {
        puts("KH 0.3");
        return 0;
    }
    if (argc == 2 && strcmp(argv[1], "--help") == 0) {
        usage(stdout);
        return 0;
    }
    int web = argc == 4 && strcmp(argv[1], "web") == 0;
    if (!web && (argc != 3 || strcmp(argv[1], "run") != 0)) {
        usage(stderr);
        return 2;
    }

    Project project = {.folder = -1};
    char *source;
    if (!read_main(argv[2], &source, &project)) {
        int result = fail_errno(argv[2]);
        if (project.folder >= 0) close(project.folder);
        return result;
    }
    const unsigned char *bytes = (const unsigned char *)source;
    const char *script = bytes[0] == 0xef && bytes[1] == 0xbb && bytes[2] == 0xbf
                       ? source + 3 : source;
    int result = web ? build_site(argv[2], script, argv[3], &project) : run_script(argv[2], script);
    free(source);
    close(project.folder);
    return result;
}
