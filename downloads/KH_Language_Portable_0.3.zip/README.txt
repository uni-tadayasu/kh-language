KH言語 0.3
macOS／Linux向けコマンドライン版

この版はターミナルで使います。ソースはUTF-8の .kh で作成します。
テキストエディターで開いて、英語の命令と日本語の名前を組み合わせて書けます。
ウェブサイト用の命令と同じフォルダーの .kh を読み込む use に対応しています。

■ macOS（Appleシリコン／Intel）・Linuxでソースから作る

Cコンパイラーと make が使える環境で、ZIPを展開し、ターミナルで
展開先のフォルダーに移動してから次を実行します。

    make
    ./kh --version

macOSでは Appleのコマンドライン開発ツールに含まれる clang と make、
Linuxでは GCC または Clang と make を使用できます。
ビルド時に外部ライブラリのダウンロードは不要です。

■ Linux（x86-64）ですぐ使う

同梱の実行ファイルはLinuxのx86-64用です。
展開方法によって実行権限が付かない場合は次を実行してください。

    chmod +x linux-x64/kh
    ./linux-x64/kh --version

下の例で ./kh を ./linux-x64/kh に置き換えて使えます。

■ コンソールスクリプトを実行する

    ./kh run examples/Console/Hello.kh

■ ホームページを作る

    ./kh web examples/Website/index.kh my-site

my-site に index.html、about.html、styles.css、app.js が生成されます。
ブラウザーで my-site/index.html を開くか、フォルダーの中身をまとめて
静的ホスティングへ配置します。出力先は新しい名前を指定してください。
use の関連ファイルは、メインの .kh と同じフォルダーに置きます。

自分のページを書く例

    theme("#1e684d")
    page("私のホームページ", "活動を紹介するサイトです。")
    text("ようこそ！")
    button("押してみる", "クリックできました！")

上の例を index.kh として保存し、次のコマンドで公開用ファイルを作ります。

    ./kh web index.kh public

Linux x86-64上で、ソースからのビルド、日本語を使う実行例、複数の
.kh を読み込むサイト生成を確認済みです。macOS実機では未確認です。
